/*
 * see COPYRIGHT
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <ctype.h>
#include <math.h>

#ifndef WINDOWS
#	include <netinet/in.h>
#	include <unistd.h>
#else
#	include "windows.h"
#endif

#include "ttf.h"
#include "pt1.h"
#include "global.h"

/* big and small values for comparisons */
#define FBIGVAL	(1e20)
#define FEPS	(100000./FBIGVAL)

/* names of the axes */
#define X	0
#define	Y	1

/* the GENTRY extension structure used in fforceconcise() */

struct gex_con {
	double d[2 /*X, Y*/]; /* sizes of curve */
	double sin2; /* squared sinus of the angle to the next gentry */
	double len2; /* squared distance between the endpoints */

/* number of reference dots taken from each curve */
#define NREFDOTS	3

	double dots[NREFDOTS][2]; /* reference dots */

	int flags; /* flags for gentry and tits joint to the next gentry */
/* a vertical or horizontal line may be in 2 quadrants at once */
#define GEXF_QUL	0x00000001 /* in up-left quadrant */
#define GEXF_QUR	0x00000002 /* in up-right quadrant */
#define GEXF_QDR	0x00000004 /* in down-right quadrant */
#define GEXF_QDL	0x00000008 /* in down-left quadrant */
#define GEXF_QMASK	0x0000000F /* quadrant mask */

/* if a line is nearly vertical or horizontal, we remember that idealized quartant too */
#define GEXF_QTO_IDEAL(f)	(((f)&0xF)<<4)
#define GEXF_QFROM_IDEAL(f)	(((f)&0xF0)>>4)
#define GEXF_IDQ_L	0x00000090 /* left */
#define GEXF_IDQ_R	0x00000060 /* right */
#define GEXF_IDQ_U	0x00000030 /* up */
#define GEXF_IDQ_D	0x000000C0 /* down */

/* possibly can be joined with conditions: 
 * (in order of increasing preference, the numeric order is important) 
 */
#define GEXF_JLINE	0x00000100 /* into one line */
#define GEXF_JIGN	0x00000200 /* if one entry's tangent angle is ignored */
#define GEXF_JID	0x00000400 /* if one entry is idealized to hor/vert */
#define GEXF_JFLAT	0x00000800 /* if one entry is flattened */
#define GEXF_JGOOD	0x00001000 /* perfectly, no additional maodifications */

#define GEXF_JMASK	0x00001F00 /* the mask of all above */
#define GEXF_JCVMASK	0x00001E00 /* the mask of all above except JLINE */

/* which entry needs to be modified for conditional joining */
#define GEXF_JIGN1	0x00002000
#define GEXF_JIGN2	0x00004000
#define GEXF_JIGNDIR(dir)	(GEXF_JIGN1<<(dir))
#define GEXF_JID1	0x00008000
#define GEXF_JID2	0x00010000
#define GEXF_JIDDIR(dir)	(GEXF_JID1<<(dir))
#define GEXF_JFLAT1	0x00020000
#define GEXF_JFLAT2	0x00040000
#define GEXF_JFLATDIR(dir)	(GEXF_JFLAT1<<(dir))

#define GEXF_VERT	0x00100000 /* is nearly vertical */
#define GEXF_HOR	0x00200000 /* is nearly horizontal */
#define GEXF_FLAT	0x00400000 /* is nearly flat */

#define GEXF_VDOTS	0x01000000 /* the dots are valid */

	signed char isd[2 /*X,Y*/]; /* signs of the sizes */
};
typedef struct gex_con GEX_CON;

/* convenience macros */
#define	X_CON(ge)	((GEX_CON *)((ge)->ext))
#define X_CON_D(ge)	(X_CON(ge)->d)
#define X_CON_DX(ge)	(X_CON(ge)->d[0])
#define X_CON_DY(ge)	(X_CON(ge)->d[1])
#define X_CON_ISD(ge)	(X_CON(ge)->isd)
#define X_CON_ISDX(ge)	(X_CON(ge)->isd[0])
#define X_CON_ISDY(ge)	(X_CON(ge)->isd[1])
#define X_CON_SIN2(ge)	(X_CON(ge)->sin2)
#define X_CON_LEN2(ge)	(X_CON(ge)->len2)
#define X_CON_F(ge)	(X_CON(ge)->flags)

/* performance statistics about guessing the concise curves */
static int ggoodcv=0, ggoodcvdots=0, gbadcv=0, gbadcvdots=0;

int      stdhw, stdvw;	/* dominant stems widths */
int      stemsnaph[12], stemsnapv[12];	/* most typical stem width */

int      bluevalues[14];
int      nblues;
int      otherblues[10];
int      notherb;
int      bbox[4];	/* the FontBBox array */
double   italic_angle;

GLYPH   *glyph_list;
int    encoding[ENCTABSZ];	/* inverse of glyph[].char_no */
int    kerning_pairs = 0;

/* prototypes */
static void fixcvdir( GENTRY * ge, int dir);
static void fixcvends( GENTRY * ge);
static int fgetcvdir( GENTRY * ge);
static int igetcvdir( GENTRY * ge);
static int fiszigzag( GENTRY *ge);
static int iiszigzag( GENTRY *ge);
static GENTRY * freethisge( GENTRY *ge);
static void addgeafter( GENTRY *oge, GENTRY *nge );
static GENTRY * newgentry( int flags);
static void debugstems( char *name, STEM * hstems, int nhs, STEM * vstems, int nvs);
static int addbluestems( STEM *s, int n);
static void sortstems( STEM * s, int n);
static int stemoverlap( STEM * s1, STEM * s2);
static int steminblue( STEM *s);
static void markbluestems( STEM *s, int nold);
static int joinmainstems( STEM * s, int nold, int useblues);
static void joinsubstems( STEM * s, short *pairs, int nold, int useblues);
static void fixendpath( GENTRY *ge);
static void fdelsmall( GLYPH *g, double minlen);
static void alloc_gex_con( GENTRY *ge);
static double fjointsin2( GENTRY *ge1, GENTRY *ge2);
static double fcvarea( GENTRY *ge);
static double fcvval( GENTRY *ge, int axis, double t);
static void fsampledots( GENTRY *ge, double dots[][2], int ndots);
static void fnormalizege( GENTRY *ge);
static void fanalyzege( GENTRY *ge);
static void fanalyzejoint( GENTRY *ge);
static void fconcisecontour( GLYPH *g, GENTRY *ge);
static double fclosegap( GENTRY *from, GENTRY *to, int axis,
	double gap, double *ret);

int
isign(
     int x
)
{
	if (x > 0)
		return 1;
	else if (x < 0)
		return -1;
	else
		return 0;
}

int
fsign(
     double x
)
{
	if (x > 0.0)
		return 1;
	else if (x < 0.0)
		return -1;
	else
		return 0;
}

static GENTRY *
newgentry(
	int flags
)
{
	GENTRY         *ge;

	ge = calloc(1, sizeof(GENTRY));

	if (ge == 0) {
		fprintf(stderr, "***** Memory allocation error *****\n");
		exit(255);
	}
	ge->stemid = -1;
	ge->flags = flags;
	/* the rest is set to 0 by calloc() */
	return ge;
}

/*
 * Routines to print out Postscript functions with optimization
 */

void
rmoveto(
	int dx,
	int dy
)
{
	if (optimize && dx == 0)
		fprintf(pfa_file, "%d vmoveto\n", dy);
	else if (optimize && dy == 0)
		fprintf(pfa_file, "%d hmoveto\n", dx);
	else
		fprintf(pfa_file, "%d %d rmoveto\n", dx, dy);
}

void
rlineto(
	int dx,
	int dy
)
{
	if (optimize && dx == 0 && dy == 0)	/* for special pathologic
						 * case */
		return;
	else if (optimize && dx == 0)
		fprintf(pfa_file, "%d vlineto\n", dy);
	else if (optimize && dy == 0)
		fprintf(pfa_file, "%d hlineto\n", dx);
	else
		fprintf(pfa_file, "%d %d rlineto\n", dx, dy);
}

void
rrcurveto(
	  int dx1,
	  int dy1,
	  int dx2,
	  int dy2,
	  int dx3,
	  int dy3
)
{
	/* first two ifs are for crazy cases that occur surprisingly often */
	if (optimize && dx1 == 0 && dx2 == 0 && dx3 == 0)
		rlineto(0, dy1 + dy2 + dy3);
	else if (optimize && dy1 == 0 && dy2 == 0 && dy3 == 0)
		rlineto(dx1 + dx2 + dx3, 0);
	else if (optimize && dy1 == 0 && dx3 == 0)
		fprintf(pfa_file, "%d %d %d %d hvcurveto\n",
			dx1, dx2, dy2, dy3);
	else if (optimize && dx1 == 0 && dy3 == 0)
		fprintf(pfa_file, "%d %d %d %d vhcurveto\n",
			dy1, dx2, dy2, dx3);
	else
		fprintf(pfa_file, "%d %d %d %d %d %d rrcurveto\n",
			dx1, dy1, dx2, dy2, dx3, dy3);
}

void
closepath(void)
{
	fprintf(pfa_file, "closepath\n");
}

/*
 * Many of the path processing routines exist (or will exist) in
 * both floating-point and integer version. Fimally most of the
 * processing will go in floating point and the integer processing
 * will become legacy.
 * The names of floating routines start with f, names of integer 
 * routines start with i, and those old routines existing in one 
 * version only have no such prefix at all.
 */

/*
** Routine that checks integrity of the path, for debugging
*/

void
assertpath(
	   GENTRY * from,
	   char *file,
	   int line,
	   char *name
)
{
	GENTRY         *first, *pe, *ge;
	int	isfloat;

	if(from==0)
		return;
	isfloat = (from->flags & GEF_FLOAT);
	pe = from->prev;
	for (ge = from; ge != 0; pe = ge, ge = ge->next) {
		if( (ge->flags & GEF_FLOAT) ^ isfloat ) {
			fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
			fprintf(stderr, "float flag changes from %s to %s at 0x%p (type %c, prev type %c)\n",
				(isfloat ? "TRUE" : "FALSE"), (isfloat ? "FALSE" : "TRUE"), ge, ge->type, pe->type);
			abort();
		}
		if (pe != ge->prev) {
			fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
			fprintf(stderr, "unidirectional chain 0x%x -next-> 0x%x -prev-> 0x%x \n",
				(unsigned int)pe, (unsigned int)ge, (unsigned int)ge->prev);
			abort();
		}

		switch(ge->type) {
		case GE_MOVE:
			break;
		case GE_PATH:
			if (ge->prev == 0) {
				fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
				fprintf(stderr, "empty path at 0x%x \n", (unsigned int)ge);
				abort();
			}
			break;
		case GE_LINE:
		case GE_CURVE:
			if(ge->frwd->bkwd != ge) {
				fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
				fprintf(stderr, "unidirectional chain 0x%x -frwd-> 0x%x -bkwd-> 0x%x \n",
					(unsigned int)ge, (unsigned int)ge->frwd, (unsigned int)ge->frwd->bkwd);
				abort();
			}
			if(ge->prev->type == GE_MOVE) {
				first = ge;
				if(ge->bkwd->next->type != GE_PATH) {
					fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
					fprintf(stderr, "broken first backlink 0x%x -bkwd-> 0x%x -next-> 0x%x \n",
						(unsigned int)ge, (unsigned int)ge->bkwd, (unsigned int)ge->bkwd->next);
					abort();
				}
			}
			if(ge->next->type == GE_PATH) {
				if(ge->frwd != first) {
					fprintf(stderr, "**! assertpath: called from %s line %d (%s) ****\n", file, line, name);
					fprintf(stderr, "broken loop 0x%x -...-> 0x%x -frwd-> 0x%x \n",
						(unsigned int)first, (unsigned int)ge, (unsigned int)ge->frwd);
					abort();
				}
			}
			break;
		}

	}
}

void
assertisfloat(
	GLYPH *g,
	char *msg
)
{
	if( !(g->flags & GF_FLOAT) ) {
		fprintf(stderr, "**! Glyph %s is not float: %s\n", g->name, msg);
		abort();
	}
	if(g->lastentry) {
		if( !(g->lastentry->flags & GEF_FLOAT) ) {
			fprintf(stderr, "**! Glyphs %s last entry is int: %s\n", g->name, msg);
			abort();
		}
	}
}

void
assertisint(
	GLYPH *g,
	char *msg
)
{
	if( (g->flags & GF_FLOAT) ) {
		fprintf(stderr, "**! Glyph %s is not int: %s\n", g->name, msg);
		abort();
	}
	if(g->lastentry) {
		if( (g->lastentry->flags & GEF_FLOAT) ) {
			fprintf(stderr, "**! Glyphs %s last entry is float: %s\n", g->name, msg);
			abort();
		}
	}
}


/*
 * Routines to save the generated data about glyph
 */

void
fg_rmoveto(
	  GLYPH * g,
	  double x,
	  double y)
{
	GENTRY         *oge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: f rmoveto(%g, %g)\n", g->name, x, y);

	assertisfloat(g, "adding float MOVE");

	if ((oge = g->lastentry) != 0) {
		if (oge->type == GE_MOVE) {	/* just eat up the first move */
			oge->fx3 = x;
			oge->fy3 = y;
		} else if (oge->type == GE_LINE || oge->type == GE_CURVE) {
			fprintf(stderr, "Glyph %s: MOVE in middle of path\n", g->name);
		} else {
			GENTRY         *nge;

			nge = newgentry(GEF_FLOAT);
			nge->type = GE_MOVE;
			nge->fx3 = x;
			nge->fy3 = y;

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		}
	} else {
		GENTRY         *nge;

		nge = newgentry(GEF_FLOAT);
		nge->type = GE_MOVE;
		nge->fx3 = x;
		nge->fy3 = y;
		nge->bkwd = (GENTRY*)&g->entries;
		g->entries = g->lastentry = nge;
	}

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

void
ig_rmoveto(
	  GLYPH * g,
	  int x,
	  int y)
{
	GENTRY         *oge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: i rmoveto(%d, %d)\n", g->name, x, y);

	assertisint(g, "adding int MOVE");

	if ((oge = g->lastentry) != 0) {
		if (oge->type == GE_MOVE) {	/* just eat up the first move */
			oge->ix3 = x;
			oge->iy3 = y;
		} else if (oge->type == GE_LINE || oge->type == GE_CURVE) {
			fprintf(stderr, "Glyph %s: MOVE in middle of path, ignored\n", g->name);
		} else {
			GENTRY         *nge;

			nge = newgentry(0);
			nge->type = GE_MOVE;
			nge->ix3 = x;
			nge->iy3 = y;

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		}
	} else {
		GENTRY         *nge;

		nge = newgentry(0);
		nge->type = GE_MOVE;
		nge->ix3 = x;
		nge->iy3 = y;
		nge->bkwd = (GENTRY*)&g->entries;
		g->entries = g->lastentry = nge;
	}

}

void
fg_rlineto(
	  GLYPH * g,
	  double x,
	  double y)
{
	GENTRY         *oge, *nge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: f rlineto(%g, %g)\n", g->name, x, y);

	assertisfloat(g, "adding float LINE");

	nge = newgentry(GEF_FLOAT);
	nge->type = GE_LINE;
	nge->fx3 = x;
	nge->fy3 = y;

	if ((oge = g->lastentry) != 0) {
		if (x == oge->fx3 && y == oge->fy3) {	/* empty line */
			/* ignore it or we will get in troubles later */
			free(nge);
			return;
		}
		if (g->path == 0) {
			g->path = nge;
			nge->bkwd = nge->frwd = nge;
		} else {
			oge->frwd = nge;
			nge->bkwd = oge;
			g->path->bkwd = nge;
			nge->frwd = g->path;
		}

		oge->next = nge;
		nge->prev = oge;
		g->lastentry = nge;
	} else {
		WARNING_1 fprintf(stderr, "Glyph %s: LINE outside of path\n", g->name);
		free(nge);
	}

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

void
ig_rlineto(
	  GLYPH * g,
	  int x,
	  int y)
{
	GENTRY         *oge, *nge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: i rlineto(%d, %d)\n", g->name, x, y);

	assertisint(g, "adding int LINE");

	nge = newgentry(0);
	nge->type = GE_LINE;
	nge->ix3 = x;
	nge->iy3 = y;

	if ((oge = g->lastentry) != 0) {
		if (x == oge->ix3 && y == oge->iy3) {	/* empty line */
			/* ignore it or we will get in troubles later */
			free(nge);
			return;
		}
		if (g->path == 0) {
			g->path = nge;
			nge->bkwd = nge->frwd = nge;
		} else {
			oge->frwd = nge;
			nge->bkwd = oge;
			g->path->bkwd = nge;
			nge->frwd = g->path;
		}

		oge->next = nge;
		nge->prev = oge;
		g->lastentry = nge;
	} else {
		WARNING_1 fprintf(stderr, "Glyph %s: LINE outside of path\n", g->name);
		free(nge);
	}

}

void
fg_rrcurveto(
	    GLYPH * g,
	    double x1,
	    double y1,
	    double x2,
	    double y2,
	    double x3,
	    double y3)
{
	GENTRY         *oge, *nge;

	oge = g->lastentry;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: f rrcurveto(%g, %g, %g, %g, %g, %g)\n"
			,g->name, x1, y1, x2, y2, x3, y3);

	assertisfloat(g, "adding float CURVE");

	if (oge && oge->fx3 == x1 && x1 == x2 && x2 == x3)	/* check if it's
								 * actually a line */
		fg_rlineto(g, x1, y3);
	else if (oge && oge->fy3 == y1 && y1 == y2 && y2 == y3)
		fg_rlineto(g, x3, y1);
	else {
		nge = newgentry(GEF_FLOAT);
		nge->type = GE_CURVE;
		nge->fx1 = x1;
		nge->fy1 = y1;
		nge->fx2 = x2;
		nge->fy2 = y2;
		nge->fx3 = x3;
		nge->fy3 = y3;

		if (oge != 0) {
			if (x3 == oge->fx3 && y3 == oge->fy3) {
				free(nge);	/* consider this curve empty */
				/* ignore it or we will get in troubles later */
				return;
			}
			if (g->path == 0) {
				g->path = nge;
				nge->bkwd = nge->frwd = nge;
			} else {
				oge->frwd = nge;
				nge->bkwd = oge;
				g->path->bkwd = nge;
				nge->frwd = g->path;
			}

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		} else {
			WARNING_1 fprintf(stderr, "Glyph %s: CURVE outside of path\n", g->name);
			free(nge);
		}
	}

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

void
ig_rrcurveto(
	    GLYPH * g,
	    int x1,
	    int y1,
	    int x2,
	    int y2,
	    int x3,
	    int y3)
{
	GENTRY         *oge, *nge;

	oge = g->lastentry;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: i rrcurveto(%d, %d, %d, %d, %d, %d)\n"
			,g->name, x1, y1, x2, y2, x3, y3);

	assertisint(g, "adding int CURVE");

	if (oge && oge->ix3 == x1 && x1 == x2 && x2 == x3)	/* check if it's
								 * actually a line */
		ig_rlineto(g, x1, y3);
	else if (oge && oge->iy3 == y1 && y1 == y2 && y2 == y3)
		ig_rlineto(g, x3, y1);
	else {
		nge = newgentry(0);
		nge->type = GE_CURVE;
		nge->ix1 = x1;
		nge->iy1 = y1;
		nge->ix2 = x2;
		nge->iy2 = y2;
		nge->ix3 = x3;
		nge->iy3 = y3;

		if (oge != 0) {
			if (x3 == oge->ix3 && y3 == oge->iy3) {
				free(nge);	/* consider this curve empty */
				/* ignore it or we will get in troubles later */
				return;
			}
			if (g->path == 0) {
				g->path = nge;
				nge->bkwd = nge->frwd = nge;
			} else {
				oge->frwd = nge;
				nge->bkwd = oge;
				g->path->bkwd = nge;
				nge->frwd = g->path;
			}

			oge->next = nge;
			nge->prev = oge;
			g->lastentry = nge;
		} else {
			WARNING_1 fprintf(stderr, "Glyph %s: CURVE outside of path\n", g->name);
			free(nge);
		}
	}
}

void
g_closepath(
	    GLYPH * g
)
{
	GENTRY         *oge, *nge;

	if (ISDBG(BUILDG))
		fprintf(stderr, "%s: closepath\n", g->name);

	oge = g->lastentry;

	if (g->path == 0) {
		WARNING_1 fprintf(stderr, "Warning: **** closepath on empty path in glyph \"%s\" ****\n",
			g->name);
		if (oge == 0) {
			WARNING_1 fprintf(stderr, "No previois entry\n");
		} else {
			WARNING_1 fprintf(stderr, "Previous entry type: %c\n", oge->type);
			if (oge->type == GE_MOVE) {
				g->lastentry = oge->prev;
				if (oge->prev == 0)
					g->entries = 0;
				else
					g->lastentry->next = 0;
				free(oge);
			}
		}
		return;
	}

	nge = newgentry(oge->flags & GEF_FLOAT); /* keep the same type */
	nge->type = GE_PATH;

	g->path = 0;

	oge->next = nge;
	nge->prev = oge;
	g->lastentry = nge;

	if (0 && ISDBG(BUILDG))
		dumppaths(g, NULL, NULL);
}

/*
 * * SB * Routines to smooth and fix the glyphs
 */

/*
** we don't want to see the curves with coinciding middle and
** outer points
*/

static void
fixcvends(
	  GENTRY * ge
)
{
	int             dx, dy;
	int             x0, y0, x1, y1, x2, y2, x3, y3;

	if (ge->type != GE_CURVE)
		return;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! fixcvends(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	x0 = ge->prev->ix3;
	y0 = ge->prev->iy3;
	x1 = ge->ix1;
	y1 = ge->iy1;
	x2 = ge->ix2;
	y2 = ge->iy2;
	x3 = ge->ix3;
	y3 = ge->iy3;


	/* look at the start of the curve */
	if (x1 == x0 && y1 == y0) {
		dx = x2 - x1;
		dy = y2 - y1;

		if (dx == 0 && dy == 0
		    || x2 == x3 && y2 == y3) {
			/* Oops, we actually have a straight line */
			/*
			 * if it's small, we hope that it will get optimized
			 * later
			 */
			if (abs(x3 - x0) <= 2 || abs(y3 - y0) <= 2) {
				ge->ix1 = x3;
				ge->iy1 = y3;
				ge->ix2 = x0;
				ge->iy2 = y0;
			} else {/* just make it a line */
				ge->type = GE_LINE;
			}
		} else {
			if (abs(dx) < 4 && abs(dy) < 4) {	/* consider it very
								 * small */
				ge->ix1 = x2;
				ge->iy1 = y2;
			} else if (abs(dx) < 8 && abs(dy) < 8) {	/* consider it small */
				ge->ix1 += dx / 2;
				ge->iy1 += dy / 2;
			} else {
				ge->ix1 += dx / 4;
				ge->iy1 += dy / 4;
			}
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(dy) < abs(y3 - y0) * abs(dx)) {
				if (abs(x3 - x0) * abs(ge->iy1 - y0) > abs(y3 - y0) * abs(ge->ix1 - x0))
					ge->ix1 += isign(dx);
			} else {
				if (abs(x3 - x0) * abs(ge->iy1 - y0) < abs(y3 - y0) * abs(ge->ix1 - x0))
					ge->iy1 += isign(dy);
			}

			ge->ix2 += (x3 - x2) / 8;
			ge->iy2 += (y3 - y2) / 8;
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(y3 - y2) < abs(y3 - y0) * abs(x3 - x2)) {
				if (abs(x3 - x0) * abs(y3 - ge->iy2) > abs(y3 - y0) * abs(x3 - ge->ix2))
					ge->iy1 -= isign(y3 - y2);
			} else {
				if (abs(x3 - x0) * abs(y3 - ge->iy2) < abs(y3 - y0) * abs(x3 - ge->ix2))
					ge->ix1 -= isign(x3 - x2);
			}

		}
	} else if (x2 == x3 && y2 == y3) {
		dx = x1 - x2;
		dy = y1 - y2;

		if (dx == 0 && dy == 0) {
			/* Oops, we actually have a straight line */
			/*
			 * if it's small, we hope that it will get optimized
			 * later
			 */
			if (abs(x3 - x0) <= 2 || abs(y3 - y0) <= 2) {
				ge->ix1 = x3;
				ge->iy1 = y3;
				ge->ix2 = x0;
				ge->iy2 = y0;
			} else {/* just make it a line */
				ge->type = GE_LINE;
			}
		} else {
			if (abs(dx) < 4 && abs(dy) < 4) {	/* consider it very
								 * small */
				ge->ix2 = x1;
				ge->iy2 = y1;
			} else if (abs(dx) < 8 && abs(dy) < 8) {	/* consider it small */
				ge->ix2 += dx / 2;
				ge->iy2 += dy / 2;
			} else {
				ge->ix2 += dx / 4;
				ge->iy2 += dy / 4;
			}
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(dy) < abs(y3 - y0) * abs(dx)) {
				if (abs(x3 - x0) * abs(ge->iy2 - y3) > abs(y3 - y0) * abs(ge->ix2 - x3))
					ge->ix2 += isign(dx);
			} else {
				if (abs(x3 - x0) * abs(ge->iy2 - y3) < abs(y3 - y0) * abs(ge->ix2 - x3))
					ge->iy2 += isign(dy);
			}

			ge->ix1 += (x0 - x1) / 8;
			ge->iy1 += (y0 - y1) / 8;
			/* make sure that it's still on the same side */
			if (abs(x3 - x0) * abs(y0 - y1) < abs(y3 - y0) * abs(x0 - x1)) {
				if (abs(x3 - x0) * abs(y0 - ge->iy1) > abs(y3 - y0) * abs(x0 - ge->ix1))
					ge->iy1 -= isign(y0 - y1);
			} else {
				if (abs(x3 - x0) * abs(y0 - ge->iy1) < abs(y3 - y0) * abs(x0 - ge->ix1))
					ge->ix1 -= isign(x0 - x1);
			}

		}
	}
}

/*
** After transformations we want to make sure that the resulting
** curve is going in the same quadrant as the original one,
** because rounding errors introduced during transformations
** may make the result completeley wrong.
**
** `dir' argument describes the direction of the original curve,
** it is the superposition of two values for the front and
** rear ends of curve:
**
** >EQUAL - goes over the line connecting the ends
** =EQUAL - coincides with the line connecting the ends
** <EQUAL - goes under the line connecting the ends
**
** See CVDIR_* for exact definitions.
*/

static void
fixcvdir(
	 GENTRY * ge,
	 int dir
)
{
	int             a, b, c, d;
	double          kk, kk1, kk2;
	int             changed;
	int             fdir, rdir;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! fixcvdir(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	fdir = (dir & CVDIR_FRONT) - CVDIR_FEQUAL;
	if ((dir & CVDIR_REAR) == CVDIR_RSAME)
		rdir = fdir; /* we need only isign, exact value doesn't matter */
	else
		rdir = (dir & CVDIR_REAR) - CVDIR_REQUAL;

	fixcvends(ge);

	c = isign(ge->ix3 - ge->prev->ix3);	/* note the direction of
						 * curve */
	d = isign(ge->iy3 - ge->prev->iy3);

	a = ge->iy3 - ge->prev->iy3;
	b = ge->ix3 - ge->prev->ix3;
	kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
	a = ge->iy1 - ge->prev->iy3;
	b = ge->ix1 - ge->prev->ix3;
	kk1 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
	a = ge->iy3 - ge->iy2;
	b = ge->ix3 - ge->ix2;
	kk2 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));

	changed = 1;
	while (changed) {
		if (ISDBG(FIXCVDIR)) {
			/* for debugging */
			fprintf(stderr, "fixcvdir %d %d (%d %d %d %d %d %d) %f %f %f\n",
				fdir, rdir,
				ge->ix1 - ge->prev->ix3,
				ge->iy1 - ge->prev->iy3,
				ge->ix2 - ge->ix1,
				ge->iy2 - ge->iy1,
				ge->ix3 - ge->ix2,
				ge->iy3 - ge->iy2,
				kk1, kk, kk2);
		}
		changed = 0;

		if (fdir > 0) {
			if (kk1 > kk) {	/* the front end has problems */
				if (c * (ge->ix1 - ge->prev->ix3) > 0) {
					ge->ix1 -= c;
					changed = 1;
				} if (d * (ge->iy2 - ge->iy1) > 0) {
					ge->iy1 += d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy1 - ge->prev->iy3;
				b = ge->ix1 - ge->prev->ix3;
				kk1 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		} else if (fdir < 0) {
			if (kk1 < kk) {	/* the front end has problems */
				if (c * (ge->ix2 - ge->ix1) > 0) {
					ge->ix1 += c;
					changed = 1;
				} if (d * (ge->iy1 - ge->prev->iy3) > 0) {
					ge->iy1 -= d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy1 - ge->prev->iy3;
				b = ge->ix1 - ge->prev->ix3;
				kk1 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		}
		if (rdir > 0) {
			if (kk2 < kk) {	/* the rear end has problems */
				if (c * (ge->ix2 - ge->ix1) > 0) {
					ge->ix2 -= c;
					changed = 1;
				} if (d * (ge->iy3 - ge->iy2) > 0) {
					ge->iy2 += d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy3 - ge->iy2;
				b = ge->ix3 - ge->ix2;
				kk2 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		} else if (rdir < 0) {
			if (kk2 > kk) {	/* the rear end has problems */
				if (c * (ge->ix3 - ge->ix2) > 0) {
					ge->ix2 += c;
					changed = 1;
				} if (d * (ge->iy2 - ge->iy1) > 0) {
					ge->iy2 -= d;
					changed = 1;
				}
				/* recalculate the coefficients */
				a = ge->iy3 - ge->prev->iy3;
				b = ge->ix3 - ge->prev->ix3;
				kk = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
				a = ge->iy3 - ge->iy2;
				b = ge->ix3 - ge->ix2;
				kk2 = fabs(a == 0 ? (b == 0 ? 1. : 100000.) : ((double) b / (double) a));
			}
		}
	}
	fixcvends(ge);
}

/* Get the directions of ends of curve for further usage */

/* expects that the previous element is also float */

static int
fgetcvdir(
	 GENTRY * ge
)
{
	double          a, b;
	double          k, k1, k2;
	int             dir = 0;

	if( !(ge->flags & GEF_FLOAT) ) {
		fprintf(stderr, "**! fgetcvdir(0x%x) on int entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	a = fabs(ge->fy3 - ge->prev->fy3);
	b = fabs(ge->fx3 - ge->prev->fx3);
	k = a < FEPS ? (b < FEPS ? 1. : 100000.) : ( b / a);

	a = fabs(ge->fy1 - ge->prev->fy3);
	b = fabs(ge->fx1 - ge->prev->fx3);
	if(a < FEPS) {
		if(b < FEPS) {
			a = fabs(ge->fy2 - ge->prev->fy3);
			b = fabs(ge->fx2 - ge->prev->fx3);
			k1 = a < FEPS ? (b < FEPS ? k : 100000.) : ( b / a);
		} else
			k1 = FBIGVAL;
	} else
		k1 = b / a;

	a = fabs(ge->fy3 - ge->fy2);
	b = fabs(ge->fx3 - ge->fx2);
	if(a < FEPS) {
		if(b < FEPS) {
			a = fabs(ge->fy3 - ge->fy1);
			b = fabs(ge->fx3 - ge->fx1);
			k2 = a < FEPS ? (b < FEPS ? k : 100000.) : ( b / a);
		} else
			k2 = FBIGVAL;
	} else
		k2 = b / a;

	if(fabs(k1-k) < 0.0001)
		dir |= CVDIR_FEQUAL;
	else if (k1 < k)
		dir |= CVDIR_FUP;
	else
		dir |= CVDIR_FDOWN;

	if(fabs(k2-k) < 0.0001)
		dir |= CVDIR_REQUAL;
	else if (k2 > k)
		dir |= CVDIR_RUP;
	else
		dir |= CVDIR_RDOWN;

	return dir;
}


/* expects that the previous element is also int */

static int
igetcvdir(
	 GENTRY * ge
)
{
	int             a, b;
	double          k, k1, k2;
	int             dir = 0;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! igetcvdir(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	a = ge->iy3 - ge->prev->iy3;
	b = ge->ix3 - ge->prev->ix3;
	k = (a == 0) ? (b == 0 ? 1. : 100000.) : fabs((double) b / (double) a);

	a = ge->iy1 - ge->prev->iy3;
	b = ge->ix1 - ge->prev->ix3;
	if(a == 0) {
		if(b == 0) {
			a = ge->iy2 - ge->prev->iy3;
			b = ge->ix2 - ge->prev->ix3;
			k1 = (a == 0) ? (b == 0 ? k : 100000.) : fabs((double) b / (double) a);
		} else
			k1 = FBIGVAL;
	} else
		k1 = fabs((double) b / (double) a);

	a = ge->iy3 - ge->iy2;
	b = ge->ix3 - ge->ix2;
	if(a == 0) {
		if(b == 0) {
			a = ge->iy3 - ge->iy1;
			b = ge->ix3 - ge->ix1;
			k2 = (a == 0) ? (b == 0 ? k : 100000.) : fabs((double) b / (double) a);
		} else
			k2 = FBIGVAL;
	} else
		k2 = fabs((double) b / (double) a);

	if(fabs(k1-k) < 0.0001)
		dir |= CVDIR_FEQUAL;
	else if (k1 < k)
		dir |= CVDIR_FUP;
	else
		dir |= CVDIR_FDOWN;

	if(fabs(k2-k) < 0.0001)
		dir |= CVDIR_REQUAL;
	else if (k2 > k)
		dir |= CVDIR_RUP;
	else
		dir |= CVDIR_RDOWN;

	return dir;
}

#if 0
/* a function just to test the work of fixcvdir() */
static void
testfixcvdir(
	     GLYPH * g
)
{
	GENTRY         *ge;
	int             dir;

	for (ge = g->entries; ge != 0; ge = ge->next) {
		if (ge->type == GE_CURVE) {
			dir = igetcvdir(ge);
			fixcvdir(ge, dir);
		}
	}
}
#endif

static int
iround(
	double val
)
{
	return (int) (val > 0 ? val + 0.5 : val - 0.5);
}
	
/* for debugging - dump the glyph
 * mark with a star the entries from start to end inclusive
 * (start == NULL means don't mark any, end == NULL means to the last)
 */

void
dumppaths(
	GLYPH *g,
	GENTRY *start,
	GENTRY *end
)
{
	GENTRY *ge;
	int i;
	char mark=' ';

	fprintf(stderr, "Glyph %s:\n", g->name);

	/* now do the conversion */
	for(ge = g->entries; ge != 0; ge = ge->next) {
		if(ge == start)
			mark = '*';
		fprintf(stderr, " %c %8x", mark, (unsigned int)ge);
		switch(ge->type) {
		case GE_MOVE:
		case GE_LINE:
			if(ge->flags & GEF_FLOAT)
				fprintf(stderr," %c float (%g, %g)\n", ge->type, ge->fx3, ge->fy3);
			else
				fprintf(stderr," %c int (%d, %d)\n", ge->type, ge->ix3, ge->iy3);
			break;
		case GE_CURVE:
			if(ge->flags & GEF_FLOAT) {
				fprintf(stderr," C float ");
				for(i=0; i<3; i++)
					fprintf(stderr,"(%g, %g) ", ge->fxn[i], ge->fyn[i]);
				fprintf(stderr,"\n");
			} else {
				fprintf(stderr," C int ");
				for(i=0; i<3; i++)
					fprintf(stderr,"(%d, %d) ", ge->ixn[i], ge->iyn[i]);
				fprintf(stderr,"\n");
			}
			break;
		default:
			fprintf(stderr, " %c\n", ge->type);
			break;
		}
		if(ge == end)
			mark = ' ';
	}
}

/*
 * Routine that converts all entries in the path from float to int
 */

void
pathtoint(
	GLYPH *g
)
{
	GENTRY *ge;
	int x[3], y[3];
	int i;


	if(ISDBG(TOINT))
		fprintf(stderr, "TOINT: glyph %s\n", g->name);
	assertisfloat(g, "converting path to int\n");

	fdelsmall(g, 1.0); /* get rid of sub-pixel contours */
	assertpath(g->entries, __FILE__, __LINE__, g->name);

	/* 1st pass, collect the directions of the curves: have
	 * to do that in advance, while everyting is float
	 */
	for(ge = g->entries; ge != 0; ge = ge->next) {
		if( !(ge->flags & GEF_FLOAT) ) {
			fprintf(stderr, "**! glyphs %s has int entry, found in conversion to int\n",
				g->name);
			exit(1);
		}
		if(ge->type == GE_CURVE) {
			ge->dir = fgetcvdir(ge);
		}
	}

	/* now do the conversion */
	for(ge = g->entries; ge != 0; ge = ge->next) {
		switch(ge->type) {
		case GE_MOVE:
		case GE_LINE:
			if(ISDBG(TOINT))
				fprintf(stderr," %c float x=%g y=%g\n", ge->type, ge->fx3, ge->fy3);
			x[0] = iround(ge->fx3);
			y[0] = iround(ge->fy3);
			for(i=0; i<3; i++) { /* put some valid values everywhere, for convenience */
				ge->ixn[i] = x[0];
				ge->iyn[i] = y[0];
			}
			if(ISDBG(TOINT))
				fprintf(stderr,"   int   x=%d y=%d\n", ge->ix3, ge->iy3);
			break;
		case GE_CURVE:
			if(ISDBG(TOINT))
				fprintf(stderr," %c float ", ge->type);

			for(i=0; i<3; i++) {
				if(ISDBG(TOINT))
					fprintf(stderr,"(%g, %g) ", ge->fxn[i], ge->fyn[i]);
				x[i] = iround(ge->fxn[i]);
				y[i] = iround(ge->fyn[i]);
			}

			if(ISDBG(TOINT))
				fprintf(stderr,"\n   int   ");

			for(i=0; i<3; i++) {
				ge->ixn[i] = x[i];
				ge->iyn[i] = y[i];
				if(ISDBG(TOINT))
					fprintf(stderr,"(%d, %d) ", ge->ixn[i], ge->iyn[i]);
			}
			ge->flags &= ~GEF_FLOAT; /* for fixcvdir */
			fixcvdir(ge, ge->dir);

			if(ISDBG(TOINT)) {
				fprintf(stderr,"\n   fixed ");
				for(i=0; i<3; i++)
					fprintf(stderr,"(%d, %d) ", ge->ixn[i], ge->iyn[i]);
				fprintf(stderr,"\n");
			}

			break;
		}
		ge->flags &= ~GEF_FLOAT;
	}
	g->flags &= ~GF_FLOAT;
}


/* check whether we can fix up the curve to change its size by (dx,dy) */
/* 0 means NO, 1 means YES */

/* for float: if scaling would be under 10% */

int
fcheckcv(
	GENTRY * ge,
	double dx,
	double dy
)
{
	if( !(ge->flags & GEF_FLOAT) ) {
		fprintf(stderr, "**! fcheckcv(0x%x) on int entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	if (ge->type != GE_CURVE)
		return 0;

	if( fabs(ge->fx3 - ge->prev->fx3) < fabs(dx) * 10 )
		return 0;

	if( fabs(ge->fy3 - ge->prev->fy3) < fabs(dy) * 10 )
		return 0;

	return 1;
}

/* for int: if won't create new zigzags at the ends */

int
icheckcv(
	GENTRY * ge,
	int dx,
	int dy
)
{
	int             xdep, ydep;

	if(ge->flags & GEF_FLOAT) {
		fprintf(stderr, "**! icheckcv(0x%x) on floating entry, ABORT\n", (unsigned int)ge);
		abort(); /* dump core */
	}

	if (ge->type != GE_CURVE)
		return 0;

	xdep = ge->ix3 - ge->prev->ix3;
	ydep = ge->iy3 - ge->prev->iy3;

	if (ge->type == GE_CURVE
	    && (xdep * (xdep + dx)) > 0
	    && (ydep * (ydep + dy)) > 0) {
		return 1;
	} else
		return 0;
}

/* float connect the ends of open contours */

void
fclosepaths(
	   GLYPH * g
)
{
	GENTRY         *ge, *fge, *xge, *nge;
	int             i;

	assertisfloat(g, "fclosepaths float\n");

	for (xge = g->entries; xge != 0; xge = xge->next) {
		if( xge->type != GE_PATH )
			continue;

		ge = xge->prev;
		if(ge == 0 || ge->type != GE_LINE && ge->type!= GE_CURVE) {
			fprintf(stderr, "**! Glyph %s got empty path\n",
				g->name);
			exit(1);
		}

		fge = ge->frwd;
		if (fge->prev == 0 || fge->prev->type != GE_MOVE) {
			fprintf(stderr, "**! Glyph %s got strange beginning of path\n",
				g->name);
			exit(1);
		}
		fge = fge->prev;
		if (fge->fx3 != ge->fx3 || fge->fy3 != ge->fy3) {
			/* we have to fix this open path */

			WARNING_4 fprintf(stderr, "Glyph %s got path open by dx=%g dy=%g\n",
			g->name, fge->fx3 - ge->fx3, fge->fy3 - ge->fy3);


			/* add a new line */
			nge = newgentry(GEF_FLOAT);
			(*nge) = (*ge);
			nge->fx3 = fge->fx3;
			nge->fy3 = fge->fy3;
			nge->type = GE_LINE;

			addgeafter(ge, nge);

			if (fabs(ge->fx3 - fge->fx3) <= 2 && fabs(ge->fy3 - fge->fy3) <= 2) {
				/*
				 * small change, try to get rid of the new entry
				 */

				double df[2];

				for(i=0; i<2; i++) {
					df[i] = ge->fpoints[i][2] - fge->fpoints[i][2];
					df[i] = fclosegap(nge, nge, i, df[i], NULL);
				}

				if(df[0] == 0. && df[1] == 0.) {
					/* closed gap successfully, remove the added entry */
					freethisge(nge);
				}
			}
		}
	}
}

void
smoothjoints(
	     GLYPH * g
)
{
	GENTRY         *ge, *ne;
	int             dx1, dy1, dx2, dy2, k;
	int             dir;

	return; /* this stuff seems to create problems */

	assertisint(g, "smoothjoints int");

	if (g->entries == 0)	/* nothing to do */
		return;

	for (ge = g->entries->next; ge != 0; ge = ge->next) {
		ne = ge->frwd;

		/*
		 * although there should be no one-line path * and any path
		 * must end with CLOSEPATH, * nobody can say for sure
		 */

		if (ge == ne || ne == 0)
			continue;

		/* now handle various joints */

		if (ge->type == GE_LINE && ne->type == GE_LINE) {
			dx1 = ge->ix3 - ge->prev->ix3;
			dy1 = ge->iy3 - ge->prev->iy3;
			dx2 = ne->ix3 - ge->ix3;
			dy2 = ne->iy3 - ge->iy3;

			/* check whether they have the same direction */
			/* and the same slope */
			/* then we can join them into one line */

			if (dx1 * dx2 >= 0 && dy1 * dy2 >= 0 && dx1 * dy2 == dy1 * dx2) {
				/* extend the previous line */
				ge->ix3 = ne->ix3;
				ge->iy3 = ne->iy3;

				/* and get rid of the next line */
				freethisge(ne);
			}
		} else if (ge->type == GE_LINE && ne->type == GE_CURVE) {
			fixcvends(ne);

			dx1 = ge->ix3 - ge->prev->ix3;
			dy1 = ge->iy3 - ge->prev->iy3;
			dx2 = ne->ix1 - ge->ix3;
			dy2 = ne->iy1 - ge->iy3;

			/* if the line is nearly horizontal and we can fix it */
			if (dx1 != 0 && 5 * abs(dy1) / abs(dx1) == 0
			    && icheckcv(ne, 0, -dy1)
			    && abs(dy1) <= 4) {
				dir = igetcvdir(ne);
				ge->iy3 -= dy1;
				ne->iy1 -= dy1;
				fixcvdir(ne, dir);
				if (ge->next != ne)
					ne->prev->iy3 -= dy1;
				dy1 = 0;
			} else if (dy1 != 0 && 5 * abs(dx1) / abs(dy1) == 0
				   && icheckcv(ne, -dx1, 0)
				   && abs(dx1) <= 4) {
				/* the same but vertical */
				dir = igetcvdir(ne);
				ge->ix3 -= dx1;
				ne->ix1 -= dx1;
				fixcvdir(ne, dir);
				if (ge->next != ne)
					ne->prev->ix3 -= dx1;
				dx1 = 0;
			}
			/*
			 * if line is horizontal and curve begins nearly
			 * horizontally
			 */
			if (dy1 == 0 && dx2 != 0 && 5 * abs(dy2) / abs(dx2) == 0) {
				dir = igetcvdir(ne);
				ne->iy1 -= dy2;
				fixcvdir(ne, dir);
				dy2 = 0;
			} else if (dx1 == 0 && dy2 != 0 && 5 * abs(dx2) / abs(dy2) == 0) {
				/* the same but vertical */
				dir = igetcvdir(ne);
				ne->ix1 -= dx2;
				fixcvdir(ne, dir);
				dx2 = 0;
			}
		} else if (ge->type == GE_CURVE && ne->type == GE_LINE) {
			fixcvends(ge);

			dx1 = ge->ix3 - ge->ix2;
			dy1 = ge->iy3 - ge->iy2;
			dx2 = ne->ix3 - ge->ix3;
			dy2 = ne->iy3 - ge->iy3;

			/* if the line is nearly horizontal and we can fix it */
			if (dx2 != 0 && 5 * abs(dy2) / abs(dx2) == 0
			    && icheckcv(ge, 0, dy2)
			    && abs(dy2) <= 4) {
				dir = igetcvdir(ge);
				ge->iy3 += dy2;
				ge->iy2 += dy2;
				fixcvdir(ge, dir);
				if (ge->next != ne)
					ne->prev->iy3 += dy2;
				dy2 = 0;
			} else if (dy2 != 0 && 5 * abs(dx2) / abs(dy2) == 0
				   && icheckcv(ge, dx2, 0)
				   && abs(dx2) <= 4) {
				/* the same but vertical */
				dir = igetcvdir(ge);
				ge->ix3 += dx2;
				ge->ix2 += dx2;
				fixcvdir(ge, dir);
				if (ge->next != ne)
					ne->prev->ix3 += dx2;
				dx2 = 0;
			}
			/*
			 * if line is horizontal and curve ends nearly
			 * horizontally
			 */
			if (dy2 == 0 && dx1 != 0 && 5 * abs(dy1) / abs(dx1) == 0) {
				dir = igetcvdir(ge);
				ge->iy2 += dy1;
				fixcvdir(ge, dir);
				dy1 = 0;
			} else if (dx2 == 0 && dy1 != 0 && 5 * abs(dx1) / abs(dy1) == 0) {
				/* the same but vertical */
				dir = igetcvdir(ge);
				ge->ix2 += dx1;
				fixcvdir(ge, dir);
				dx1 = 0;
			}
		} else if (ge->type == GE_CURVE && ne->type == GE_CURVE) {
			fixcvends(ge);
			fixcvends(ne);

			dx1 = ge->ix3 - ge->ix2;
			dy1 = ge->iy3 - ge->iy2;
			dx2 = ne->ix1 - ge->ix3;
			dy2 = ne->iy1 - ge->iy3;

			/*
			 * check if we have a rather smooth joint at extremal
			 * point
			 */
			/* left or right extremal point */
			if (abs(dx1) <= 4 && abs(dx2) <= 4
			    && dy1 != 0 && 5 * abs(dx1) / abs(dy1) == 0
			    && dy2 != 0 && 5 * abs(dx2) / abs(dy2) == 0
			    && (ge->iy3 < ge->prev->iy3 && ne->iy3 < ge->iy3
				|| ge->iy3 > ge->prev->iy3 && ne->iy3 > ge->iy3)
			  && (ge->ix3 - ge->prev->ix3) * (ne->ix3 - ge->ix3) < 0
				) {
				dir = igetcvdir(ge);
				ge->ix2 += dx1;
				dx1 = 0;
				fixcvdir(ge, dir);
				dir = igetcvdir(ne);
				ne->ix1 -= dx2;
				dx2 = 0;
				fixcvdir(ne, dir);
			}
			/* top or down extremal point */
			else if (abs(dy1) <= 4 && abs(dy2) <= 4
				 && dx1 != 0 && 5 * abs(dy1) / abs(dx1) == 0
				 && dx2 != 0 && 5 * abs(dy2) / abs(dx2) == 0
				 && (ge->ix3 < ge->prev->ix3 && ne->ix3 < ge->ix3
				|| ge->ix3 > ge->prev->ix3 && ne->ix3 > ge->ix3)
				 && (ge->iy3 - ge->prev->iy3) * (ne->iy3 - ge->iy3) < 0
				) {
				dir = igetcvdir(ge);
				ge->iy2 += dy1;
				dy1 = 0;
				fixcvdir(ge, dir);
				dir = igetcvdir(ne);
				ne->iy1 -= dy2;
				dy2 = 0;
				fixcvdir(ne, dir);
			}
			/* or may be we just have a smooth junction */
			else if (dx1 * dx2 >= 0 && dy1 * dy2 >= 0
				 && 10 * abs(k = abs(dx1 * dy2) - abs(dy1 * dx2)) < (abs(dx1 * dy2) + abs(dy1 * dx2))) {
				int             tries[6][4];
				int             results[6];
				int             i, b;

				/* build array of changes we are going to try */
				/* uninitalized entries are 0 */
				if (k > 0) {
					static int      t1[6][4] = {
						{0, 0, 0, 0},
						{-1, 0, 1, 0},
						{-1, 0, 0, 1},
						{0, -1, 1, 0},
						{0, -1, 0, 1},
					{-1, -1, 1, 1}};
					memcpy(tries, t1, sizeof tries);
				} else {
					static int      t1[6][4] = {
						{0, 0, 0, 0},
						{1, 0, -1, 0},
						{1, 0, 0, -1},
						{0, 1, -1, 0},
						{0, 1, 0, -1},
					{1, 1, -1, -1}};
					memcpy(tries, t1, sizeof tries);
				}

				/* now try the changes */
				results[0] = abs(k);
				for (i = 1; i < 6; i++) {
					results[i] = abs((abs(dx1) + tries[i][0]) * (abs(dy2) + tries[i][1]) -
							 (abs(dy1) + tries[i][2]) * (abs(dx2) + tries[i][3]));
				}

				/* and find the best try */
				k = abs(k);
				b = 0;
				for (i = 1; i < 6; i++)
					if (results[i] < k) {
						k = results[i];
						b = i;
					}
				/* and finally apply it */
				if (dx1 < 0)
					tries[b][0] = -tries[b][0];
				if (dy2 < 0)
					tries[b][1] = -tries[b][1];
				if (dy1 < 0)
					tries[b][2] = -tries[b][2];
				if (dx2 < 0)
					tries[b][3] = -tries[b][3];

				dir = igetcvdir(ge);
				ge->ix2 -= tries[b][0];
				ge->iy2 -= tries[b][2];
				fixcvdir(ge, dir);
				dir = igetcvdir(ne);
				ne->ix1 += tries[b][3];
				ne->iy1 += tries[b][1];
				fixcvdir(ne, dir);
			}
		}
	}
}

/* debugging: print out stems of a glyph */
static void
debugstems(
	   char *name,
	   STEM * hstems,
	   int nhs,
	   STEM * vstems,
	   int nvs
)
{
	int             i;

	fprintf(pfa_file, "%% %s\n", name);
	fprintf(pfa_file, "%% %d horizontal stems:\n", nhs);
	for (i = 0; i < nhs; i++)
		fprintf(pfa_file, "%% %3d    %d (%d...%d) %c %c%c%c%c\n", i, hstems[i].value,
			hstems[i].from, hstems[i].to,
			((hstems[i].flags & ST_UP) ? 'U' : 'D'),
			((hstems[i].flags & ST_END) ? 'E' : '-'),
			((hstems[i].flags & ST_FLAT) ? 'F' : '-'),
			((hstems[i].flags & ST_ZONE) ? 'Z' : ' '),
			((hstems[i].flags & ST_TOPZONE) ? 'T' : ' '));
	fprintf(pfa_file, "%% %d vertical stems:\n", nvs);
	for (i = 0; i < nvs; i++)
		fprintf(pfa_file, "%% %3d    %d (%d...%d) %c %c%c\n", i, vstems[i].value,
			vstems[i].from, vstems[i].to,
			((vstems[i].flags & ST_UP) ? 'U' : 'D'),
			((vstems[i].flags & ST_END) ? 'E' : '-'),
			((vstems[i].flags & ST_FLAT) ? 'F' : '-'));
}

/* add pseudo-stems for the limits of the Blue zones to the stem array */
static int
addbluestems(
	STEM *s,
	int n
)
{
	int i;

	for(i=0; i<nblues && i<2; i+=2) { /* baseline */
		s[n].value=bluevalues[i];
		s[n].flags=ST_UP|ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i;
		n++;
		s[n].value=bluevalues[i+1];
		s[n].flags=ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+1;
		n++;
	}
	for(i=2; i<nblues; i+=2) { /* top zones */
		s[n].value=bluevalues[i];
		s[n].flags=ST_UP|ST_ZONE|ST_TOPZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i;
		n++;
		s[n].value=bluevalues[i+1];
		s[n].flags=ST_ZONE|ST_TOPZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+1;
		n++;
	}
	for(i=0; i<notherb; i+=2) { /* bottom zones */
		s[n].value=otherblues[i];
		s[n].flags=ST_UP|ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+nblues;
		n++;
		s[n].value=otherblues[i+1];
		s[n].flags=ST_ZONE;
		/* don't overlap with anything */
		s[n].origin=s[n].from=s[n].to= -10000+i+1+nblues;
		n++;
	}
	return n;
}

/* sort stems in array */
static void
sortstems(
	  STEM * s,
	  int n
)
{
	int             i, j;
	STEM            x;


	/* a simple sorting */
	/* hm, the ordering criteria are not quite simple :-) 
	 * if the values are tied
	 * ST_UP always goes under not ST_UP
	 * ST_ZONE goes on the most outer side
	 * ST_END goes towards inner side after ST_ZONE
	 * ST_FLAT goes on the inner side
	 */

	for (i = 0; i < n; i++)
		for (j = i + 1; j < n; j++) {
			if(s[i].value < s[j].value)
				continue;
			if(s[i].value == s[j].value) {
				if( (s[i].flags & ST_UP) < (s[j].flags & ST_UP) )
					continue;
				if( (s[i].flags & ST_UP) == (s[j].flags & ST_UP) ) {
					if( s[i].flags & ST_UP ) {
						if(
						(s[i].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
							>
						(s[j].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
						)
							continue;
					} else {
						if(
						(s[i].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
							<
						(s[j].flags & (ST_ZONE|ST_FLAT|ST_END) ^ ST_FLAT)
						)
							continue;
					}
				}
			}
			x = s[j];
			s[j] = s[i];
			s[i] = x;
		}
}

/* check whether two stem borders overlap */

static int
stemoverlap(
	    STEM * s1,
	    STEM * s2
)
{
	int             result;

	if (s1->from <= s2->from && s1->to >= s2->from
	    || s2->from <= s1->from && s2->to >= s1->from)
		result = 1;
	else
		result = 0;

	if (ISDBG(STEMOVERLAP))
		fprintf(pfa_file, "%% overlap %d(%d..%d)x%d(%d..%d)=%d\n",
			s1->value, s1->from, s1->to, s2->value, s2->from, s2->to, result);
	return result;
}

/* 
 * check if the stem [border] is in an appropriate blue zone
 * (currently not used)
 */

static int
steminblue(
	STEM *s
)
{
	int i, val;

	val=s->value;
	if(s->flags & ST_UP) {
		/* painted size up, look at lower zones */
		if(nblues>=2 && val>=bluevalues[0] && val<=bluevalues[1] )
			return 1;
		for(i=0; i<notherb; i++) {
			if( val>=otherblues[i] && val<=otherblues[i+1] )
				return 1;
		}
	} else {
		/* painted side down, look at upper zones */
		for(i=2; i<nblues; i++) {
			if( val>=bluevalues[i] && val<=bluevalues[i+1] )
				return 1;
		}
	}

	return 0;
}

/* mark the outermost stem [borders] in the blue zones */

static void
markbluestems(
	STEM *s,
	int nold
)
{
	int i, j, a, b, c;
	/*
	 * traverse the list of Blue Values, mark the lowest upper
	 * stem in each bottom zone and the topmost lower stem in
	 * each top zone with ST_BLUE
	 */

	/* top zones */
	for(i=2; i<nblues; i+=2) {
		a=bluevalues[i]; b=bluevalues[i+1];
		if(ISDBG(BLUESTEMS))
			fprintf(pfa_file, "%% looking at blue zone %d...%d\n", a, b);
		for(j=nold-1; j>=0; j--) {
			if( s[j].flags & (ST_ZONE|ST_UP|ST_END) )
				continue;
			c=s[j].value;
			if(c<a) /* too low */
				break;
			if(c<=b) { /* found the topmost stem border */
				/* mark all the stems with the same value */
				if(ISDBG(BLUESTEMS))
					fprintf(pfa_file, "%% found D BLUE at %d\n", s[j].value);
				/* include ST_END values */
				while( s[j+1].value==c && (s[j+1].flags & ST_ZONE)==0 )
					j++;
				s[j].flags |= ST_BLUE;
				for(j--; j>=0 && s[j].value==c 
						&& (s[j].flags & (ST_UP|ST_ZONE))==0 ; j--)
					s[j].flags |= ST_BLUE;
				break;
			}
		}
	}
	/* baseline */
	if(nblues>=2) {
		a=bluevalues[0]; b=bluevalues[1];
		for(j=0; j<nold; j++) {
			if( (s[j].flags & (ST_ZONE|ST_UP|ST_END))!=ST_UP )
				continue;
			c=s[j].value;
			if(c>b) /* too high */
				break;
			if(c>=a) { /* found the lowest stem border */
				/* mark all the stems with the same value */
				if(ISDBG(BLUESTEMS))
					fprintf(pfa_file, "%% found U BLUE at %d\n", s[j].value);
				/* include ST_END values */
				while( s[j-1].value==c && (s[j-1].flags & ST_ZONE)==0 )
					j--;
				s[j].flags |= ST_BLUE;
				for(j++; j<nold && s[j].value==c
						&& (s[j].flags & (ST_UP|ST_ZONE))==ST_UP ; j++)
					s[j].flags |= ST_BLUE;
				break;
			}
		}
	}
	/* bottom zones: the logic is the same as for baseline */
	for(i=0; i<notherb; i+=2) {
		a=otherblues[i]; b=otherblues[i+1];
		for(j=0; j<nold; j++) {
			if( (s[j].flags & (ST_UP|ST_ZONE|ST_END))!=ST_UP )
				continue;
			c=s[j].value;
			if(c>b) /* too high */
				break;
			if(c>=a) { /* found the lowest stem border */
				/* mark all the stems with the same value */
				if(ISDBG(BLUESTEMS))
					fprintf(pfa_file, "%% found U BLUE at %d\n", s[j].value);
				/* include ST_END values */
				while( s[j-1].value==c && (s[j-1].flags & ST_ZONE)==0 )
					j--;
				s[j].flags |= ST_BLUE;
				for(j++; j<nold && s[j].value==c
						&& (s[j].flags & (ST_UP|ST_ZONE))==ST_UP ; j++)
					s[j].flags |= ST_BLUE;
				break;
			}
		}
	}
}

/* Eliminate invalid stems, join equivalent lines and remove nested stems
 * to build the main (non-substituted) set of stems.
 * XXX add consideration of the italic angle
 */
static int
joinmainstems(
	  STEM * s,
	  int nold,
	  int useblues /* do we use the blue values ? */
)
{
#define MAX_STACK	1000
	STEM            stack[MAX_STACK];
	int             nstack = 0;
	int             sbottom = 0;
	int             nnew;
	int             i, j, k;
	int             a, b, c, w1, w2, w3;
	int             fw, fd;
	/*
	 * priority of the last found stem: 
	 * 0 - nothing found yet 
	 * 1 - has ST_END in it (one or more) 
	 * 2 - has no ST_END and no ST_FLAT, can override only one stem 
	 *     with priority 1 
	 * 3 - has no ST_END and at least one ST_FLAT, can override one 
	 *     stem with priority 2 or any number of stems with priority 1
	 * 4 (handled separately) - has ST_BLUE, can override anything
	 */
	int             readystem = 0;
	int             pri;
	int             nlps = 0;	/* number of non-committed
					 * lowest-priority stems */


	for (i = 0, nnew = 0; i < nold; i++) {
		if (s[i].flags & (ST_UP|ST_ZONE)) {
			if(s[i].flags & ST_BLUE) {
				/* we just HAVE to use this value */
				if (readystem)
					nnew += 2;
				readystem=0;

				/* remember the list of Blue zone stems with the same value */
				for(a=i, i++; i<nold && s[a].value==s[i].value
					&& (s[i].flags & ST_BLUE); i++)
					{}
				b=i; /* our range is a <= i < b */
				c= -1; /* index of our best guess up to now */
				pri=0;
				/* try to find a match, don't cross blue zones */
				for(; i<nold && (s[i].flags & ST_BLUE)==0; i++) {
					if(s[i].flags & ST_UP) {
						if(s[i].flags & ST_TOPZONE)
							break;
						else
							continue;
					}
					for(j=a; j<b; j++) {
						if(!stemoverlap(&s[j], &s[i]) )
							continue;
						/* consider priorities */
						if( ( (s[j].flags|s[i].flags) & (ST_FLAT|ST_END) )==ST_FLAT ) {
							c=i;
							goto bluematch;
						}
						if( ((s[j].flags|s[i].flags) & ST_END)==0 )  {
							if(pri < 2) {
								c=i; pri=2;
							}
						} else {
							if(pri == 0) {
								c=i; pri=1;
							}
						}
					}
				}
			bluematch:
				/* clean up the stack */
				nstack=sbottom=0;
				readystem=0;
				/* add this stem */
				s[nnew++]=s[a];
				if(c<0) { /* make one-dot-wide stem */
					if(nnew>=b) { /* have no free space */
						for(j=nold; j>=b; j--) /* make free space */
							s[j]=s[j-1];
						b++;
						nold++;
					}
					s[nnew]=s[a];
					s[nnew].flags &= ~(ST_UP|ST_BLUE);
					nnew++;
					i=b-1;
				} else {
					s[nnew++]=s[c];
					i=c; /* skip up to this point */
				}
				if (ISDBG(MAINSTEMS))
					fprintf(pfa_file, "%% +stem %d...%d U BLUE\n",
						s[nnew-2].value, s[nnew-1].value);
			} else {
				if (nstack >= MAX_STACK) {
					WARNING_1 fprintf(stderr, "Warning: **** converter's stem stack overflow ****\n");
					nstack = 0;
				}
				stack[nstack++] = s[i];
			}
		} else if(s[i].flags & ST_BLUE) {
			/* again, we just HAVE to use this value */
			if (readystem)
				nnew += 2;
			readystem=0;

			/* remember the list of Blue zone stems with the same value */
			for(a=i, i++; i<nold && s[a].value==s[i].value
				&& (s[i].flags & ST_BLUE); i++)
				{}
			b=i; /* our range is a <= i < b */
			c= -1; /* index of our best guess up to now */
			pri=0;
			/* try to find a match */
			for (i = nstack - 1; i >= 0; i--) {
				if( (stack[i].flags & ST_UP)==0 ) {
					if( (stack[i].flags & (ST_ZONE|ST_TOPZONE))==ST_ZONE )
						break;
					else
						continue;
				}
				for(j=a; j<b; j++) {
					if(!stemoverlap(&s[j], &stack[i]) )
						continue;
					/* consider priorities */
					if( ( (s[j].flags|stack[i].flags) & (ST_FLAT|ST_END) )==ST_FLAT ) {
						c=i;
						goto bluedownmatch;
					}
					if( ((s[j].flags|stack[i].flags) & ST_END)==0 )  {
						if(pri < 2) {
							c=i; pri=2;
						}
					} else {
						if(pri == 0) {
							c=i; pri=1;
						}
					}
				}
			}
		bluedownmatch:
			/* if found no match make a one-dot-wide stem */
			if(c<0) {
				c=0;
				stack[0]=s[b-1];
				stack[0].flags |= ST_UP;
				stack[0].flags &= ~ST_BLUE;
			}
			/* remove all the stems conflicting with this one */
			readystem=0;
			for(j=nnew-2; j>=0; j-=2) {
				if (ISDBG(MAINSTEMS))
					fprintf(pfa_file, "%% ?stem %d...%d -- %d\n",
						s[j].value, s[j+1].value, stack[c].value);
				if(s[j+1].value < stack[c].value) /* no conflict */
					break;
				if(s[j].flags & ST_BLUE) {
					/* oops, we don't want to spoil other blue zones */
					stack[c].value=s[j+1].value+1;
					break;
				}
				if( (s[j].flags|s[j+1].flags) & ST_END ) {
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% -stem %d...%d p=1\n",
							s[j].value, s[j+1].value);
					continue; /* pri==1, silently discard it */
				}
				/* we want to discard no nore than 2 stems of pri>=2 */
				if( ++readystem > 2 ) {
					/* change our stem to not conflict */
					stack[c].value=s[j+1].value+1;
					break;
				} else {
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% -stem %d...%d p>=2\n",
							s[j].value, s[j+1].value);
					continue;
				}
			}
			nnew=j+2;
			/* add this stem */
			if(nnew>=b-1) { /* have no free space */
				for(j=nold; j>=b-1; j--) /* make free space */
					s[j]=s[j-1];
				b++;
				nold++;
			}
			s[nnew++]=stack[c];
			s[nnew++]=s[b-1];
			/* clean up the stack */
			nstack=sbottom=0;
			readystem=0;
			/* set the next position to search */
			i=b-1;
			if (ISDBG(MAINSTEMS))
				fprintf(pfa_file, "%% +stem %d...%d D BLUE\n",
					s[nnew-2].value, s[nnew-1].value);
		} else if (nstack > 0) {

			/*
			 * check whether our stem overlaps with anything in
			 * stack
			 */
			for (j = nstack - 1; j >= sbottom; j--) {
				if (s[i].value <= stack[j].value)
					break;
				if (stack[j].flags & ST_ZONE)
					continue;

				if ((s[i].flags & ST_END)
				    || (stack[j].flags & ST_END))
					pri = 1;
				else if ((s[i].flags & ST_FLAT)
					 || (stack[j].flags & ST_FLAT))
					pri = 3;
				else
					pri = 2;

				if (pri < readystem && s[nnew + 1].value >= stack[j].value
				    || !stemoverlap(&stack[j], &s[i]))
					continue;

				if (readystem > 1 && s[nnew + 1].value < stack[j].value) {
					nnew += 2;
					readystem = 0;
					nlps = 0;
				}
				/*
				 * width of the previous stem (if it's
				 * present)
				 */
				w1 = s[nnew + 1].value - s[nnew].value;

				/* width of this stem */
				w2 = s[i].value - stack[j].value;

				if (readystem == 0) {
					/* nothing yet, just add a new stem */
					s[nnew] = stack[j];
					s[nnew + 1] = s[i];
					readystem = pri;
					if (pri == 1)
						nlps = 1;
					else if (pri == 2)
						sbottom = j;
					else {
						sbottom = j + 1;
						while (sbottom < nstack
						       && stack[sbottom].value <= stack[j].value)
							sbottom++;
					}
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
							stack[j].value, s[i].value, pri, nlps);
				} else if (pri == 1) {
					if (stack[j].value > s[nnew + 1].value) {
						/*
						 * doesn't overlap with the
						 * previous one
						 */
						nnew += 2;
						nlps++;
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					} else if (w2 < w1) {
						/* is narrower */
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d %d->%d\n",
								stack[j].value, s[i].value, pri, nlps, w1, w2);
					}
				} else if (pri == 2) {
					if (readystem == 2) {
						/* choose the narrower stem */
						if (w1 > w2) {
							s[nnew] = stack[j];
							s[nnew + 1] = s[i];
							sbottom = j;
							if (ISDBG(MAINSTEMS))
								fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d\n",
									stack[j].value, s[i].value, pri, nlps);
						}
						/* else readystem==1 */
					} else if (stack[j].value > s[nnew + 1].value) {
						/*
						 * value doesn't overlap with
						 * the previous one
						 */
						nnew += 2;
						nlps = 0;
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						sbottom = j;
						readystem = pri;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					} else if (nlps == 1
						   || stack[j].value > s[nnew - 1].value) {
						/*
						 * we can replace the top
						 * stem
						 */
						nlps = 0;
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						readystem = pri;
						sbottom = j;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					}
				} else if (readystem == 3) {	/* that means also
								 * pri==3 */
					/* choose the narrower stem */
					if (w1 > w2) {
						s[nnew] = stack[j];
						s[nnew + 1] = s[i];
						sbottom = j + 1;
						while (sbottom < nstack
						       && stack[sbottom].value <= stack[j].value)
							sbottom++;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% /stem %d...%d p=%d n=%d\n",
								stack[j].value, s[i].value, pri, nlps);
					}
				} else if (pri == 3) {
					/*
					 * we can replace as many stems as
					 * neccessary
					 */
					nnew += 2;
					while (nnew > 0 && s[nnew - 1].value >= stack[j].value) {
						nnew -= 2;
						if (ISDBG(MAINSTEMS))
							fprintf(pfa_file, "%% -stem %d..%d\n",
								s[nnew].value, s[nnew + 1].value);
					}
					nlps = 0;
					s[nnew] = stack[j];
					s[nnew + 1] = s[i];
					readystem = pri;
					sbottom = j + 1;
					while (sbottom < nstack
					       && stack[sbottom].value <= stack[j].value)
						sbottom++;
					if (ISDBG(MAINSTEMS))
						fprintf(pfa_file, "%% +stem %d...%d p=%d n=%d\n",
							stack[j].value, s[i].value, pri, nlps);
				}
			}
		}
	}
	if (readystem)
		nnew += 2;

	/* change the 1-pixel-wide stems to 20-pixel-wide stems if possible 
	 * the constant 20 is recommended in the Type1 manual 
	 */
	if(useblues) {
		for(i=0; i<nnew; i+=2) {
			if(s[i].value != s[i+1].value)
				continue;
			if( ((s[i].flags ^ s[i+1].flags) & ST_BLUE)==0 )
				continue;
			if( s[i].flags & ST_BLUE ) {
				if(nnew>i+2 && s[i+2].value<s[i].value+22)
					s[i+1].value=s[i+2].value-2; /* compensate for fuzziness */
				else
					s[i+1].value+=20;
			} else {
				if(i>0 && s[i-1].value>s[i].value-22)
					s[i].value=s[i-1].value+2; /* compensate for fuzziness */
				else
					s[i].value-=20;
			}
		}
	}
	/* make sure that no stem it stretched between
	 * a top zone and a bottom zone
	 */
	if(useblues) {
		for(i=0; i<nnew; i+=2) {
			a=10000; /* lowest border of top zone crosing the stem */
			b= -10000; /* highest border of bottom zone crossing the stem */

			for(j=2; j<nblues; j++) {
				c=bluevalues[j];
				if( c>=s[i].value && c<=s[i+1].value && c<a )
					a=c;
			}
			if(nblues>=2) {
				c=bluevalues[1];
				if( c>=s[i].value && c<=s[i+1].value && c>b )
					b=c;
			}
			for(j=1; j<notherb; j++) {
				c=otherblues[j];
				if( c>=s[i].value && c<=s[i+1].value && c>b )
					b=c;
			}
			if( a!=10000 && b!= -10000 ) { /* it is stretched */
				/* split the stem into 2 ghost stems */
				for(j=nnew+1; j>i+1; j--) /* make free space */
					s[j]=s[j-2];
				nnew+=2;

				if(s[i].value+22 >= a)
					s[i+1].value=a-2; /* leave space for fuzziness */
				else
					s[i+1].value=s[i].value+20;

				if(s[i+3].value-22 <= b)
					s[i+2].value=b+2; /* leave space for fuzziness */
				else
					s[i+2].value=s[i+3].value-20;

				i+=2;
			}
		}
	}
	/* look for triple stems */
	for (i = 0; i < nnew; i += 2) {
		if (nnew - i >= 6) {
			a = s[i].value + s[i + 1].value;
			b = s[i + 2].value + s[i + 3].value;
			c = s[i + 4].value + s[i + 5].value;

			w1 = s[i + 1].value - s[i].value;
			w2 = s[i + 3].value - s[i + 2].value;
			w3 = s[i + 5].value - s[i + 4].value;

			fw = w3 - w1;	/* fuzz in width */
			fd = ((c - b) - (b - a));	/* fuzz in distance
							 * (doubled) */

			/* we are able to handle some fuzz */
			/*
			 * it doesn't hurt if the declared stem is a bit
			 * narrower than actual unless it's an edge in
			 * a blue zone
			 */
			if (abs(abs(fd) - abs(fw)) * 5 < w2
			    && abs(fw) * 20 < (w1 + w3)) {	/* width dirrerence <10% */

				if(useblues) { /* check that we don't disturb any blue stems */
					j=c; k=a;
					if (fw > 0) {
						if (fd > 0) {
							if( s[i+5].flags & ST_BLUE )
								continue;
							j -= fw;
						} else {
							if( s[i+4].flags & ST_BLUE )
								continue;
							j += fw;
						}
					} else if(fw < 0) {
						if (fd > 0) {
							if( s[i+1].flags & ST_BLUE )
								continue;
							k -= fw;
						} else {
							if( s[i].flags & ST_BLUE )
								continue;
							k += fw;
						}
					}
					pri = ((j - b) - (b - k));

					if (pri > 0) {
						if( s[i+2].flags & ST_BLUE )
							continue;
					} else if(pri < 0) {
						if( s[i+3].flags & ST_BLUE )
							continue;
					}
				}

				/*
				 * first fix up the width of 1st and 3rd
				 * stems
				 */
				if (fw > 0) {
					if (fd > 0) {
						s[i + 5].value -= fw;
						c -= fw;
					} else {
						s[i + 4].value += fw;
						c += fw;
					}
				} else {
					if (fd > 0) {
						s[i + 1].value -= fw;
						a -= fw;
					} else {
						s[i].value += fw;
						a += fw;
					}
				}
				fd = ((c - b) - (b - a));

				if (fd > 0) {
					s[i + 2].value += abs(fd) / 2;
				} else {
					s[i + 3].value -= abs(fd) / 2;
				}

				s[i].flags |= ST_3;
				i += 4;
			}
		}
	}

	return (nnew & ~1);	/* number of lines must be always even */
}

/*
 * these macros and function allow to set the base stem,
 * check that it's not empty and subtract another stem
 * from the base stem (possibly dividing it into multiple parts)
 */

/* pairs for pieces of the base stem */
static short xbstem[MAX_STEMS*2]; 
/* index of the last point */
static int xblast= -1; 

#define setbasestem(from, to) \
	(xbstem[0]=from, xbstem[1]=to, xblast=1)
#define isbaseempty()	(xblast<=0)

/* returns 1 if was overlapping, 0 otherwise */
static int
subfrombase(
	int from,
	int to
) 
{
	int a, b;
	int i, j;

	if(isbaseempty())
		return 0;

	/* handle the simple case simply */
	if(from > xbstem[xblast] || to < xbstem[0])
		return 0;

	/* the binary search may be more efficient */
	/* but for now the linear search is OK */
	for(b=1; from > xbstem[b]; b+=2) {} /* result: from <= xbstem[b] */
	for(a=xblast-1; to < xbstem[a]; a-=2) {} /* result: to >= xbstem[a] */

	/* now the interesting examples are:
	 * (it was hard for me to understand, so I looked at the examples)
	 * 1
	 *     a|-----|          |-----|b   |-----|     |-----|
	 *              f|-----|t
	 * 2
	 *     a|-----|b         |-----|    |-----|     |-----|
	 *      f|--|t
	 * 3
	 *     a|-----|b         |-----|    |-----|     |-----|
	 *           f|-----|t
	 * 4
	 *      |-----|b        a|-----|    |-----|     |-----|
	 *          f|------------|t
	 * 5
	 *      |-----|          |-----|b   |-----|    a|-----|
	 *                   f|-----------------------------|t
	 * 6
	 *      |-----|b         |-----|    |-----|    a|-----|
	 *   f|--------------------------------------------------|t
	 * 7
	 *      |-----|b         |-----|   a|-----|     |-----|
	 *          f|--------------------------|t
	 */

	if(a < b-1) /* hits a gap  - example 1 */
		return 0;

	/* now the subtraction itself */

	if(a==b-1 && from > xbstem[a] && to < xbstem[b]) {
		/* overlaps with only one subrange and splits it - example 2 */
		j=xblast; i=(xblast+=2);
		while(j>=b)
			xbstem[i--]=xbstem[j--];
		xbstem[b]=from-1;
		xbstem[b+1]=to+1;
		return 1;
	/* becomes
	 * 2a
	 *     a|b   ||          |-----|    |-----|     |-----|
	 *      f|--|t
	 */
	}

	if(xbstem[b-1] < from) {
		/* cuts the back of this subrange - examples 3, 4, 7 */
		xbstem[b] = from-1;
		b+=2;
	/* becomes
	 * 3a
	 *     a|----|           |-----|b   |-----|     |-----|
	 *           f|-----|t
	 * 4a
	 *      |---|           a|-----|b   |-----|     |-----|
	 *          f|------------|t
	 * 7a
	 *      |---|            |-----|b  a|-----|     |-----|
	 *          f|--------------------------|t
	 */
	}

	if(xbstem[a+1] > to) {
		/* cuts the front of this subrange - examples 4a, 5, 7a */
		xbstem[a] = to+1;
		a-=2;
	/* becomes
	 * 4b
	 *     a|---|              |---|b   |-----|     |-----|
	 *          f|------------|t
	 * 5b
	 *      |-----|          |-----|b  a|-----|          ||
	 *                   f|-----------------------------|t
	 * 7b
	 *      |---|           a|-----|b        ||     |-----|
	 *          f|--------------------------|t
	 */
	}

	if(a < b-1) /* now after modification it hits a gap - examples 3a, 4b */
		return 1; /* because we have removed something */

	/* now remove the subranges completely covered by the new stem */
	/* examples 5b, 6, 7b */
	i=b-1; j=a+2;
	/* positioned as:
	 * 5b                    i                           j
	 *      |-----|          |-----|b  a|-----|          ||
	 *                   f|-----------------------------|t
	 * 6    i                                             xblast  j
	 *      |-----|b         |-----|    |-----|    a|-----|
	 *   f|--------------------------------------------------|t
	 * 7b                    i               j
	 *      |---|           a|-----|b        ||     |-----|
	 *          f|--------------------------|t
	 */
	while(j <= xblast)
		xbstem[i++]=xbstem[j++];
	xblast=i-1;
	return 1;
}

/* for debugging */
static void
printbasestem(void)
{
	int i;

	printf("( ");
	for(i=0; i<xblast; i+=2)
		printf("%d-%d ", xbstem[i], xbstem[i+1]);
	printf(") %d\n", xblast);
}

/*
 * Join the stem borders to build the sets of substituted stems
 * XXX add consideration of the italic angle
 */
static void
joinsubstems(
	  STEM * s,
	  short *pairs,
	  int nold,
	  int useblues /* do we use the blue values ? */
)
{
	int i, j, x;
	static unsigned char mx[MAX_STEMS][MAX_STEMS];

	/* we do the substituted groups of stems first
	 * and it looks like it's going to be REALLY SLOW 
	 * AND PAINFUL but let's bother about it later
	 */

	/* for the substituted stems we don't bother about [hv]stem3 -
	 * anyway the X11R6 rasterizer does not bother about hstem3
	 * at all and is able to handle only one global vstem3
	 * per glyph 
	 */

	/* clean the used part of matrix */
	for(i=0; i<nold; i++)
		for(j=0; j<nold; j++)
			mx[i][j]=0;

	/* build the matrix of stem pairs */
	for(i=0; i<nold; i++) {
		if( s[i].flags & ST_ZONE )
			continue;
		if(s[i].flags & ST_BLUE)
			mx[i][i]=1; /* allow to pair with itself if no better pair */
		if(s[i].flags & ST_UP) { /* the down-stems are already matched */
			setbasestem(s[i].from, s[i].to);
			for(j=i+1; j<nold; j++) {
				if(s[i].value==s[j].value
				|| s[j].flags & ST_ZONE ) {
					continue;
				}
				x=subfrombase(s[j].from, s[j].to);

				if(s[j].flags & ST_UP) /* match only up+down pairs */
					continue;

				mx[i][j]=mx[j][i]=x;

				if(isbaseempty()) /* nothing else to do */
					break;
			}
		}
	}

	if(ISDBG(SUBSTEMS)) {
		fprintf(pfa_file, "%%     ");
		for(j=0; j<nold; j++)
			putc( j%10==0 ? '0'+(j/10)%10 : ' ', pfa_file);
		fprintf(pfa_file, "\n%%     ");
		for(j=0; j<nold; j++)
			putc('0'+j%10, pfa_file);
		putc('\n', pfa_file);
		for(i=0; i<nold; i++) {
			fprintf(pfa_file, "%% %3d ",i);
			for(j=0; j<nold; j++)
				putc( mx[i][j] ? 'X' : '.', pfa_file);
			putc('\n', pfa_file);
		}
	}

	/* now use the matrix to find the best pair for each stem */
	for(i=0; i<nold; i++) {
		int pri, lastpri, v, f;

		x= -1; /* best pair: none */
		lastpri=0;

		v=s[i].value;
		f=s[i].flags;

		if(f & ST_ZONE) {
			pairs[i]= -1;
			continue;
		}

		if(f & ST_UP) {
			for(j=i+1; j<nold; j++) {
				if(mx[i][j]==0)
					continue;

				if( (f | s[j].flags) & ST_END )
					pri=1;
				else if( (f | s[j].flags) & ST_FLAT )
					pri=3;
				else
					pri=2;

				if(lastpri==0
				|| pri > lastpri  
				&& ( lastpri==1 || s[j].value-v<20 || (s[x].value-v)*2 >= s[j].value-v ) ) {
					lastpri=pri;
					x=j;
				}
			}
		} else {
			for(j=i-1; j>=0; j--) {
				if(mx[i][j]==0)
					continue;

				if( (f | s[j].flags) & ST_END )
					pri=1;
				else if( (f | s[j].flags) & ST_FLAT )
					pri=3;
				else
					pri=2;

				if(lastpri==0
				|| pri > lastpri  
				&& ( lastpri==1 || v-s[j].value<20 || (v-s[x].value)*2 >= v-s[j].value ) ) {
					lastpri=pri;
					x=j;
				}
			}
		}
		if(x== -1 && mx[i][i])
			pairs[i]=i; /* a special case */
		else
			pairs[i]=x;
	}

	if(ISDBG(SUBSTEMS)) {
		for(i=0; i<nold; i++) {
			j=pairs[i];
			if(j>0)
				fprintf(pfa_file, "%% %d...%d  (%d x %d)\n", s[i].value, s[j].value, i, j);
		}
	}
}

/*
 * Make all the stems originating at the same value get the
 * same width. Without this the rasterizer may move the dots
 * randomly up or down by one pixel, and that looks bad.
 * The prioritisation is the same as in findstemat().
 */
static void
uniformstems(
	  STEM * s,
	  short *pairs,
	  int ns
)
{
	int i, j, from, to, val, dir;
	int pri, prevpri[2], wd, prevwd[2], prevbest[2];

	for(from=0; from<ns; from=to) {
		prevpri[0] = prevpri[1] = 0;
		prevwd[0] = prevwd[1] = 0;
		prevbest[0] = prevbest[1] = -1;
		val = s[from].value;

		for(to = from; to<ns && s[to].value == val; to++) {
			dir = ((s[to].flags & ST_UP)!=0);

			i=pairs[to]; /* the other side of this stem */
			if(i<0 || i==to)
				continue; /* oops, no other side */
			wd=abs(s[i].value-val);
			if(wd == 0)
				continue;
			pri=1;
			if( (s[to].flags | s[i].flags) & ST_END )
				pri=0;
			if( prevbest[dir] == -1 || pri > prevpri[dir] || wd<prevwd[dir] ) {
				prevbest[dir]=i;
				prevpri[dir]=pri;
				prevwd[dir]=wd;
			}
		}

		for(i=from; i<to; i++) {
			dir = ((s[i].flags & ST_UP)!=0);
			if(prevbest[dir] >= 0) {
				if(ISDBG(SUBSTEMS)) {
					fprintf(stderr, "at %d (%s %d) pair %d->%d(%d)\n", i, 
						(dir ? "UP":"DOWN"), s[i].value, pairs[i], prevbest[dir],
						s[prevbest[dir]].value);
				}
				pairs[i] = prevbest[dir];
			}
		}
	}
}

/* 
 * Find the best stem in the array at the specified (value, origin),
 * related to the entry ge.
 * Returns its index in the array sp, -1 means "none".
 * prevbest is the result for the other end of the line, we must 
 * find something better than it or leave it as it is.
 */
static int
findstemat(
	int value,
	int origin,
	GENTRY *ge,
	STEM *sp,
	short *pairs,
	int ns,
	int prevbest /* -1 means "none" */
)
{
	int i, min, max;
	int v, si;
	int pri, prevpri; /* priority, 0 = has ST_END, 1 = no ST_END */
	int wd, prevwd; /* stem width */

	si= -1; /* nothing yet */

	/* stems are ordered by value, binary search */
	min=0; max=ns; /* min <= i < max */
	while( min < max ) {
		i=(min+max)/2;
		v=sp[i].value;
		if(v<value)
			min=i+1;
		else if(v>value)
			max=i;
		else {
			si=i; /* temporary value */
			break;
		}
	}

	if( si < 0 ) /* found nothing this time */
		return prevbest;

	/* find the priority of the prevbest */
	/* we expect that prevbest has a pair */
	if(prevbest>=0) {
		i=pairs[prevbest];
		prevpri=1;
		if( (sp[prevbest].flags | sp[i].flags) & ST_END )
			prevpri=0; 
		prevwd=abs(sp[i].value-value);
	}

	/* stems are not ordered by origin, so now do the linear search */

	while( si>0 && sp[si-1].value==value ) /* find the first one */
		si--;

	for(; si<ns && sp[si].value==value; si++) {
		if(sp[si].origin != origin) 
			continue;
		if(sp[si].ge != ge) {
			if(ISDBG(SUBSTEMS)) {
				fprintf(stderr, 
					"dbg: possible self-intersection at v=%d o=%d exp_ge=0x%x ge=0x%x\n",
					value, origin, (unsigned int)ge, (unsigned int)sp[si].ge);
			}
			continue;
		}
		i=pairs[si]; /* the other side of this stem */
		if(i<0)
			continue; /* oops, no other side */
		pri=1;
		if( (sp[si].flags | sp[i].flags) & ST_END )
			pri=0;
		wd=abs(sp[i].value-value);
		if( prevbest == -1 || pri >prevpri 
		|| pri==prevpri && prevwd==0 || wd!=0 && wd<prevwd ) {
			prevbest=si;
			prevpri=pri;
			prevwd=wd;
			continue;
		}
	}

	return prevbest;
}

/* add the substems for one glyph entry 
 * (called from groupsubstems())
 * returns 0 if all OK, 1 if too many groups
 */

static int gssentry_lastgrp=0; /* reset to 0 for each new glyph */

static int
gssentry( /* crazy number of parameters */
	GENTRY *ge,
	STEM *hs, /* horizontal stems, sorted by value */
	short *hpairs,
	int nhs,
	STEM *vs, /* vertical stems, sorted by value */
	short *vpairs,
	int nvs,
	STEMBOUNDS *s,
	short *egp,
	int *nextvsi, 
	int *nexthsi /* -2 means "check by yourself" */
) {
	enum {
		SI_VP,	/* vertical primary */
		SI_HP,	/* horizontal primary */
		SI_SIZE /* size of the array */
	};
	int si[SI_SIZE]; /* indexes of relevant stems */

	/* the bounds of the existing relevant stems */
	STEMBOUNDS r[ sizeof(si) / sizeof(si[0]) * 2 ];
	char rexpand; /* by how much we need to expand the group */
	int nr; /* and the number of them */

	/* yet more temporary storage */
	short lb, hb, isvert;
	int conflict, grp;
	int i, j, x, y;


	/* for each line or curve we try to find a horizontal and
	 * a vertical stem corresponding to its first point
	 * (corresponding to the last point of the previous
	 * glyph entry), because the directions of the lines
	 * will be eventually reversed and it will then become the last
	 * point. And the T1 rasterizer applies the hints to 
	 * the last point.
	 *
	 */

	/* start with the common part, the first point */
	x=ge->prev->ix3;
	y=ge->prev->iy3;

	if(*nextvsi == -2)
		si[SI_VP]=findstemat(x, y, ge, vs, vpairs, nvs, -1);
	else {
		si[SI_VP]= *nextvsi; *nextvsi= -2;
	}
	if(*nexthsi == -2)
		si[SI_HP]=findstemat(y, x, ge, hs, hpairs, nhs, -1);
	else {
		si[SI_HP]= *nexthsi; *nexthsi= -2;
	}

	/*
	 * For the horizontal lines we make sure that both
	 * ends of the line have the same horizontal stem,
	 * and the same thing for vertical lines and stems.
	 * In both cases we enforce the stem for the next entry.
	 * Otherwise unpleasant effects may arise.
	 */

	if(ge->type==GE_LINE) {
		if(ge->ix3==x) { /* vertical line */
			*nextvsi=si[SI_VP]=findstemat(x, ge->iy3, ge->frwd, vs, vpairs, nvs, si[SI_VP]);
		} else if(ge->iy3==y) { /* horizontal line */
			*nexthsi=si[SI_HP]=findstemat(y, ge->ix3, ge->frwd, hs, hpairs, nhs, si[SI_HP]);
		}
	}

	if(si[SI_VP]+si[SI_HP] == -2) /* no stems, leave it alone */
		return 0;

	/* build the array of relevant bounds */
	nr=0;
	for(i=0; i< sizeof(si) / sizeof(si[0]); i++) {
		STEM *sp;
		short *pairs;
		int step;
		int f;
		int nzones, firstzone, binzone, einzone;
		int btype, etype;

		if(si[i] < 0)
			continue;

		if(i<SI_HP) {
			r[nr].isvert=1; sp=vs; pairs=vpairs;
		} else {
			r[nr].isvert=0; sp=hs; pairs=hpairs;
		}

		r[nr].low=sp[ si[i] ].value;
		r[nr].high=sp[ pairs[ si[i] ] ].value;

		if(r[nr].low > r[nr].high) {
			j=r[nr].low; r[nr].low=r[nr].high; r[nr].high=j;
			step= -1;
		} else {
			step=1;
		}

		/* handle the interaction with Blue Zones */

		if(i>=SI_HP) { /* only for horizontal stems */
			if(si[i]==pairs[si[i]]) {
				/* special case, the outermost stem in the
				 * Blue Zone without a pair, simulate it to 20-pixel
				 */
				if(sp[ si[i] ].flags & ST_UP) {
					r[nr].high+=20;
					for(j=si[i]+1; j<nhs; j++)
						if( (sp[j].flags & (ST_ZONE|ST_TOPZONE))
						== (ST_ZONE|ST_TOPZONE) ) {
							if(r[nr].high > sp[j].value-2)
								r[nr].high=sp[j].value-2;
							break;
						}
				} else {
					r[nr].low-=20;
					for(j=si[i]-1; j>=0; j--)
						if( (sp[j].flags & (ST_ZONE|ST_TOPZONE))
						== (ST_ZONE) ) {
							if(r[nr].low < sp[j].value+2)
								r[nr].low=sp[j].value+2;
							break;
						}
				}
			}

			/* check that the stem borders don't end up in
			 * different Blue Zones */
			f=sp[ si[i] ].flags;
			nzones=0; einzone=binzone=0;
			for(j=si[i]; j!=pairs[ si[i] ]; j+=step) {
				if( (sp[j].flags & ST_ZONE)==0 )
					continue;
				/* if see a zone border going in the same direction */
				if( ((f ^ sp[j].flags) & ST_UP)==0 ) {
					if( ++nzones == 1 ) {
						firstzone=sp[j].value; /* remember the first one */
						etype=sp[j].flags & ST_TOPZONE;
					}
					einzone=1;

				} else { /* the opposite direction */
					if(nzones==0) { /* beginning is in a blue zone */
						binzone=1;
						btype=sp[j].flags & ST_TOPZONE;
					}
					einzone=0;
				}
			}

			/* beginning and end are in Blue Zones of different types */
			if( binzone && einzone && (btype ^ etype)!=0 ) {
				if( sp[si[i]].flags & ST_UP ) {
					if(firstzone > r[nr].low+22)
						r[nr].high=r[nr].low+20;
					else
						r[nr].high=firstzone-2;
				} else {
					if(firstzone < r[nr].high-22)
						r[nr].low=r[nr].high-20;
					else
						r[nr].low=firstzone+2;
				}
			}
		}

		if(ISDBG(SUBSTEMS))
			fprintf(pfa_file, "%%  at(%d,%d)[%d,%d] %d..%d %c (%d x %d)\n", x, y, i, nr,
				r[nr].low, r[nr].high, r[nr].isvert ? 'v' : 'h',
				si[i], pairs[si[i]]);

		nr++;
	}

	/* now try to find a group */
	conflict=0; /* no conflicts found yet */
	for(j=0; j<nr; j++)
		r[j].already=0;

	/* check if it fits into the last group */
	grp = gssentry_lastgrp;
	i = (grp==0)? 0 : egp[grp-1];
	for(; i<egp[grp]; i++) {
		lb=s[i].low; hb=s[i].high; isvert=s[i].isvert;
		for(j=0; j<nr; j++)
			if( r[j].isvert==isvert  /* intersects */
			&& r[j].low <= hb && r[j].high >= lb ) {
				if( r[j].low == lb && r[j].high == hb ) /* coincides */
					r[j].already=1;
				else
					conflict=1;
			}

		if(conflict) 
			break;
	}

	if(conflict) { /* nope, check all the groups */
		for(j=0; j<nr; j++)
			r[j].already=0;

		for(i=0, grp=0; i<egp[NSTEMGRP-1]; i++) {
			if(i == egp[grp]) { /* checked all stems in a group */
				if(conflict) {
					grp++; conflict=0; /* check the next group */
					for(j=0; j<nr; j++)
						r[j].already=0;
				} else
					break; /* insert into this group */
			}

			lb=s[i].low; hb=s[i].high; isvert=s[i].isvert;
			for(j=0; j<nr; j++)
				if( r[j].isvert==isvert  /* intersects */
				&& r[j].low <= hb && r[j].high >= lb ) {
					if( r[j].low == lb && r[j].high == hb ) /* coincides */
						r[j].already=1;
					else
						conflict=1;
				}

			if(conflict) 
				i=egp[grp]-1; /* fast forward to the next group */
		}
	}

	/* do we have any empty group ? */
	if(conflict && grp < NSTEMGRP-1) {
		grp++; conflict=0;
		for(j=0; j<nr; j++)
			r[j].already=0;
	}

	if(conflict) { /* oops, can't find any group to fit */
		return 1;
	}

	/* OK, add stems to this group */

	rexpand = nr;
	for(j=0; j<nr; j++)
		rexpand -= r[j].already;

	if(rexpand > 0) {
		for(i=egp[NSTEMGRP-1]-1; i>=egp[grp]; i--)
			s[i+rexpand]=s[i];
		for(i=0; i<nr; i++)
			if(!r[i].already)
				s[egp[grp]++]=r[i];
		for(i=grp+1; i<NSTEMGRP; i++)
			egp[i]+=rexpand;
	}

	ge->stemid = gssentry_lastgrp = grp;
	return 0;
}

/*
 * Create the groups of substituted stems from the list.
 * Each group will be represented by a subroutine in the Subs
 * array.
 */

static void
groupsubstems(
	GLYPH *g,
	STEM *hs, /* horizontal stems, sorted by value */
	short *hpairs,
	int nhs,
	STEM *vs, /* vertical stems, sorted by value */
	short *vpairs,
	int nvs
)
{
	GENTRY *ge;
	int i, j;

	/* temporary storage */
	STEMBOUNDS s[MAX_STEMS*2];
	/* indexes in there, pointing past the end each stem group */
	short egp[NSTEMGRP]; 

	int nextvsi, nexthsi; /* -2 means "check by yourself" */

	for(i=0; i<NSTEMGRP; i++)
		egp[i]=0;

	nextvsi=nexthsi= -2; /* processed no horiz/vert line */

	gssentry_lastgrp = 0; /* reset the last group for new glyph */

	for (ge = g->entries; ge != 0; ge = ge->next) {
		if(ge->type!=GE_LINE && ge->type!=GE_CURVE) {
			nextvsi=nexthsi= -2; /* next path is independent */
			continue;
		}

		if( gssentry(ge, hs, hpairs, nhs, vs, vpairs, nvs, s, egp, &nextvsi, &nexthsi) ) {
			WARNING_2 fprintf(stderr, "*** glyph %s requires over %d hint subroutines, ignored them\n",
				g->name, NSTEMGRP);
			/* it's better to have no substituted hints at all than have only part */
			for (ge = g->entries; ge != 0; ge = ge->next)
				ge->stemid= -1;
			g->nsg=0; /* just to be safe, already is 0 by initialization */
			return;
		}

		/*
		 * handle the last vert/horiz line of the path specially,
		 * correct the hint for the first entry of the path
		 */
		if(ge->frwd != ge->next && (nextvsi != -2 || nexthsi != -2) ) {
			if( gssentry(ge->frwd, hs, hpairs, nhs, vs, vpairs, nvs, s, egp, &nextvsi, &nexthsi) ) {
				WARNING_2 fprintf(stderr, "*** glyph %s requires over %d hint subroutines, ignored them\n",
					g->name, NSTEMGRP);
				/* it's better to have no substituted hints at all than have only part */
				for (ge = g->entries; ge != 0; ge = ge->next)
					ge->stemid= -1;
				g->nsg=0; /* just to be safe, already is 0 by initialization */
				return;
			}
		}

	}

	/* find the index of the first empty group - same as the number of groups */
	if(egp[0]>0) {
		for(i=1; i<NSTEMGRP && egp[i]!=egp[i-1]; i++)
			{}
		g->nsg=i;
	} else
		g->nsg=0;

	if(ISDBG(SUBSTEMS)) {
		fprintf(pfa_file, "%% %d substem groups (%d %d %d)\n", g->nsg,
			g->nsg>1 ? egp[g->nsg-2] : -1,
			g->nsg>0 ? egp[g->nsg-1] : -1,
			g->nsg<NSTEMGRP ? egp[g->nsg] : -1 );
		j=0;
		for(i=0; i<g->nsg; i++) {
			fprintf(pfa_file, "%% grp %3d:      ", i);
			for(; j<egp[i]; j++) {
				fprintf(pfa_file, " %4d...%-4d %c  ", s[j].low, s[j].high,
					s[j].isvert ? 'v' : 'h');
			}
			fprintf(pfa_file, "\n");
		}
	}

	if(g->nsg==1) { /* it would be the same as the main stems */
		/* so erase it */
		for (ge = g->entries; ge != 0; ge = ge->next)
			ge->stemid= -1;
		g->nsg=0;
	}

	if(g->nsg>0) {
		if( (g->nsbs=malloc(g->nsg * sizeof (egp[0]))) == 0 ) {
			fprintf(stderr, "**** not enough memory for substituted hints ****\n");
			exit(255);
		}
		memmove(g->nsbs, egp, g->nsg * sizeof(short));
		if( (g->sbstems=malloc(egp[g->nsg-1] * sizeof (s[0]))) == 0 ) {
			fprintf(stderr, "**** not enough memory for substituted hints ****\n");
			exit(255);
		}
		memmove(g->sbstems, s, egp[g->nsg-1] * sizeof(s[0]));
	}
}

void
buildstems(
	   GLYPH * g
)
{
	STEM            hs[MAX_STEMS], vs[MAX_STEMS];	/* temporary working
							 * storage */
	short	hs_pairs[MAX_STEMS], vs_pairs[MAX_STEMS]; /* best pairs for these stems */
	STEM           *sp;
	GENTRY         *ge, *nge, *pge;
	int             nx, ny;
	int ovalue;
	int totals, grp, lastgrp;

	assertisint(g, "buildstems int");

	g->nhs = g->nvs = 0;
	memset(hs, 0, sizeof hs);
	memset(vs, 0, sizeof vs);

	/* first search the whole character for possible stem points */

	for (ge = g->entries; ge != 0; ge = ge->next) {
		if (ge->type == GE_CURVE) {

			/*
			 * SURPRISE! 
			 * We consider the stems bound by the
			 * H/V ends of the curves as flat ones.
			 *
			 * But we don't include the point on the
			 * other end into the range.
			 */

			/* first check the beginning of curve */
			/* if it is horizontal, add a hstem */
			if (ge->iy1 == ge->prev->iy3) {
				hs[g->nhs].value = ge->iy1;

				if (ge->ix1 < ge->prev->ix3)
					hs[g->nhs].flags = ST_FLAT | ST_UP;
				else
					hs[g->nhs].flags = ST_FLAT;

				hs[g->nhs].origin = ge->prev->ix3;
				hs[g->nhs].ge = ge;

				if (ge->ix1 < ge->prev->ix3) {
					hs[g->nhs].from = ge->ix1+1;
					hs[g->nhs].to = ge->prev->ix3;
					if(hs[g->nhs].from > hs[g->nhs].to)
						hs[g->nhs].from--;
				} else {
					hs[g->nhs].from = ge->prev->ix3;
					hs[g->nhs].to = ge->ix1-1;
					if(hs[g->nhs].from > hs[g->nhs].to)
						hs[g->nhs].to++;
				}
				if (ge->ix1 != ge->prev->ix3)
					g->nhs++;
			}
			/* if it is vertical, add a vstem */
			else if (ge->ix1 == ge->prev->ix3) {
				vs[g->nvs].value = ge->ix1;

				if (ge->iy1 > ge->prev->iy3)
					vs[g->nvs].flags = ST_FLAT | ST_UP;
				else
					vs[g->nvs].flags = ST_FLAT;

				vs[g->nvs].origin = ge->prev->iy3;
				vs[g->nvs].ge = ge;

				if (ge->iy1 < ge->prev->iy3) {
					vs[g->nvs].from = ge->iy1+1;
					vs[g->nvs].to = ge->prev->iy3;
					if(vs[g->nvs].from > vs[g->nvs].to)
						vs[g->nvs].from--;
				} else {
					vs[g->nvs].from = ge->prev->iy3;
					vs[g->nvs].to = ge->iy1-1;
					if(vs[g->nvs].from > vs[g->nvs].to)
						vs[g->nvs].to++;
				}

				if (ge->iy1 != ge->prev->iy3)
					g->nvs++;
			}
			/* then check the end of curve */
			/* if it is horizontal, add a hstem */
			if (ge->iy3 == ge->iy2) {
				hs[g->nhs].value = ge->iy3;

				if (ge->ix3 < ge->ix2)
					hs[g->nhs].flags = ST_FLAT | ST_UP;
				else
					hs[g->nhs].flags = ST_FLAT;

				hs[g->nhs].origin = ge->ix3;
				hs[g->nhs].ge = ge->frwd;

				if (ge->ix3 < ge->ix2) {
					hs[g->nhs].from = ge->ix3;
					hs[g->nhs].to = ge->ix2-1;
					if( hs[g->nhs].from > hs[g->nhs].to )
						hs[g->nhs].to++;
				} else {
					hs[g->nhs].from = ge->ix2+1;
					hs[g->nhs].to = ge->ix3;
					if( hs[g->nhs].from > hs[g->nhs].to )
						hs[g->nhs].from--;
				}

				if (ge->ix3 != ge->ix2)
					g->nhs++;
			}
			/* if it is vertical, add a vstem */
			else if (ge->ix3 == ge->ix2) {
				vs[g->nvs].value = ge->ix3;

				if (ge->iy3 > ge->iy2)
					vs[g->nvs].flags = ST_FLAT | ST_UP;
				else
					vs[g->nvs].flags = ST_FLAT;

				vs[g->nvs].origin = ge->iy3;
				vs[g->nvs].ge = ge->frwd;

				if (ge->iy3 < ge->iy2) {
					vs[g->nvs].from = ge->iy3;
					vs[g->nvs].to = ge->iy2-1;
					if( vs[g->nvs].from > vs[g->nvs].to )
						vs[g->nvs].to++;
				} else {
					vs[g->nvs].from = ge->iy2+1;
					vs[g->nvs].to = ge->iy3;
					if( vs[g->nvs].from > vs[g->nvs].to )
						vs[g->nvs].from--;
				}

				if (ge->iy3 != ge->iy2)
					g->nvs++;
			} else {

				/*
				 * check the end of curve for a not smooth
				 * local extremum
				 */
				nge = ge->frwd;

				if (nge == 0)
					continue;
				else if (nge->type == GE_LINE) {
					nx = nge->ix3;
					ny = nge->iy3;
				} else if (nge->type == GE_CURVE) {
					nx = nge->ix1;
					ny = nge->iy1;
				} else
					continue;

				/* check for vertical extremums */
				if (ge->iy3 > ge->iy2 && ge->iy3 > ny
				|| ge->iy3 < ge->iy2 && ge->iy3 < ny) {
					hs[g->nhs].value = ge->iy3;
					hs[g->nhs].from
						= hs[g->nhs].to
						= hs[g->nhs].origin = ge->ix3;
					hs[g->nhs].ge = ge->frwd;

					if (ge->ix3 < ge->ix2
					    || nx < ge->ix3)
						hs[g->nhs].flags = ST_UP;
					else
						hs[g->nhs].flags = 0;

					if (ge->ix3 != ge->ix2 || nx != ge->ix3)
						g->nhs++;
				}
				/*
				 * the same point may be both horizontal and
				 * vertical extremum
				 */
				/* check for horizontal extremums */
				if (ge->ix3 > ge->ix2 && ge->ix3 > nx
				|| ge->ix3 < ge->ix2 && ge->ix3 < nx) {
					vs[g->nvs].value = ge->ix3;
					vs[g->nvs].from
						= vs[g->nvs].to
						= vs[g->nvs].origin = ge->iy3;
					vs[g->nvs].ge = ge->frwd;

					if (ge->iy3 > ge->iy2
					    || ny > ge->iy3)
						vs[g->nvs].flags = ST_UP;
					else
						vs[g->nvs].flags = 0;

					if (ge->iy3 != ge->iy2 || ny != ge->iy3)
						g->nvs++;
				}
			}

		} else if (ge->type == GE_LINE) {
			nge = ge->frwd;

			/* if it is horizontal, add a hstem */
			/* and the ends as vstems if they brace the line */
			if (ge->iy3 == ge->prev->iy3
			&& ge->ix3 != ge->prev->ix3) {
				hs[g->nhs].value = ge->iy3;
				if (ge->ix3 < ge->prev->ix3) {
					hs[g->nhs].flags = ST_FLAT | ST_UP;
					hs[g->nhs].from = ge->ix3;
					hs[g->nhs].to = ge->prev->ix3;
				} else {
					hs[g->nhs].flags = ST_FLAT;
					hs[g->nhs].from = ge->prev->ix3;
					hs[g->nhs].to = ge->ix3;
				}
				hs[g->nhs].origin = ge->ix3;
				hs[g->nhs].ge = ge->frwd;

				pge = ge->bkwd;

				/* add beginning as vstem */
				vs[g->nvs].value = pge->ix3;
				vs[g->nvs].origin
					= vs[g->nvs].from
					= vs[g->nvs].to = pge->iy3;
				vs[g->nvs].ge = ge;

				if(pge->type==GE_CURVE)
					ovalue=pge->iy2;
				else
					ovalue=pge->prev->iy3;

				if (pge->iy3 > ovalue)
					vs[g->nvs].flags = ST_UP | ST_EN<se {
					giority*pri;
			prib	vs[g->nvs].f {
					giority*pri;
			p
					s[i+1 		giority*pri;
		!p[g->	}

				if (ge->ge->frwd;

				}
->bkwd;

				/* add beginning as vtem */
				vs[g->nvs].value = pge->ix3;
				vs[g->nvs].origin
					= vs[g->nvFLAT;

				vs[g->nvs].origin = ge->iy3;
				vs		ny = ngenvs].ge = ge;

				if(pg
					nx = ngeRVE)
					ovalue=
					nx =se
					oonlps == f (ge->iy3 != 			if (pge->iy3 > ovalue)
					vs[g->nvs].flags onlps =< f (ge->iy3 != 			if (pge->iy3 > oval	vs[g->nvs].f {
					giority*pri;
			p
					s[i+1 		giority*pri;
		!p[g->	}

				if (ge->ge->f		if (ge->ix3 != ge->ix2)
					g->nhs++;
			}
			/* if it  horizontal, add a hstem */
			/* and the ends as if it is vertical, add a vstemAT;
					 			if (ge->iy3 == ge->prev->iylse if (ge->ix1 == ge->prev->ix3) {
				hs[g->nhs].ge = ge-e = ge;

				if (ge->iy1 < ge->prev->ix3) {
					hs[g->nhs]nvs].from--;
				} else {
					vs[g->nvs].from = ge->prev->i			hs[g->nhs].to = geST_FLAT | ST_UP;
				else
		>nhs]nvs].from--;
				} els			vs[g->nvs].from = ge->prev-e {
					vs[g->}			vs[g->nvs].value = >nvFLAT;

				vs[g->nvs].origin = ge->iy3;
				hs[g->nhs].ge = ge->frwd;

				pge = ge->	/* if it isge->ix3 != ge->prev-s].from
					=->nhs].to = ge->i].origin[g->nhs].value = ge->y3;
					hs[g->s vstem */
				vss].origin = ge->prev->ix3;
				vs[g->nvs].ge = ge;

				if(pge->typx==GE_CURVE)
					ovalue=pge->iy2;
		x	else
					ovalue=x | ST_EN<se {
							    || nx < ge->ix3))
					vs[g->nvs].flags = ST_Uxge->prev->iy3;

					    || nx < ge->ix	vs[g->nvs].f {
			flags = ST_UP;
					else
			hs[g->nhs].to =i;
		!p[g->	}

				ifh(ge->ge->frwd;

				}
->	/* if it isge->ix3 != ge->prev-].from
					=->nhs].to = ge->i].origin[g->nhs].value = ge->y3;
					hs[g->s vFLAT;

				hs[g->nhs].origin = ge->ix3;
				hs		ny = ngenvs].ge = ge;

				if(pg
					xx = ngeRVE)
					ovalue=
					xx =se
					oonlps =->ix3 < ge->ix2
				    || nx < ge->ix3))
					vs[g->nvs].flags onlps == f (ge ge->ix2
				    || nx < ge->ix	vs[g->nvs].f {
			flags = ST_UP;
					else
			hs[g->nhs].to =i;
		!p[g->	}

				ifh(ge->ge->fge->iy1 != ge->prev->prenvs++;
			} else {

ds as
				 * check thf curv>prenvshorizontal af it is if (ge->type == GE_		 */
				nge = ge>frwd;

				i (nge == 0)
					continue;
				else i (nge->type == GE_LNE) {
					nx = ng->ix3;
					ny = nge->iy3;
				} else if(nge->type == GE_CUVE) {
					nx = ng->ix1;
				ny = nge->iy1;				} else
					continue;

				/* checs[g->nhs].ge = ge-e = ge;

ms */
				if (ge->iy > ge->iy2 && ge-e = ge;

ms */
				if| ge->iy3 < e->ix3 != ge->prev-].from
					=->nhs].to =lue = ge->y3;
					hs[g->= ge->y3;
					hs[gags = ST_FLAT;

				hs[g->nhs].origin = ge->ix3;
				hs[g->nhs].ge = geiy2;
		x	
								if (ge->ix3 < ge->ix2
				    || nx < ge->ix3)
					s].f {
			flags = ST_UP;
					else
			h	hs[g->nhs].flagsAT;
					 ;

					if (ge->ix3 != 		if (ge->ix3 != ge->prenvs	g->nhs++;
				}
				/*
				 * the same p				conti>prenvshorizontal af it is vertical extremum
				 */
				/* check or horizontal extrAT;
					 s */
				if (ge->ix > ge->ix2 && ge-AT;
					 s */
				if| ge->ix3 <  add beginning as vtem */
				vs[g->nvs].va>nvs].origin
					= vs[g-].origin
					= vs[ags = ST_FLAT;

				vs[g->nvs].origin = ge->iy3;
				vs[g->nvs].g = ge-e = ge;


								if (ge->iy3 > ge->iy2
				    || ny > ge->iy3)
					s].f {
					giority*pri;
			p
					s[i+	vs[g->nvs].flagse = ge;

m;

					if (ge->iy3 != ge->iy1 != ge->pr
			fpr		if (=;

*pairizeof
	g-		if (s = 
	STrizeof
	g-		if (s = 
	STrizeofv	g-		ifeof hs)i+	vsg=i;
					}
			last=rizeof		ifnes, 
	g-		if (entry(		ifeof hs) */
				retuastgrp;

tep=1;= gast pointon't end up in
mark*pairizeof
	g-		if (s =ge->ssub enouentries; gstzone+2;
				}
			}
		}

		if(ISDBG(SUBST%s: e it;= gr, "*stems(
	GLYPH *g,%% %d subnessg<NST italic angl ) {
/
	shorg-		if (enat(y,	 findstemat() ) {
/
	shorg-		if ()high=sp gstzone+2;
				}
			}
		}

		if(ISDBG(SUBST%s: e it;= gr, "*spairs,
	int nh%% %d subnessg<NST italic angltry(g/
	shorg-		ifset(h)high=ubs
 * array.
g2) ) {
/
	shorg-		if (entry(g/
	shorg-		ifse
		prevwsp gstzoneMAIN
				}
			
		}

		if(ISDBG(SUBST%s: e it;= g/* ittems(
	GLYPH *g,%% %d subnessg<N		if (		pe it/* irizeof
	g-		if (enat(y,sp gstzoneMAIN
				}
			
		}

		if(ISDBG(SUBST%s: e it;= g/* itpairs,
	int nh%% %d subnessg<N		ifse		pe it/* irizeofvrg-		ifset(h)highsp gstzoneMAIN
				}
			last=rizeof		ifnes, 
	g-		if (entry(		ifeof hs)->stemi (	 -= r[j].sp g(s/vereof(shog->sbst
			DS r		if ()(egp[g>nsg-1] * sizeof (s[0]))) == 0 ) {
			fprintf(stder enough memory for substituted hints		ihstem *=  sizeorincpy(Retue->ix3>sbst
			DS r		if ();gp[i-1]; i++)
hstem *= 0 hs)->stemiv(	 -= r[j].sp g(s/vereof(shog->sbst
			DS r		ifv()(egp[g>nsg-1] * sizeof (s[0]))) == 0 ) {
			fprintf(stder enough memory for substituted hints		ivstem *=  sizeorincpy(Retuv->ix3>sbst
			DS r		ifv();gp[i-1]; i++)
vstem *= 0 hs), pairseak;
						}
				}
s wflat stdeflsult: to >= e =>= 's[si]; stacki=b-1; of to >= e =>= s (f steX11) pushi, j);
		}
	nin thech	/* ce po=b-1; tackme p	pop/
	inttitutt
	 */ sizeof vsWARNIs				

	/* nodse unplea     n = stemi (+		ifv()
				 e priocouhas of vs	exit(20 ) halv up in
 horiz/ver-1;ter for possible stem points */

	for (ge = g->entrie			rge =ge != ;
 firstz/vT_UPy empty  */ horiz/) xtvsi != 	grp = y3 !=     n +g, "busbems,				i (ngy3 !=     n +g, "busbem			i -, "busbem			grp;
y3 !nd;
	}

	ge->ste forward tobe But we-1;
	
			c,ertical extT_U(20 ) > - same      n >ereox_ge !deptue;
 .already=0)
 *dee* fast p, &nextvssg-1] * sizeof (s[0]))Wart;= :	WARNING_2har s "*** gtackmdeptuem[i], x		ifnes,      nfa_file* sizeof (s[0]))  (f miEMS)):
		returnr about it later enoug;
			iti], xeox_ge !deptueed hints->stemid=(c - b) - ( all than have only part */
			for (ge = g->entries; ge != 0  ge = ge-fren");
			exit); );
			exit ] = 0;
-fren");
usbe); );
usbe ] = 0;
-temid=(] = 0;
e);
			putc('\r; j++)
	s[MAX}
			)
 * retu/* it would be      n = stemi (+		ifv()
				 e priocouhas of vs	exit(20 ) halv up in
me      n >ereox_ge !deptue;
 
is venumbeworirs[s
 * 2 ];o /* n-
}

/*
 * Create tfast p, &nextvssg-1] * sizeof (s[0]))Wart;= :	WARNING_2*/
	%dg/* ittenoui], x		ifnes,      nfa_file* sizeof (s[0]))  (f miEMS)):
		returnr ab enoug;
			iti], xeox_ge !deptueed hints->stemvstem  b) - ( ren");
v	exit); );
vstem *= 0 , "buildstems hints->stemhstem  b) - ( ren");
h	exit); );
hstem *= 0 , "buhs(] = 0;
e);
	nue;
	ny j].loweirdnd by th					
			cloif(isbnd thee poind th.
nple>nsg-fstraightenf(s[0]));
	}
}

void
stems */
	STEM       p         *si;
	GEdouh thhhhhhhhhhdhortNTRY         *ge
)
{
	douh thhhhhhhhhhiln, olnortNTRY         *gesvde
		i, o;ter for ithan have only pairt */
			ithan ige = g->entriesp giny = nge-!iy3;
				} 
			ny = nge->iy1than ige 0;
hs[g->nhs].ge = is if (ge->type == GEdf(] =.;nitial or dse
					continiy3)
tems(
	GLYP /* nope,p[g->ns21 );
		j=0;
>s v!TEMGRPthe X11xi the int	ilns vfags)e->tyle cha			}2i -,pe->tyle cha			}2ifa_filolns vfags)e->tyle cha	o	}2i -,pe->tyle cha	o	}2ifa_file->prenvsi

			 end 				/*er al
				aE_LINE) {
		if,	 * wil>prenvs * afor t		pgi, jlse tems(
	GLYtut(rizontale = / g->>prenvsds as * afor e itheck thtut?)al af it is	hs[olns< 1.->ix > ge->yle cha	o	}2i a vstemyle cha	o	}1] ->ix > ge->yle cha	o	}0i a vpe->tyle cha	o	}2i->ix > ilns> 2.->ix > ilns> 1. y emiln/olns> 0.1 e = ge>frwd;

		= GE_		vsg=i;
		RAIGHTEN)nflict=e* sizeof (s[0]))  straighten al
				%ui], x(i? "tems(
	GLY":"_LINE) {")dir = (df(] e->tyle cha			}2i -,pe->tyle cha			}2ia_fil
		forf, or)e->tyle cha	o	}2i -,pe->tyle cha	o	}2ifa_filny = nge->inue;
		->iy1;		>prenvssuj++)nue, i, j);equencen 0;
} ];al
				 becausrenvse;
				/* if see a zone borde RE0 ) devi/*
 *>prenvs	
 *farg;
						conti>prenv/int	ilns vfags)ne->tyle cha			}2i -,e->tyle cha			}2ifa_filolns vne->tyle cha	o	}2i -,e->tyle cha	o	}2i->iy1; now  (fags)df)* in5y em	ny = nge->iy3;
				}iy1; em
		foorf, or)oln)}
				r to so giy tholns!p[g-.isvert==ilns in2.->ix==0
	ilns in1. y > iln/fags)oln)}<= 0.1 evs, s, ege->tydd avne->ty/
				vse->tyyd avne->tynx =se
				vsg=i;
		RAIGHTEN)ny3 != e* sizeof (s[0]))  straighten col && 
			%ui], x(i? "tems(
	GLY":"_LINE) {")dir	- ( renrn 1ge)ne-dir	- ( ixlseint (e-dir	- (hs[g->nhs].ge = is			 * local extremum
		df(] e->tyle cha			}2i -,pe->tyle cha			}2ia_se
			lns vfags)ne->tyle cha			}2i -,e->tyle cha			}2ifa_fillolns vne->tyle cha	o	}2i -,e->tyle cha	o	}2i->	
					}
			c('\r; j++w	r t the next grsonding to/ g-> -2; /* prots->ste-!iyp			co se
				v pny = nge->iy3;
 ge->nexpe->tyle cha			}2i a vpe->te = geyle cha			}2ise
		nexfags)pe->tyle cha	o	}2i-!iyp		>te = geyle cha	o	}2ifj].low <= hb sg=i;
		RAIGHTEN)nfe* sizeof (s[0]))  straighten e ithast pnding to terseon at v=alue, origin, (p		value, origin, (e-dir	- (
			jf(") %d\nding to -2; /ast p			 end r[j].higpe->tydd ave->ty/
				vsgpe->tyyd ave->tynx =se
			ithan  renrn 1ge)e-d>te = EMGRPkee* t: to
tept
			alid r[j].higgrev-s].				vsg ixlseint (e-dir	- ((hs[g->nhs].ge = is		NE;
					}
->ste-!iyn			co se
				= 0)
					continue;
		y em	ny =yle cha			}2i a vny =yle cha			}2ise
		nexfags)ne->tyle cha	o	}2i ! vstemyle cha	o	}2ifj].low <= hb sg=i;
		RAIGHTEN)nfe* sizeof (s[0]))  straighten e ithast p g-> terseon at v=alue, origin, (		value, origin, (ne-dir	- (
			jf(") %d\ g-> -2; /ast p			 end r[j].hige->tydd avne->ty/
				vsse->tyyd avne->tynx =se
		( renrn 1ge)ne-dir	- (g ixlseint (e-dir	- ((hs[g->nhs].ge = is				 * local extremum
		NE;
					}
->ste-!iyp			co se
		
			si[i]]aligntry), beca1; /*ec;

	 */
		SI_}
->sdf(!p[g.ny3 != ecloifgap		congx %d)\df, NULL) = ng->ix3;
{se
		
		>frwour			/*
she ste* at all 		if,	 oririe {

id r[j].hiithan  renrn 1ge)e-dEMGRPkee* t: to
tept
			alid r[j].hi; i<
				nge}
				er w==1) { urn;
>frwour	r[j].highis 0 by in	ithan ige =e = EE;
					}
[j].alread* for the subor d
 * Make althe X11xi the ;
e);
	nue;
	solt gr squ
			equsafe,,* (called frhe first emptysoluglyph /
	cos[si[isoluglyphted bye	/* tigin,e */+w	itherh	}
	};
				i]]a*/
		rettwsbasuh tter ts; /*rizoin <f miEMlone *eastderroluglyphtedreset to 0 forfsqequsafe,(
	douh tha,
	douh thb,
	douh thc,
	douh th* */,
	douh thmndstedouh thmax
void
douh thDortNTRYn
		g->nsg=i;
	QEQ)nfe* sizeof (s[0] "sqeq(%g,%g,%g) [%g;%g]t v=aa,hb,hc, -1 meansf hs)->sfags)a)		in.00000le, "\n")fgr dered bequsafe,the ;
nEMGRP ->sfags)b)		in.00000le,wd; /**ribequsafe,tr to haalready is 0 = 0;
 */[0] = -c/bGRP ->ssg=i;
	QEQ)nfe* sizeof (s[0] "sqeq: dered bt=%gt v=a */[0]bs, egp, */[0] >ere /*lb )*/[0] <ereoxny3 !n1 != gy is 0 n		prevwD = b*b -,4.0*a*c;	g->nsg=i;
	QEQ)nfe* sizeof (s[0] "sqeq: D=%gt v=aDt(y,sp(Dher si no stems, lD = sqrt(Df hs)nEMGRP */[0] = (-b+D)
		(2*a);	g->nsg=i;
	QEQ)nfe* sizeof (s[0] "sqeq: t1=%gt v=a */[0]bs, gp, */[0] >ere /*lb )*/[0] <ereoxny3 nge->ge)*/[n] = (-b-D)
		(2*a);	g->nsg=i;
	QEQ)nfe* sizeof (s[0] "sqeq: t2=%gt v=a */[n]bs, gp, */[n] >ere /*lb )*/[n] <ereoxny3 nge->ge/(called  2end oluglype* at ix2)
'sng and end {
			fp in
me n==x3 > fags))*/[0]-)*/[1])<n.00000le ;
nE1->ge)*is 0 n		nue;
	nak;
						}
		d by th* for cross qusdr;

	/* bu */
		S;
	(float)edresy_la HMAX}*
	 * For the hori}
		d by s * a; /**>frwd;


	/* la tems(
	GLYP
					continue;

				.e pixertical prime char *ela explaere=finf" */
) {e char *e Eachnalogy.
la  pixertical prime char *e+w	erevious
erivsafvela dy/dx*er equslnt gs.urvesointoeziernd by therus
efere= Eala t
gssenro 0ndstuurnla  x=fx(t)la  y=fy(t)la s]]);

	}

	if( 
erivsafve				

	/**/
nodse  A so numbeix2weer end of };
				(x,y) s/**t*
 * Make 			tem co 				fargalue-bng to.thsitun
noat riocribprevdy/dt(] =  irizad,* urn 1;
ee T1 ra ept<0)
			/*  squ
			equsafe,e same/**t*
 *
 tr to knve ting asrett							/* .
la  pixndstuurnheru:
la E) {A*(1-t)^3 + 3*B*(1-t)^2*t + 3*C*(1-t)*t^2 + D*t^3la E) {(-A+3*B-3*C+D)*t^3 + (3*A-6*B+3*C)*t^2 + (-3*A+3*B)*t + Ala dy/dt(] 3*(-A+3*B-3*C+D)*t^2 + 2*(3*A-6*B+3*C)*t + (-3*A+3*B)tedres>nsg-f ixqusdr;

.
 */

stati
void
stems */
	STEM       n;
	GENTR	vert;
np, oldnp{
	douh t	sp[5[MAX_Se/**time cha;
	int all /* fin}

	/f(sidir[5[MAX_Stderlast=g
 *,a zone bordey+w	ither/**tihappere= }

	douh tha,hb,h*pt binarme charofgr 	}
			/* er for possible stem points */

	for (ge = g->entries; ge != 0; g!iy3;
				} 
			ny = nge->		
	doagaer: ;
n/vert lineP);
/**time chanflict=0;g->nsg=i;
QUAD)>nsg-1] * sizeof (s[0]))%s: 	si
 * terse(%g %g) (%g %g) (%g %g) (%g %g)\nrintf		ifnes,y in	lue, origin, (		vaflagse = gefi=si[SI_e = gefi=si[SI_Vx1si[SI_Vy1si[SI_Vx2si[SI_Vy2,s, ege->tyddsi[SI_Vy3eed hintsope,p[g->ns21 );
		j end into  forxniy3)
 for/
		SI_} */
				retucortidn
noarofgny =rolole charactI_}a->prev-e {
		yle cha			}2ia_filpt ->p&ny =yle cha			}0ia_se
	oldnp avn>ste 
n/v+orf,qequsafe,(
				3.0*(-a + 3.0*pt [0] - 3.0*pt [1] + pt [2if,s, eg6.0*(a - 2.0*pt [0] + pt [1if,s, eg3.0*(-a + pt [0]f,s, eg&sp[np].valuen.0, 1.0dEMGRPXXXon the				[0;move prots->snp a= oldnpe = ge>frwd;

		=	;g->nsg=i;
QUAD)>lict=e* sizeof (s[0]))%s: ters:	%dgpt (%c):intf			vsse	ifnes, lue, origin, (		vanp-oldnp %d? 'y':'x')->iy1;					retuole char					
				
 *cloif(isbntal, add>prenvsthe prevertthsi= , add 			permiEte=fio so>prenvsi

si[is/**time ch				VEs *cloif(isbntal, ad>prenvst RE0 ) exactlyniy3)
->ste		 *ten _HP]			;
	}

	gaer
			 * ot	MGRP-1) = oldnpoup *p:      ", i);dir[j] = est[dir->nsg=i;
QUAD)>lict==e* sizeof (s[0]))%gintf(
			)st[dir->n(
					in.03		j end rontvs++;
			}
			/* the	first entle cha			}0is].flagse = geyle cha			}2if=0 ) {
		t entle cha			}0is>prev-e {
		yle cha			}2ia_fildir->nsg=i;
QUAD)>fe* sizeof (s[0] "		 *ten			itd rontmory for 
		totsbas	gaer for 
	} the	firsvny =yle cha			}1i ! vstemyle cha			}0i the	f > f, or)e->tyle cha			}2i -,e->tyle cha			}1iffor 
			!orf, or)e->tyle cha			}1i -,e->tyle cha			}0ifj].low <= 	t entle cha			}1](] e->tyle cha			}0ia_fildir->nsg=i;
QUAD)>fe* sizeof (s[0] "		 *ten			zigzag	itd rontmory for 
		totsbas	gaer for 
	} the	f(
				=f(
		+1; inp--w-=20;
ildir->nsg=i;
QUAD)>fe* sizeof (s[0] "( rontv		 *)rin],
					s, vpairs(
				> 0.97		j endred be++;
			}
			/* the	first entle cha			}1i ! vstemyle cha			}2if=0 ) {
		t entle cha			}1](] e->tyle cha			}2ia_fildir->nsg=i;
QUAD)>fe* sizeof (s[0] "		 *ten			itdred mory for 
		totsbas	gaer for 
	} the	firsvny =yle cha			}0i ! vstemyle cha			}1i the	f > f, or)e->te {
		yle cha			}2i -,e->tyle cha			}0iffor 
			!orf, or)e->tyle cha			}0i -,e->tyle cha			}1ifj].low <= 	t entle cha			}0](] e->tyle cha			}1ia_fildir->nsg=i;
QUAD)>fe* sizeof (s[0] "		 *ten			zigzag	itdred mory for 
		totsbas	gaer for 
	} the	f(
				=f(
		+1; inp--w-=20;
ildir->nsg=i;
QUAD)>fe* sizeof (s[0] "(red b		 *)rin],
					s
 
	} the->nsg=i;
QUAD)>fe* sizeof (s[0] "');
			}
	
ts->snpite dineP);
/**time chaP]+si[SI_HP] == -2) /*ype, etype;

		ifsg=i;
QUAD)>nsg-1] * sizeof (s[0]))%s: s/**t*
 * terse(%g %g) (%g %g) (%g %g) (%g %g)	itd%	};
			s\nrintf		ifnes,y in	lue, origin, (		vaflagse = gefi=si[SI_e = gefi=si[SI_Vx1si[SI_Vy1si[SI_Vx2si[SI_Vy2,s, ege->tyddsi[SI_Vy3vanpfa_file, "-)
			s[p i<NSTEMGR=e* sizeof (s[0]))%g(%c)intf(
	nr].dir[i] ? 'y':'x')->GR=e* sizeof (s[0]))');
			}
	
ts;
	sort		 *
			 *dd ace

	}

 /* nope,p[g->ns[p i<NSTEMGRthis gi[nr].hipt=s[i].isvert;(
	nrPZONE) )].low <= a	=f(
	3d: (
	nrP=f(
		d: (
				=fa= is		NE
}
			c('\
		LYtut not or
/**ti	nin theith the co this group *p:      ", i)douh thk1sik2sic->iy1;k1P=f(
		d:iy1;k2 _UP)-hk1		=	;g->nsg=i;
QUAD)>fe* sizeof (s[0] "EM terse%g/%gt v=alue, origin, (		vak1sik2)->iy1;	 * lonewg| nextGEF_FLOAT)->GR=(*n			c {(*e-dir
#
efere SPLIT(pt1sipt2)	( (pt1) + k1*((pt2)-(pt1))j].lowontinutvsiAX_St;

!* ot	MGRP-1p[g->ns21 );
		j end forxn]			/
		SI_}
a(] e->tyle cha			}0ia endg

	gssemid/
		le charactI_}	b(] e->tyle cha			}1ia_se
		
		>alc* Blue0; /o >= nalole charactI_}	cge->PLIT(a,hb)->ge->fg entle cha			}0](] >PLIT(e->te {
		yle cha			}2ifio);ge->fg entle cha			}1](] >PLIT(e->ttle cha			}0]sic)->ge->f	ny =yle cha			}1](] >PLIT(b,h	ny =yle cha			}2i);ge->f	ny =yle cha			}0](] >PLIT(c,h	ny =yle cha			}1])->ge->fg entle cha			}2](] >PLIT(e->ttle cha			}1].value	+h	ny =yle cha			}0]bs, e	NE#un
ef >PLIT>ge->addget
	 *		conne-diriy1;			go		i=egp[grp]- */

	ad->ste		rait;= gle charactI_} * lon].				vRP-1p[js[egp[[p i<NSTEMGR=(
	nrP=f;(
	nr-kle,wik2 0;
e);
		nue;
	nak;
	ifgr 	}
			er a	zigzag	dreset to 0 foriiszigzag(*/
	short *v
) oid
douh thhhhhhhhhhkvak1sik2ortNTRY         *gea,hbhighsp ge != 0; g!iy3;
				} 
		 no stems, la(] e->t = 0- e->t = = gb(] e->t>ix3- e->t == GE->naegp[g>nsg-1->nbegp[g>nsg-1]y is 0 = 0;
->ix1;
			k(] FBIGVAL;gp[i-1]; i+ks vfags)(douh t) b
		(douh t) a)s, la(] e->t =13- e->te {
					vs[b(] e->t>i13- e->te {
			/
			->naegp[g>nsg-1->nbegp[g>nsg-1]y is 0 = 0;
->ix1;
			k1(] FBIGVAL;gp[i-1]; i+k1s vfags)(douh t) b
		(douh t) a)s, la(] e->t =30- e->t =2vs[b(] e->t>i30- e->t x==GE->naegp[g>nsg-1->nbegp[g>nsg-1]y is 0 = 0;
->ix1;
			k2(] FBIGVAL;gp[i-1]; i+k2s vfags)(douh t) b
		(douh t) a)s, l/vsi

si[i	}
			er  /**r	zigzag	drehsp gk1+n.0001 >erk3 > k2s<erk+n.0001 ||ak1s<erk+n.0001  > k2+n.0001 >erk 
		 no stems,i (ngy3 n't find anue;
	nak;
	ifgr 	}
			er a	zigzag	- float	}

 /*set to 0 forfiszigzag(*/
	short *v
) oid
douh thhhhhhhhhhkvak1sik2ortdouh thhhhhhhhhha,hbhighsp ge != 0; g!iy3;
				} 
		 no stems, la(] fags)e->ty= 0- e->tVy1)vs[b(] fags)e->tyix3- e->tVx1)=GE->nae< FEPS>nsg-1->nbe< FEPS>nsg-1]y is 0 = 0;
->ix1;
			k(] FBIGVAL;gp[i-1]; i+ks vb
		as, la(] fags)e->ty=13- e->te {
		Vy3eed b(] fags)e->tyi13- e->te {
		Vx3)=GE->nae< FEPS>nsg-1->nbe< FEPS>nsg-1]y is 0 = 0;
->ix1;
			k1(] FBIGVAL;gp[i-1]; i+k1s vb
		as, la(] fags)e->ty=30- e->tVy2eed b(] fags)e->tyi30- e->tVx2)=GE->nae< FEPS>nsg-1->nbe< FEPS>nsg-1]y is 0 = 0;
->ix1;
			k2(] FBIGVAL;gp[i-1]; i+k2s vb
		as, l/vsi

si[i	}
			er  /**r	zigzag	drehsp gk1+n.0001 >erk3 > k2s<erk+n.0001 ||ak1s<erk+n.0001  > k2+n.0001 >erk 
		 no stems,i (ngy3 n't find anue;
	
/**tisi[izigzag-f sted by thi poinwo- */
sedres>nsg-f
/**tzigzagof(s[0]0]));
	}
}

void
stems */
	STEM       n;
	GEdouh thhhhhhhhhha,hb,hc, dalue;
	int tfloatls, gs/**t*
 * zigzago;
			 for possible stem points */

	for (ge = g->entries; ge != 0; g!iy3;
				} 
			ny = nge->
	l/vsi

si[i	}
			er  /**r	zigzag	drehes; g !fiszigzag(			c>nsg-1]next path is indepensg=i;
FCONCISE)  ", i)douh thmaxsc1,hmaxsc21 >GR=e* sizeof (s[0]))
/**tir	zigzag	n],
			fnorm be ege)e-dE=	;g->n fcrossray1ge)e-ongx %&maxsc1,h&maxsc2, NULL)j].low <=e* sizeof (s[0]))
c1=%g sc2=%gt v=amaxsc1,hmaxsc2) = ng->ix3;
{se
		e* sizeof (s[0] "(ray1h* for cross)mory for ->pr
			;
	
/**tisi[i	}
			 * W=0.5the ;
n * lonewg| nextGEF_FLOAT)->GR(*n			c {(*e-dir>f	ny = nge->inue				}->
	la->prev-e {
		y/
				b(] e->ty== GE_c(] e->ty=2 0;
d ave->ty/
				ne->ty/
 avd				ne->ty/2s v(c + d)
			.				ne->ty/1s vnbe+		.nvs+ + d)
		4.				e->ty/
 av(a + bnvs3. + cnvs3. + d)
		8.				e->ty/2 av(a + 	.nvsbe+	c)
		4.				e->ty/1 av(a + b)
			.		
	la->prev-e {
		yy
				b(] e->tyy= GE_c(] e->tyy2 0;
d ave->tyy
				ne->tyy
 avd				ne->tyy2s v(c + d)
			.				ne->tyy1s vnbe+		.nvs+ + d)
		4.				e->tyy
 av(a + bnvs3. + cnvs3. + d)
		8.				e->tyy2 av(a + 	.nvsbe+	c)
		4.				e->tyy1 av(a + b)
			.		
	laddget
	 *		conne-diriy1pensg=i;
FCONCISE)  ", i)dumpint .
g2)	conne-dir;
e);
	nue;
	 renurn 1;stems ,called frw	r tw==1ge = g->r ts posm>stebasrettnge-nue;
		yfor3;
				} 
 ts], v}
	ni*
			float	 * win* corrm ptedreset to 0
	short 
 renrn 1ge)*/
	short *v
)e */
	short xprev->s; ge !=.ge s].flagse =   ", irwd;t.
			 */

			/retucorwour	r[j, ixs[g->nhs].ge = ispenx
				n			co e pr==1) { * at lill be >frwour	r[j].h					retuoretucorwour	

	/* nol/
		SI_} */e =   1;st_MOVEt egp[  1;st_PATH,			retuoretmto haalrSI_} */}
				/		}

	}

	corwour,niy3)
!=.ge sle char	o>nhs]corrm pf it is	hsrev-e {
		e =  		nge = ge*(
	short *)srev-e {
		.ge )r (ge = g-> = g-> for  (ngy3 !=rev-e {
		e =  = g->r (ge = g-> = g-> ft is	hsrev- g-> = g->s, s, ege->t g-> = g->		e =  	 rev-e {
		e = ;s, ege->t g-> = g->		.ge s	 rev-e {
		.ge = is					}
xfor (ge = g-> = g-> for  ren")agse =  ;  ren")ags g->s;  ren")ay for n't finxgth is inde */}etuoretuet rtime ch			/retucorwour	r[j	first entype)!=0GEF_FLOAT), s, erev-e {
		y/
r (xe->ty/
					rev-e {
		yy
r (xe->tyy
				->ix3;
{se
	e->te {
			/
r (xe->ti/
					rev-e {
		iy
r (xe->t;

				}
		s, vpairse->tyry of the path
  ", irwd;t.e++;
		retucorwour	r[j, ixs[g->nhs]yry 		e = ;s,  */}etuoretuet rtime ch			/retucorwour	r[j	first entype)!=0GEF_FLOAT), s, exe->ty/
g->nhs].ge >ty/
					xe->tyy
g->nhs].ge >tyy
				->ix3;
{se
	xe->ti/
g->nhs].ge >ti/
					xe->tiy
g->nhs].ge >t;

				}
		

	rev-e {
		 g->r (ge = g->;
ge->t g-> =e =  	 rev-e {
;
ge->t.ge >tyre s	 rev-extrem	nhs]yry 		.ge s	 rev-.ge = gexfor (ge = g->			 ren")ay fon't finxgth nue;
	y=0;
	r a	0; /*correc(;
		yfor				} et
	 */anthe X1(MOVE
 tsfor;
		yfor				} 
 line of ts/		}

	}

	st_MOVE1; /*ec;

	 */ubroutine in the Saddget
	 *	*/
	short o	conrwd;
	 */ si the ;
	short n * eady=0;
		 si the )e */irsony = nge->=	st_MOVE  ", irwdy=0;
		be fop[grp]-r[j	firsoe->t g-> = nge->=	st_PATH), s, eend into  * w* at 
	shortbe he la it is if>tyre s	 ne !=.ge slon].				->ix3;
{se
	 if>tyre s	 oge = g->			
	 if>t.ge slooe->t g-> =.ge = is	oe->t g-> =.ge >tyre s	 ne = is	oe->t g-> =.ge slon].				-
	->ix3;
{se
 if>tyre s	 oge =extrem		 if>t.ge slooe-em		onhs]yry 		.ge s	 ne-em		onhs]yry s	 ne-em		

	ne->t g->s	 oge = g->			nrev-e {
slooe-em	oe->t g-> =e =  	 ne-em	oe->t g-> 	 ne-em
	hs		ny =yry 		e =  = nge->=	st_MOVE  ", irwdfix u* t: tst_MOVE1correcr[j	firsnt entype)!=0GEF_FLOAT), s, e	ny =yry 		e =  =ydd avne->ty/
				v	ny =yry 		e =  =yyd avne->tynx =		->ix3;
{se
	 if>tyre >te {
			/
r (->type == GE_ if>tyre >te {
			yd avne->t;

				}
		
ntry_lastg; j++)
	s[ 1;stems ihappersemid= -a indexes i		/int f horizofix 		}

	}

	MOVETO acne 
	}
l/ubron */
	si*
			 ch	rizofloatubroutine in the S ixlseint (*/
	short *v
)e */
	short me-em
	ms[g->nhs]yry 		e = ;s,irsmny = nge->=	st_MOVE  ", iirst entype)!=0GEF_FLOAT), s, eme->ty/
g->nhs]y/
				vme->tyy
g->nhs]ynx =		->ix3;
{se
	me->ti/
g->nhs]i/
				vme->tiy
g->nhs];

				}
		
ntry_lastT[ 1;fune bordad->sts/		}
rEMS]		/int  (he hinrtd rom..g->s 1;NOTech	/* d 
 li->scstdert or
/ecified gap	 * We r
/ecified 1xi t(0 - X,UP)-hY)er tsGap				

u.
 * be  zone bord(lse_of_->s-.
			 */

_of_ rom)er tsRlled fr * how* 2 ];rp;
	ap	r==1 /**>loifdt(0.0>ix2)
	r==1fuYtut>loifd)er tsRllucorw* irr * how* 2 ];rp;
 into  * w	int me charofg[ rom..g->]
 ts]erevreturnrid=r	}

	itmtbe >fr*
shencenpoint onEMS]		/he hint er tsIfcall==NULLniy3)
s[ 1;info	er  /**n't fiodse routine in douh t
ecloifgap	*/
	short  rom,*/
	short torted by1xi stedouh thgap,
	douh th* *t
)e *#
efere TIMESLARGER 10.	ubstew* retutim	silargderm>stebasr 	}
			poi /**>h	/* cs
 * 2 ];}

	douh thrm}2ia_fdouh tholdpos}2ia_fdouh thtim	s,<f miE)\df, dx;ted byj, k;*/
	short xpr   p         *sbge}2ia_se					rest em) { *l sle char	o>>alc* Bluerlict=0;oldpos}0](] [g->nte {
		yle cha	1xi 	}2ia_foldpos}1](] to		yle cha	1xi 	}2ia_fonm}0](] nm}1](] eap				. a_fobge}0](] [g->;}
				er 			

nvenie speciao
teptlyph t=0;bge}1](] to hs);
	memset	si[i]]modifyilargded by tht REix2TEMGRP)neniy3)
settlas
			smo haalreRP-1tim	siav(TIMESLARGER-1s; tim	si> 0.1; tim	si/in2. t) {
		gp, m}0]+nm}1](]p[g.ny3 ![j].al>
	l/vsi
teptl be *
			 zone bors,<backwardsniy3)
 fowardsne co this vert ljs21      ",t is	hsnm}j](]p[g.n /vsi

sif( 
zone border exha>sted r[j].hi>frwd;

		=	;gf miEM] fags)nm}j]DS r(1.+tim	sdiriy1;thisxfor (bge}j]->corr		d: xnts */bge}!	d: xnts (xe->tcorr		d  ", i);dxr (xe->tyle cha	1xi 	}2is-.xrev-e {
		yle cha	1xi 	}2ia_f			df(] fags)dx)s-.f miEa_f			->n df(<= FEPSj].low	}
			er s
 *smo ha	o>>h	/* c/* the	fny = nge->iy1;
->n df(>] fags)nm}j]DSffor 
	df(] nm}j]a_f			ix3;
for 
	df(*orf, or)nm}j]D	 e prio}
		cstdert 			tnrtd		/rmaalrSI_}	nm}j](-=hdhort	;gf miEM] fags)nm}j]DS r(1.+tim	sdiriy1;spenx
	 = nge->iy3;
				} el.low	e of tho >= nalole charactI_}	fdouh ths>alts (()dx+df)*/ dx)s-.1.;tI_}	fdouh thbase->iy1;
spenjffor 
		baser (xe->tyle cha	1xi 	}2i;tI_}	fvs[g->nvs].baser (xe->te {
		yle cha	1xi 	}2ia_->nvs]thiskvert lks21 kNSTEMGR=		xe->tyle cha	1xi 	}k]v+ors>alts*
for 
			(xe->tyle cha	1xi 	}k]v-hbase],
					_se
		
		}etuoe, i, j)o >= mediptl  beca1r[j].hi; ij].low <= df(] -dhonrwd;b olug a zone bordr[j].higpe-r (bge}1]s].ge = is				 * loxnhs].ge = is[g->nhs].to = gexe->tyle cha	1xi 	}2is+=hdhort	;ggpe-r (bge}0ia_fildi	 * loxnhs]extrem		
	} the	 now */
		!iyp			coiy1;
spen	ny = nge->iy3;
				} else if f	ny =yle cha	1xi 	}0] +=dhort	;ggf	ny =yle cha	1xi 	}1] +=dhort	;gg}
	;ggf	ny =yle cha	1xi 	}2is+=hdhort	;ggpen	ny = g-> !avne->tyre )rl.low	int correct t>frwour	r[j].higv	ny =yry 		e =  =yle cha	1xi 	}2is+=hdhort	;gg}_fildi	 * lone->tcorr	!j]a_f			)
						vsnm}j](]p[g.n_fildi[j].al>	ge->pr
			fpr */
				retug and encect=0;oldpos}0](-] [g->nte {
		yle cha	1xi 	}2ia_foldpos}1](-] to		yle cha	1xi 	}2ia_fogp, *
  ", i *
}0](] oldpos}0](- [g->nte {
		yle cha	1xi 	}2ia_fi *
}1](] oldpos}1i -,to		yle cha	1xi 	}2ia_		fp#i

0fogp,  m}0]+nm}1](!] eap	- oldpos}1i + oldpos}0]	g->nsg=0;

	if (s[0])))  eap=%g  m}0]=%g  m}1]=%g o}0]=%g o}1]=%g rg=%g og=%gt v=				rap,  m}0],  m}1], oldpos}0], oldpos}1i,  m}0]+nm}1]tf			veap	- oldpos}1i + oldpos}0]	a_		f#e

	f>ge)*is 0  m}0]+nm}1];E#un
ef TIMESLARGER nue;
			retuoretu beca1ornd by thsmo h empr equslnt gWe r
ize<f miEMroutine in the S dnhsmo h
 */

stati,
	douh thmndlen
void
stems */          *sp;
,t xpr    g->			 ch		, k;*/douh thdx, dy, d2, d2m;
	douh thmndlen2;*#
efere TIMESLARGER 10.	ubstew* 2 ];largderm>stebasr 	}
			poi /**>h	/* cs
 * 2 ];}


	mndlen2 =hmndlen*mndlen;ter for possible stem points */

	for (ath
  ", i g->r (ge = g->;

ies; ge != 0; g!iy3;
				} s */
		 0; g!iy3;
;
			
e	fny = nge->iy1d2m ] = 0;
RP-1p[ ge != 0; nvs].ge = ? 0: 2)egp[31 );
		j=0;
dxr (nhs]y/n	nrP- e->te {
		Vx3l>	gedyg->nhs]ynn	nrP- e->te {
		V

				vd2 =hdx*dxr+ dy*dy;t is	hsd2m < d2n_fildd2m ] d2h is inde->n d2e->imndlen2 )rl.low	ill br  /**s
 *smo ha		SI_} */XXXo;

	mfop[gorm be safe,e	erev2) /*ype, etype;is inde */i

si[i	ill br s
 *smo ha		S
is vertical exwardsnix2weeext grs of vs	equencen 0;	itmthe ;
n * loe-em		thisxfor (nhs]extre xnts */e-e xnts (xe->tyre )rl
	y1d2m ] = 0;

RP-1p[ gxe != 0; nvs].ge = ? 0: 2)egp[31 );
		j=0;
;dxr (xe->ty/n	nrP- xe->te {
		Vx3l>	geedyg->xnhs]ynn	nrP- xe->te {
		V

				vvd2 =hdx*dxr+ dy*dy;t iss	hsd2m < d2n_filddd2m ] d2h is	} the->n d2e->imndlen2 )rlow	ill br  /**s
 *smo ha		SI_}i[j].al>	ge	 * loxnh;t is	hs g->r iyn			c */}etuoretu g->rstep
	/* rt 				equencenoth
				g-> 	 ng-> = g-> for}S
is verticalbackwardsnix2weeext grs of vs	equencen 0;	itmthe ;
p * loe-em		thisxfor (nhs].ge = xnts */e-e xnts (xe->t.ge )rl
	y1d2m ] = 0;

RP-1p[ gxe != 0; nvs].ge = ? 0: 2)egp[31 );
		j=0;
;dxr (xe->ty/n	nrP- xe->te {
		Vx3l>	geedyg->xnhs]ynn	nrP- xe->te {
		V

				vvd2 =hdx*dxr+ dy*dy;t iss	hsd2m < d2n_filddd2m ] d2h is	} the->n d2e->imndlen2 )rlow	ill br  /**s
 *smo ha		SI_}i[j].al>	gep * loxnh;t iNE
}
			c('\weeext grs;equencen 0;
mo hafragmecharbe hge...	 * (ones.sive)a		S
ispensg=i;
FCONCISE)  nsg-1] * sizeof (s[0]))WARNING_2*/
	tdey;
mo hafragmecha(%x..%x..%x)t v=a			ve	ifnes, lue, origin, (p		value, origin, (e-value, origin, (ne-dir	- dumpint .
g2)p	conne-dir;
e)
.h					duces of vs	equencenpoi)nentnrtd * w		rest em) { mid/
		le chcr[j	firspte-!iyn			co
he	 now *1		j=0;
;xgrev-s].s]extrem		
	penx
				nn			coiy1;
spe->tyd1ev-s].s]e/2 avpe->tydd;iy1;
spe->tydd avne->ty/
				vsspe->tyy1ev-s].s]ey2 avpe->tyy
				vsspe->tyyd avne->tynx =		vsspe->t nge->inue				}->		vss renrn 1ge)ne-dir	- (g[j].al>	ge.to)
				nx
				nn		>t.ge )rl
	y1
spe->tyd1ev-s].s]e/2 av(pe->tydd+xe->ty/
)/2.;iy1;
spe->tydd avne->ty/
				vsspe->tyy1ev-s].s]ey2 av(pe->tyyd+xe->tyy
)/2.;iy1;
spe->tyyd avne->tynx =		vsspe->t nge->inue				}->		vss renrn 1ge)ne-dir	- (g renrn 1ge)xe-dir	- (g[j].al>	ge.to)
		 renrn 1ge)pe-dEMp * loxnh;t i
;xgrev-n		>t.ge ;  renrn 1ge)ne-di 	 * loxnh;t is->pr
			grev-s].		
is verticali

si[i of vs	equencenis*smo ha		SI_dxr (nhs]y/3P- e->te {
		Vx3l>	gdyg->nhs]yn3P- e->te {
		V

				d2 =hdx*dxr+ dy*dy;tnde->n d2->imndlen2 )rl.lowno,2)
				 /**		SI_}douh thb, remum
	p, &next3fe* sizeof (s[0] "WARNING_2*/dgrs;equencen 0;fragmechar< % gle charn th,			ducednpoi)nen	}
		t v=				ve	ifnes, mndlendiriy1;			nak;
						wtug di /**>j].t grsmonstrosity;
pa */

	qusdr;

.f it is	hsf, or)e->tyi13- e->te {
		Vx1DS rf, or)e->tyi33- e->tVx1)		int is||rf, or)e->ty=13- e->te {
		Vy1DS rf, or)e->ty=30- e->tVy1)		in 	co se
		
		y	s,<wtug d;r *e E
			 */
seo

sif( sif

	big {
			fp?a		SI_}idxr (nhs]y/13- e->te {
		Vx3l>	geedyg->e->ty=13- e->te {
		Vy
				vvd2 =hdx*dxr+ dy*dy;tSI_}idxr (nhs]y/33- e->tVx1l>	geedyg->e->ty=30- e->tVy1				vvd2m =hdx*dxr+ dy*dy;tSI_}i	hsd2->imndlen2  em
2e->imndlen2)rl.low * Fonwo-straightaractI_}	f	 * lonewg| nextGEF_FLOAT)->GR=		*	 * lo*].				vsgr	- (g pe,p[g->ns21 );
		j=0;
	>fg entle cha			}2](] g entle cha			}0ia_fildirb avne->tyle cha			}0ia_fildird avne->tyle cha			}2is-.bort	;ggf	ny =yle cha			}0](] be+	0.1*dort	;ggf	ny =yle cha			}1](] be+	0.9*dort	;gg}>	ge.to)
		 P-1p[g->ns21 );
		j end * Fo)nenstraightmpr memsetrettwsbstraightaractI_}	fb(] e->te {
		yle cha			}2ia_fildid(] g entle cha			}2is-.bort	;ggny =yle cha			}0](] be+	0.1*dort	;ggny =yle cha			}1](] be+	0.9*dort	;g} is	} thepe, etype  is inde->nnhs]yry s		n			co e ple char	o>itself, ->ste		retuoretuint  

	/* nol/
		SI_}p, &next3fe* sizeof (s[0] "WARNING_2*/dgrsint  maden 0;fragmechar< % gle charn th,			returt v=				ve	ifnes, mndlendiriy1;	g-> 	  renrn 1ge)e-dE /*ype, etype;is  E
}
			c('\cloif(ip;
	ap	byrxn]			/
		SI_ pe,p[g->ns21 );
		j=0;
douh thgapiriy1;	ap	] g entle cha			}2is-.e->te {
		yle cha			}2ia_fil->n fcloifgap		congx %d)\rap, NULL)j!p[g.0j].low <=douh ths>alt,hbase->iy1;
wd; /**goo=fio=1) { urn;
resort	->stes>alts %d\ g-> -2; /actI_}		ap	] g entle cha			}2is-.e->te {
		yle cha			}2ia_SI_}i	hssg=i;
FCONCISE)  r	- (g * sizeof (s[0] "EM  urn;
resort	e,e%c:\cloif

	 g-> byr%gt v=						,p[=0 ? 'x' : 'y'))\rap)->ge->f	nys	 rev-extrem		].baser (ne->tyle cha			}2i;SI_}idxr (nhs]yle cha			}2is-.base->I_}i	hsfags)dx)s< FEPS>						ny = nge->iy1;
s>alts (()dx-rap)*/ dx)3;
				hs		ny = nge->iy3;
				} r	- (g pe,kvert lks21 kNSTEMGR=		ne->tyle cha			}k](] baser+
for 
			s>alts*
)ne->tyle cha			}k]v-hbase],


	>fg entle cha			}2](-=hgapir	is->pr
	
}
			OK,(ip;
	ap				
loifdt-e		retuore			useles1;stems i		SI_ renrn 1ge)e-dE /}E#un
ef TIMESLARGER nue;
	
				retule chcw	ereviwsbray1hny = ngf

	vectors cross* (called fr1*/
			/* cross, 0*/
			/* * forr tsIfc		/* cross opafe,LYtut(i

si[ile ch= s aop[got NULL)jalled fr
nvs	g->maxim
	in>altss
			E
			vectors ]			o so opafe,LYtutretule chc
 ts]	ereviousray1hnross (twice)er tsExpf ts/					}
		d by thaop[gorm be odse rr tsFor	

nvenie  the eAX}
			2d ront-es ifune bors/	ak
 *
 d bygumecharbe g and end ndstatptedresetructsray.lowdouh thx1siy1six2siy2ortNTRYishsi=;
	douh thk,hbhrlow	illthaop[ree {se.
 * o=1yg->k*x + bnv

	douh th*maxpir};tine in etructsray.ray[3ia_S/vs	g->back-es ido	}

	it actusln], v
nvs	g->ray1herus
efere= 	/* if sne in a*/
		ray[]tedreset to 0 forfcrossray1xx(
	douh thcrossdot}2]}2isvoid
douh thxsiy,hmaxortNTRYi;ter fo,p[g->ns21 );
		j=0;gp, ay[i].d1ev=  ay[i].d2  r	-  ay[i].ishsi=g->1				nhs].to =  ay[i].ishsi=g->= 0;

 ay[i].kver, ay[i].= 0-  ay[i].=le,wi, ay[i].d 0-  ay[i].x1)=GE

 ay[i].b(]  ay[i].= 0-  ay[i].k (caay[i].d ir;
e)prevwsp, ay[0].ishsi=glb )ay[1].ishsi=		j=0;gp,sg=i;
FCONCISE)   * sizeof (s[0] "crossray1:	E
			ve" */
)mory for no stemsrlowE
			ve" */
),h* for cross v

	revwsp, ay[1].ishsi=		j=0; ay[2](]  ay[0]srlowex>h	/* csitmthe ;
 ay[0](]  ay[1ia_fi ay[1i(]  ay[2ia_		fpwsp, ay[0].ishsi=		j=0;x(]  ay[0].x1l>	->nhs].to =->n fags)nay[0].k0-  ay[1].k)e< FEPS>nsg-1]gp,sg=i;
FCONCISE)   * sizeof (s[0] "crossray1:	t
gslle{
		ifs, kver%g,r%gt v=					nay[0].k,  ay[1].k)=GE

 no stemsrlowt
gslle{
		ifsthe ;
e);;x(] , ay[1].b0-  ay[0].be,wi, ay[0].k0-  ay[1].k)ea_		f	y(]  ay[1i.k (cx +  ay[1].b;ter fo,p[g->ns21 );
		j=0;gp, ay[i].ishsi=	GE

in <] ,y0-  ay[i].=le,wi, ay[i].= 0-  ay[i].=le				nhs]GE

in <] ,x0-  ay[i].x1),wi, ay[i].d 0-  ay[i].x1)=GE
 verticali

wrong
			cseo

ray1hnross r[j	firsoin <	in 	cog-1]gp,sg=i;
FCONCISE)   * sizeof (s[0] "crossray1:	%cin>alt=%g @(%g,%g) (%g,%g)<-(%g,%g)t v=					(i?'Y':'X'))\in ,hxsiy,h ay[i].d ,  ay[i].= ,h ay[i].d1,  ay[i].=le				]y is 0 = 0;
-=0;gp, ay[i].maxp	GE

* ay[i].maxp =hmaxort}pwsp,crossdotj!p[g	cog-1crossdot}0	}0](] crossdot}1	}0](] xort1crossdot}0	}1](] crossdot}1	}1](] yort}pwn't find anue;
	rp;
 ront-es iget*
 * lone *gumechar;
			4h* tss
efer
 *
 d bw	}
			e/* if see andstat o=1
			fapprox	}
		():
 (caay1herus
efere= o=1			pge = gend.e++;
		retuc}
		,
nvs	g->crossdotj 1;in0;
	e= o=1	g->iwsbmid/
		* tss
		retuc}
		tedres forfcrossray1cv(
	douh thc}
		[4]}2rloX,Y*/],
	douh th*max1,
	douh th*max2svoid
 ay[0].x1(] c}
		[0	}Xia_	 ay[0].y1(] c}
		[0	}Yia_	 ay[0]./2 avc}
		[1	}Xia_	 ay[0].y2 avc}
		[1	}Yia_	 ay[0].maxp =hmax1->ge)ay[1].x1(] c}
		[2	}Xia_	 ay[1].y1(] c}
		[2	}Yia_	 ay[1]./2 avc}
		[3	}Xia_	 ay[1].y2 avc}
		[3	}Yia_	 ay[1].maxp =hmax2->ge)*is 0 fcrossray1xx(&c}
		[1	) anue;
	rp;
 ront-es iget*
 * lone *gumechar;
			g stem p:
 (caay1herus
efere= o=1			pge = g
			}
		1gend.e++;
			}
			2tedres forfcrossray1ge)*/
	short *v1,*/
	short *v2,
	douh th*max1,
	douh th*max2,
	douh thcrossdot}2]}2isvoid
 ay[0].x1(] *v1>te {
		Vx3l>	 ay[0].y1(] *v1>te {
		Vy3a_	 ay[0]./2 av*v1>ttle cha	X][*v1>tttgia_	 ay[0].y2 av*v1>ttle cha	Y][*v1>tttgia_	 ay[0].maxp =hmax1->ge)ay[1].x1(] *v2		Vx3l>	 ay[1].y1(] *v2		Vy3a_	->nnh2		rtg<	in		j=0; ay[1]./2 av*v2>te {
		Vx3l>	g ay[1].y2 av*v2>te {
		Vy3a_	->nhs].to = ay[1]./2 av*v2>ttle cha	X][*v2		rtg]l>	g ay[1].y2 av*v2>ttle cha	Y][*v2		rtg]l>	}_	 ay[1].maxp =hmax2->ge)*is 0 fcrossray1xx(crossdot) anue;
	last=g
 * * sizoutifune bors/dres#i


efere=(DEBUG_DOTSEG) ||a
efere=(DEBUG_DOT				} e||a
efere=(DEBUG_APPROXCV)ue;
	
derlast=g
 */dreet to 
* sizdot(
	douh thdot}2]svoid
e* sizeof (s[0] "(%g,%g)", dot}0	, dot}1	) anueet to 
* sizseg(
	douh thseg}2]}2isvoid
putc('[', f (s[0e			* sizdot(seg}0]	a_	putc(' ', f (s[0e			* sizdot(seg}1]	a_	putc(']', f (s[0e			fp#e

	frlowDEBUG_*edresy_latsF end qu
		 idiet   th;
			a dotT1 ra -2; /segmechtedresdouh t
e* tsegdiet2(
	douh thseg}2]}2rloX,Y*/],
	douh thdot}2rloX,Y*/]
)e *#
efere x1	seg}0]	X]*#
efere y1	seg}0]	Y]*#
efere x2	seg}1]	X]*#
efere y2	seg}1]	Y]*#
efere xdot	dot}X]*#
efere ydot	dot}Y]**/douh thdx, dyMAX_Seegmechidimecslyph t=0;douh thk		if,	b		ifMAX_Seegmechids as
		tuurj 1;y=k*x+bnv

	douh thkperp,	bperpsrlowterpe

	c* Brg;
			retugotT1 rsi[i	ill v

	douh thxcross, ycross	 e pr	ereviousterpe

	c* Brgcrossesi, j);egmechidresy_on */
	gWe r
itusafe,er	ereviousred estime ch			/retu;egmechi 1;iharnnd r[j#
efere HANDL;
;
MITS(les112P]+ssscr1P]+ssscr2)	\fogp, les112 	co \j	firso+ssscr1 	co \j	f	xcross(] x1; \j	f	ycross(] y1; \j	f	s, vpairs !(+ssscr2) 	co \j	f	xcross(] x2; \j	f	ycross(] y2; \j	f	s\_	->nhs].t \j	firso!(+ssscr1) 	co \j	f	xcross(] x1; \j	f	ycross(] y1; \j	f	s, vpairs +ssscr2 	co \j	f	xcross(] x2; \j	f	ycross(] y2; \j	f	s\_	->\pr */e++;
		macroidres
;dxr (x 0- x1l>	dyg->= 0- y1 hs)->sfags)dx)s< FEPS> ", irwd
/ecial caser-E_LINE) {
		if r[j#if
ef DEBUG_DOTSEG, i* sizeo"_LINE) {
		if!mory f#e

	f>f	xcross(] x1;
f	ycross(] ygot;
f	HANDL;
;
MITS( y1s< = ,hycross(<iy1siycross(<iy2);gp[i-1]; ->sfags)dy)s< FEPS> ", irwd
/ecial caser-Eertical pri		if r[j#if
ef DEBUG_DOTSEG, i* sizeo"ertical pri		if!mory f#e

	f>f	xcross(] xgot;
f	ycross(] y1;
f	HANDL;
;
MITS( x1s< d , xcross(<id1, xcross(<id2n_f->nhs].to =k		if =hdy/dx;
f	b		if =h=13- x1*k		if;
f	kperp  ge ./k		if;
f	bperp  gygot3- xgot*kperp,


	xcross(] (b		if-bperp),wi,kperp-k		if);
f	ycross(] k		if*xcross(+	b		ifM

f	HANDL;
;
MITS( x1s< d , xcross(<id1, xcross(<id2n_f-j#if
ef DEBUG_DOTSEG, * sizeo"crossstderat (%g,%g)t v=hxcross, ycrossy f#e

	f>
;dxr (xgot-xcrossl>	dyg->=got-ycrossl>	)*is 0 dx*dx+dy*dy;t#un
ef x1t#un
ef y1t#un
ef x2s#un
ef y2s#un
ef xgots#un
ef ygots#un
ef HANDL;
;
MITS nue;
	
				retuweighted	qusdr; in atdeagas
			retug et   thofgr serr tsofg* tss;
			retu	}
		;	o so fillss
vesoint;

	viduslng et   ts* (c
			n thegot;li

maxp!=NULLniy3)
alled frhe fmaxim
	inqu
		 * (cg et   the/* ifretedresdouh t
e* t	}
	diet2(
	douh thc}
		[4]}2rloX,Y*/ ],
	etructs* t_diet ** tsrted byn* tsr.lownrst emptycorrm pfbe gotsnv

	douh th*maxpsvoid
/*gr 	}
			er approxim
te= Eaore			 retustraightm;egmechs r[j#
efere NAPSECT	16d
/*gr 	}
			er 
	vidigin, oore			 retusne bors/ast pequslnweight	n ther[j#
efere NWSECT	4d
/*gtah tho t>fefficiechar;pr me

	}

	i		* tss
nisi[i	}
			v

	/*gt
}0](			left unused r[j]ine in douh tgt
}NAPSECT][4];j]ine in d byext t=g->=  end lag:gt
j 1;initi be od	v

	/*g* tss
nisi[i	}
			v

	douh thcvd}NAPSECT+1]}2rloX,Y*/];
	/*gsumrr * sne bors/v

	douh thsum[NWSECT];
	/*g

u.
rr * sne bors/v

	douh th

u.
[NWSECT];
	d byd %d)\jortNTRYid1, id2ortdouh thdiet1,hdiet2,hdiet3,hdx, dy, xsiyortdouh thin <] =.;nit->s!ext t=> ", idouh tgt, nt, t2,hnt2,hstepM

f	ext t=1 != gstep
in1. / NAPSECT!= g=g->= 0;
 fo,p[[egp[NAPSECT! );
		j=0;
tv+orstepM
=		n=g->1 -,tM
=		t2 avt*>			
	 t2 avnt*ntM
=		tt			}0](]  t2*ntM end(1-t)^3 actI_}tt			}1](] 3* t2*tM end3*(1-t)^2*t actI_}tt			}2](] 3* t*t2M end3*(1-t)*t^2 actI_}tt			}3](] t2*tM endt^3 actI_e)prevw fo,p[g->nsNWSECT! );
		j=0;sum[nrP=f0.;iy1

u.
[nrP=f0;			fpr */
/**tisi[i	}
			n, oo;egmechs r[jw fo,d[g->ds21 d;
		j endXgend. i		SI_cvd}0]	d](] c}
		[0	}d]srlowendle charactI_cvd}NAPSECT]	d](] c}
		[3	}d]s0;
 fo,p[[egp[NAPSECT! );
		j=0;
cvd}i]	d](] c}
		[0	}d] *gt
}		}0i the	+vc}
		[1	}d] *gt
}		}1i the	+vc}
		[2	}d] *gt
}		}2i the	+vc}
		[3	}d] *gt
}		}3];tI_e)prevw fo,d[g->dsn* ts1 d;
		jj#if
ef DEBUG_DOT				}iy1* sizeo"got3%dintfddEMp sizdot(* ts}d].pdEMp sizeo":mory f, irwd
derlast=g
 */dreI_ pe,p[g->ns NAPSECT! );
		j=0;
diet1 	  * tsegdiet2(&cvd}i], dots}d].pdE=0;
p sizeo" o;eg3%dintidEMp sizseg(&cvd}i]dEMp sizeo"hdiet=%gt v=asqrt(diet1)dir;
e)#e

	f>
;;x(] dots}d].p}Xia_		y(] dots}d].p}Y] f, irwd
				retured estigot3
nisi[i	}
		
renvs		erev}
				/u* to 2 lo) {
mini				 -,sthe net rti;
			ret
renvs, add
			}
			end.go		i=egp[ce.
 r
	 * otj	fid1g->= 0;
dxr (x -,cvd}0]	Xia_		dyg->= -,cvd}0]	Yia_		diet1 	 dx*dxr+ dy*dy;t#if
ef DEBUG_DOT				}iy1* sizeo" igot30	n],Mp sizdot(cvd}id1]dEMp sizeo"hdiet=%gt v=asqrt(diet1)dir#e

	f>f	 pe,pg->1	>ns=NAPSECT! );
		j=0;
dxr (x -,cvd}i]	Xia_			dyg->= -,cvd}i]	Yia_			diet3 	 dx*dxr+ dy*dy;t#if
ef DEBUG_DOT				}iy11* sizeo" igot3%dintidEMp sizdot(cvd}i]dEMp sizeo"hdiet=%gt v=asqrt(diet3)dir#e

	f>f	i	hsdiet3 <hdiet1  ", i);diet1 	 diet3->I_}i	d1g->est[di->ix1;
			g[j].al>	g inde->n	d1gs NAPSECT-1  ", i)id2 =hNAPSECT!= g
dxr (x -,cvd}NAPSECT]	Xia_			dyg->= -,cvd}NAPSECT]	Yia_			diet2 =hdx*dxr+ dy*dy;t#if
ef DEBUG_DOT				}iy11* sizeo" i+got3%dintfid2],Mp sizdot(cvd}id2]dEMp sizeo"hdiet=%gt v=asqrt(diet2)dir#e

	f>f	i pe,pg->NAPSECT-1! )>	d1s[egp--		j=0;
;dxr (x -,cvd}i]	Xia_				dyg->= -,cvd}i]	Yia_				diet3 	 dx*dxr+ dy*dy;t#if
ef DEBUG_DOT				}iy111* sizeo" igot3%dintidEMp sizdot(cvd}i]dEMp sizeo"hdiet=%gt v=asqrt(diet3)dir#e

	f>f	ii	hsdiet3 <hdiet2].low <= diet2 =hdiet3->I_}i)id2 =hest[dir->ix1;
			gi[j].al>	ge->
	}
			c('\
				w	ithe		/retulo) {
mini				 ithsmo h em it is	hsdiet2 <hdiet1  ", i);	d1g->ed2h is	} th
	
}
			retured esti;egmechim>steones.de	retured estigot3r[j	firs	d1ite dj=0;
dots}d].;eg3->= 0;

dots}d].diet2 =h * tsegdiet2(&cvd}0], dots}d].pdE=0;[i-1]; ->s	d1itNAPSECT dj=0;
dots}d].;eg3->NAPSECT-1!0;

dots}d].diet2 =h * tsegdiet2(&cvd}NAPSECT-1], dots}d].pdE=0;[i-1]; j=0;
diet1 	  * tsegdiet2(&cvd}id1], dots}d].pdE=0;	diet2 =h * tsegdiet2(&cvd}id1-1], dots}d].pdE=0;s	hsdiet2 <hdiet1  ", i);dots}d].;eg3->id1-1;, i);dots}d].diet2 =hdiet2st[di->ix1; ", i);dots}d].;eg3->id1;, i);dots}d].diet2 =hdiet1h is	} th
	
}
i(] dots}d].;eg3% NWSECT;=0;sum[nrP+] dots}d].diet2st[d	hsdots}d].diet2 >reoxny3 !in <] dots}d].diet2st[d

u.
[nr1 !=#if
ef DEBUG_DOT				}iy1* sizeo" besti;eg3%disne 3%didiet=%gt v=adots}d].;eg %d)\sqrt(dots}d].diet2)dir#e

	f>f	fpr */>alc* Blueretuweighted	atdeagasdrehsd1i= 0;diet1=0.;iy fo,p[g->nsNWSECT! );
		j=0;sp,c
u.
[nrite 
	*ype, etype;is	d1s+a_		diet1 +orsum[nr/c
u.
[nrort}pwsp,maxp	GE
*maxp =hmaxortirs	d1ite dineP);* tsr.stra/* c/* thy is 0 =.;iyix3;
for)*is 0 diet1/id1; endtodg

	gsseatdeagasg et   thapply\sqrt()a		S}pwsy_latsApproxim
tegr 	}
			m
tch	}

	i		g	ving
	eS]		/i		 *dd 			wit f homid/
		rend enceci		 *ddgo	}

] ==

	i		g	v3)
segmechs ( 			P);f rt	er
nvs	ganisi[stu;egmechs).tedres>nsg-fapprox	}
		(
	douh thcv[4]}2rloX,Y*/ ], e ple char0-3d 			p;
	igin,,ple char1, 0- 
vesr[j]inructs* t_diet ** tsr 			retu* tss1 rapproxim
teg-ng et   ts*n't fiod
forvs		erev}
				/in	alid r[j]d byn* tssvoid
/*gbP]			;	
				 { mid/
		ny =rolole charact#
efere	B	0t#
efere	C	1
} */}
xim
	iirst emptysne bors/	nin the1xi t- used 
			retumemsetstep
r[j#
efere MAXSECT	2
} */irst emptysne bors/used 
			retuthe X1steps r[j#
efere NORMSECT 2
} */wy3)
s[e1steps becof }les1;	ganisi			 retume chaP])
'sntim	s1 rstop
r[j#
efere STEPEPS	1.
	douh th;
		}2rloB,C*/],s1 }2rloB,C*/]ortdouh thiid/f}2rloB,C*/]}2rloX,Y*/],hdhortdouh th

ef}2rloB,C*/]}MAXSECT]e  idouh thres}MAXSECT]}MAXSECT],isi		 */, best */, goo= */ortNTRYn

ef}2rloB,C*/], best}2rloB,C*/], goo=}2rloB,C*/]ort ch		, j, k,Pkee*sym;
	/f(sibc[]="BC";
	/f(sixy[]="XY";
=#if
ef DEBUG_APPROXCVd
e* sizeof (s[0] "C}
			me cha:;
			 fo,p[g->ns4! );
		j=0; * sizeof (s[0] "Ery forp sizdot(cv}i]dEMrt}pwe* sizeof (s[0]))')Doha:;
			 fo,p[g->nsn* ts1 );
		j=0; * sizeof (s[0] "Ery forp sizdot(dots}i].pdEMrt}pwe* sizeof (s[0]))')"y f#e

	f>
;low	oadindexes i		 *dd 			>alc* Blueg and ences r[jw fo,p[g->ns21 );
		j=0; */i ithX,. i		SI_iid/f}B][nrP=fcv}1][nr-cv}0][nrort_iid/f}C][nrP=fcv}2][nr-cv}3][nror=0; */i ithB, Ci		SI_ rom[nrP=f0.;iy11 }nrP=f1.;tI_n

ef}nrP=fMAXSECT;			fpr now */

ef}B](!] 1 ||a/

ef}C](!] 1		j=0; */prep
				 { ing asho t>fefficiechar		SI_ pe,p[g->ns21 );
		jrloB,C*/=#if
ef DEBUG_APPROXCVd
0; * sizeof (s[0] "Cfefficiecharbyr%c(%g,%g):v=abc[i],  rom[nr,s1 }i]dEr#e

	f>f	idf(] (1 }i]- rom[nr),wi,n

ef}nr*2fa_file, " group *

ef}nr:      ", i);

ef}nr				=f rom[nrP+ df*(2*j+le		#if
ef DEBUG_APPROXCVd
0;; * sizeof (s[0] "E%gv=a

ef}nr			dEr#e

	f>f	i}=#if
ef DEBUG_APPROXCVd
0; * sizeof (s[0] "mory f#e

	f>f	} thbest */ ] FBIGVAL;gphbest}B](= best}CrP=f0;		; */i i
teptlarbyr/

ef}B], j i
teptlarbyr/

ef}C]
 /* nope,p[g->ns[

ef}B]! );
		j=0;
e, " group *

ef}Cr:      ", i); pe,k=t lks21 kNST	jrloX,. /* the	fnv}1][krP=fcv}0	}k]v+ iid/f}B][k]*

ef}B][nrort_e	fnv}2][krP=fcv}3	}k]v+ iid/f}C][k]*

ef}C][j]a_f			)
				nes}nr				=fsi		 */ =h * t	}
	diet2(cv,;* tsr.n* tsr.NULL);>f	ii	hssi		 */ < best */].low <= goo= */(= best */ort <= goo=}B](= best}B]ort <= goo=}C](= best}Crort <= best */ ] si		 */ort <= best}B](= iort <= best}C](= jst[dir->ix1; 	hssi		 */ < goo= */].low <= goo= */(= si		 */ort <= goo=}B](= iort <= goo=}C](= jst[dir-	#if
ef DEBUG_APPROXCVd
0;; * sizeof (s[0] "Eat (%g,%g)idiet=%g %st v=a

ef}B][nr=a

ef}C][j])\sqrt(si		 */)=						,best}B]==iglb best}C]==j)? "(BEST)":""dEr#e

	f>f	i}=ir-	#if
ef DEBUG_APPROXCVd
0 * sizeof (s[0] "Ebest:Eat (%g, %g)idiet=%gt v=				

ef}B][best}B]r=a

ef}C][best}C]])\sqrt(best */]);>f	 * sizeof (s[0] "EB:%d,%diC:%d,%di-- 2endbest:Eat (%g, %g)idiet=%gt v=				best}B], goo=}B], best}C], goo=}C]=a

ef}B][goo=}B]r=a

ef}C][goo=}C]])\sqrt(goo= */]y f#e

	f>
;1->nbest */ <t(0.1*0.1) el.low	en			ciao
\cloif({
			fp in
	r */>alc* Blueretucortdin
noar1 r)*is 0  ot	MGRP-1k=t lks21 kNST	jrloX,. /* the	nv}1][krP=fcv}0	}k]v+ iid/f}B][k]*

ef}B][best}B]r; the	nv}2][krP=fcv}3	}k]v+ iid/f}C][k]*

ef}C][best}C]];>f	i}=#if
ef DEBUG_APPROXCVd
0; * sizeof (s[0] "qui}

	pproxim
te= mid/
		le charn],Mp sizdot(cv}1]	a >GR=e* sizeof (s[0]))rn],Mp sizdot(cv}2]dEM * sizeof (s[0] "mory f#e

	f>f	r)*is 0;tI_e)p	kee*symP=f0;		;->nbest}B](!] best}C](lb best}B]-best}C](== goo=}C]-goo=}B]].low <kee*symP=f1		#if
ef DEBUG_APPROXCVd
0; * sizeof (s[0] "kee*ing
	ymmetry!mory f#e

	f>f	intsope,p[g->ns21 );
		j enB,C*/=	ii	hs*

ef}nr==1), i);

, etype;isi	hskee*sym].low <=			rsi[i]]kee*
s[e1symmetry1r[j].hi; ibest}i] < goo=[nr),low <=  rom[nrP=f

ef}nr	best}i]rort <= 1 }nrP=f

ef}nr	goo=[nr]st[dir->ix1; low <=  rom[nrP=f

ef}nr	goo=[nr]st[dir 1 }nrP=f

ef}nr	best}i]rort <=}t[di->ix1; ", i);df(] (1 }i]- rom[nr),wi*

ef}nr:
 <=  rom[nrP+=hdh*best}i]:
 <= 1 }nrP=f rom[nrP+ dfh is	} th=->n fags)dh*iid/f}		}0ifj< STEPEPS(lb fags)dh*iid/f}		}1ifj< STEPEPS].low <=			r 						c2*/
	

nverged r[j].hi rom[nrP=f1 }nrP=f( rom[nr+1 }i]d
			.				I_n

ef}nrP=f1st[di->ix1; 			I_n

ef}nrP=fNORMSECTl>	g ind}pr */>alc* Blueretucortdin
noar1 r)*is 0  ot	RP-1k=t lks21 kNST	jrloX,. /* thnv}1][krP=fcv}0	}k]v+ iid/f}B][k]* rom[B]ort nv}2][krP=fcv}3	}k]v+ iid/f}C][k]* rom[Crort}p#if
ef DEBUG_APPROXCVd
e* sizeof (s[0] "	pproxim
te= mid/
		le charn],Mp sizdot(cv}1]	a >Ge* sizeof (s[0]))rn],Mp sizdot(cv}2]dEM * sizeof (s[0] "mory f#e

	f>#un
ef B>#un
ef C>#un
ef MAXSECT>#un
ef NORMSECTE#un
ef >TEPEPS
ntry_lastF				retu qu
		 iing a			/retu;etyss
		retuang thbetwe3)
s[e
 */e++;
		g	1gend.	g->b		pge = g
		ge2lastT[[i	}
			m>stebasgorm be odse routine in douh t
eje chain2)*/
	short *v1,*/
	short *v2svoid
douh thd}3	}2rloX,Y*/];
	douh ths>alt1,hs>alt2P]+sn1P]+sn2ortNTRY1xi ort_	->nnh1		rtg<	in		j=0;d}1]	X] av*v1>tt/33- e-1>te {
		Vx3l>	gd}1]	Y] av*v1>tty33- e-1>te {
		Vy3a_	->nhs].to =d}1]	X] av*v1>tt/33- e-1>ttle cha	X][*v1>trtg]l>	gd}1]	Y] av*v1>tty33- e-1>ttle cha	Y][*v1>trtg]l>	}_	d[2	}Xi av*v2>ttle cha	X][*v2		ttgi3- e-2>te {
		Vx3l>	d[2	}Yi av*v2>ttle cha	Y][*v2		ttgi3- e-2>te {
		Vy3a_
	+sn1 avsqrt( d}1]	X]*d}1]	X] + d}1]	Y]*d}1]	Y] );>flen2 =hsqrt( d}2]	X]*d}2]	X] + d}2]	Y]*d}2]	Y] );>f */
>alts %d\2end;egmechi1 rsi[i	engthe		/1
	 horizoi]]m* Fosu				 			}
		1sti;egmechi			longder
>alts*tiso
envs		ei	engthe		/2gend.exteizoi]] if see ag et   thbackwards
	sr[j]i>alt1 in2./+sn1;j]i>alt2 _UP./+sn2;ter fo,1xi =t l1xi ts21 1xi     ", id}0]	1xi 	  ge( d}1]	1xi 	 *ors>alt1 );>f	d[2	}1xi 	 *ors>alt2;rt}pwn't fin * tsegdiet2(d, d}2]e			fp#i

0frwd
				retu
		a	cstdee= Eaoretuc}
		ted (f miEe= Eaoretuprojne bors/i]] if X 1xi )e routine in douh t
ecv
		a(*/
	short *v
)e */douh thLy, My, Ny, Py, Qx, Rx, Sx;
	douh th
		a hs);
	yg->Ly*t^3 + My*t^2 + Ny*t + Py1r[j]Lyg->-e->te {
		Vy
 + 3*)e->ty=13- e->tVy2e + e->tynx =	My(] 3*e->te {
		Vy
 - 6*e->ty=13+ 3*e->tyy2 0;Ny(] 3*(-e->te {
		Vy
 + e->tVy1) 0;Pyg->e->te {
		Vy3a_
	/*g*x/d=g->Qx*t^2 + Rx*t + Sx1r[j]Qx(] 3*(-e->te {
		Vx
 + 3*)e->ty/13- e->tVx2) + e->tVx3)=GERx(] 6*(e->te {
		Vx
 - 2*e->ty/13+ e->tVx2)=GESx(] 3*(-e->te {
		Vx
 + e->tVx1)a_
	/*g
		a	 1;integral[ rom 0/i]]1]( y(tDS rdx(tD/d=g*dt)a		S	
		a	_UP./6.*(Ly*Qx) + P./5.*(Ly*Rx + My*Qx) 
e	+vP./4.*(Ly*Sx + My*Rx + Ny*Qx) + P./3.*(My*Sx + Ny*Rx + Py*Qx)
e	+vP./2.*(Ny*Sx + Py*Rx) + Py*Sx;
pwn't fin
		a he)#e

	f>
rwd
				retuing a			/me ch		nisi[i	}
						}
		g	v3)
t
gsmet em),
nvs] ==

	i		g	v3)
1xi t(0 - X,UP)-hY)er toutine in douh t
ecving(*/
	short *vrted by1xi stedouh tht
)e */douh tht2,hmt,hmt2a_
	/*ging	_UA*(1-t)^3 + 3*B*(1-t)^2*t + 3*C*(1-t)*t^2 + D*t^3 actIt2 avt*>			m=g->1->			m=2 =hmt*mtort_	n't fine->te {
		yle cha	1xi 	}2i*mt2*mt 
e	+v3*)e->tyle cha	1xi 	}0]*mt2*t + e->tVle cha	1xi 	}1]*mt*t2)
e	+vny =yle cha	1xi 	}2i*t*t2M
ntry_lastF				n* tspequslly;
pacedn* tss
nir 	}
			ori		if rizofillr
nvs	g-irucortdin
noarn, ooretu* tssa*/
	ubroutine in the S seeple* ts(*/
	short *vr  idouh thdots}	}2ifi			retu* tss1 rfillrr[j]d byn* tssvoid
 ch		, 1xi ortdouh tgt, nf,hdx, d}2ia_SInf(] n* ts+= GE->nny = nge->iy3;
				} else  fo,p[g->nsn* ts1 );
		j=0;g=g->(i+1)/nfa_file, "1xi =t l1xi s21 1xi    , i);dots}i]	1xi 	  gecving(*vr 1xi s tdir;
e);
>nhs].t low	ill 		SI_d}0](] nhs]y/3P- e->te {
		Vx3l>	gd}1](] ehs]yn3P- e->te {
		V

				 fo,p[g->nsn* ts1 );
		j=0;g=g->(i+1)/nfa_file, "1xi =t l1xi s21 1xi    , i);dots}i]	1xi 	  ge->te {
		yle cha	1xi 	}2i
for 
	+vt*d	1xi 	ir;
e);

ntry_lastAllo) tegr inructu			gex_

nubroutine in the Sallo)_gex_

n(*/
	short *v
)e */e->tg-> 	 (the *)callo)(1,hse oof(GEX_CON)) GE->nny =g->r iy0		j=0; * size if (s[0]))) **mallo) faile*NG_2	ill %rt v= __FILE__= __;
		__e				nxit(255dE /}Entry_lastNorm be ogr *correc;pr m;prce

ncise() :	
				retule chs/				
 linan			/usednpoi>alc* Blueretuta/* chs.ubroutine in the S norm be ege)*/
	short *v
)e */ ch	midsnes,  rontsnes, 		arsnes;nit->sny = nge->iy3;
;
				j=0;ehs]ytg3->2st[dehs]rtg3->-1l>	->nhs].tnrwd;ssume])
'snai	}
			v

		midsnesP=f( ags)e->tyi1-e->tVx2)<FEPS(lb fags)e->tVy1-e->tVy2e<FEPS);>f	 rontsnesP=f( ags)e->tyi1-e->te {
		Vx3)<FEPS(lb fags)e->tVy1-e->te {
		Vy3e<FEPS);>f			arsnesP=f( ags)e->tyi3-e->tVx2)<FEPS(lb fags)e->tVy3-e->tVy2e<FEPS);>		;->nmidsnesPlb ( rontsnesP|| 		arsnes)j].low <lowesse.
islly;a -2; /actI_}ehs]ytg3->2st[ddehs]rtg3->-1l>		->nhs].tn th=->n rontsness, s, ege->tytg3->1st[di->ix1;  s, ege->tytg3->0h is	} th=->n		arsnes)j s, ege->trtg3->0h is	}>ix1;  s, ege->trtg3->1st[di-r;
e);

ntry_ginriouss
efer
afe,e
			retupro;

	 = g
		out		ifsthe 
 */}
xim
	iatdeagasqusdr; in diet   th;
			retutri	pgal c}
		ted (be gots)i->scsn			ciaretuje cedn	}
			goo=

r[j#
efere CVEPS	1.5j#
efere CVEPS2	(CVEPS*CVEPS)e;
	
qu
		 i;etyss
		retu}
xim
	iang th					wtucsn			ciar imo
			je chcr[j#
efere SMOOTHSIN2 0.25nrwd0.25==;et(30s
egrees)^2 act;
	
qu
		 i-2; /	engthe					wtucsn			ciasmo ha		S#
efere SMALL
;
		2 (15.*15.)e;
	tew* retutim	siai	}
			m>stebasbiggciarean;a -2; /->sje c,	
qu
		 i		S#
efere TIMES
;
		2 (3.*3.)try_lastNorm be ogr			ogalysogr *correc;pr m;prce

ncise() rizofillr
vesointgex_

nubr inructu		ubroutine in the S ogaly ege)*/
	short *v
)e */ ch		, ix, iyortdouh thavsd2, dots}3	}2rloX,Y*/];
	GEX_CONt *vx;
pw*vx3->X_CON)e-dE /memset)e-x, 0,hse ooft *vx);
pw*vx->len2 =h0;jw fo,p[g->ns21 );
		j=0;avsd2  ge-x->d}nrP=fg entle cha			}2is-.e->te {
		yle cha			}2ia_fi*vx->len2 +=havsd2*avsd2;rt}pw*vx->ain2  geje chain2)	congxv-extr) GE->nny = nge->iy3;
				} else ny =diru gegetcvdir)e-dE /* pe,p[g->ns21 );
		j=0;
dots}0][nr  ge->te {
		yle cha			}2i;SI_}dots}1]}nrP=fg entle cha			}2i;SI_}dots}2]}nrP=fecving(*vr 	, 0.5dir;
e);;avsd2  g * tsegdiet2(d tsr.dots}2]);		;->navsd2 <= CVEPS2), s, erex->type)!|iy3;XF_FLATir;
e);
>nhs].tse ny =diru gCVDIR_FEQUAL|CVDIR_REQUALa_fi*vx->type)!|iy3;XF_FLATir;}GE->nnyx->type)!&y3;XF_FLAT		j=0;sp, fags)e-x->d}X]) > FEPS(lb fags)e-x->d}Yifj< 5.=0;lb fags)e-x->d}Yi / e-x->d}X]) <d0.2)s, erex->type)!|iy3;XF_HOR				n vpairs fags)e-x->d}Yifj> FEPS(lb fags)e-x->d}Xifj< 5.=0;lb fags)e-x->d}Xi / e-x->d}Y]) <d0.2)s, erex->type)!|iy3;XF_VERTir;}GE-x  ge-x->isd}Xi avf, or)e-x->d}Xif GE-y  ge-x->isd}Yi avf, or)e-x->d}Y]) GE->n-x <iy0		j=0;->n-y <iy0		s, erex->type)!|iy3;XF_QDL;=0;->n-y >iy0		s, erex->type)!|iy3;XF_QUL;=0;->nnyx->type)!&y3;XF_HOR)s, erex->type)!|iy3;XF_IDQ_Lir;}GE->n-x >iy0		j=0;->n-y <iy0		s, erex->type)!|iy3;XF_QDR;=0;->n-y >iy0		s, erex->type)!|iy3;XF_QUR;=0;->nnyx->type)!&y3;XF_HOR)s, erex->type)!|iy3;XF_IDQ_Rir;}GE->nnyx->type)!&y3;XF_VERT		j=0;->n-y <iy0		 s, erex->type)!|iy3;XF_IDQ_Ul>		->nhs].tn/*gsuppoifdtutretrl br  / 0-se od	correcr[j	ferex->type)!|iy3;XF_IDQ_Dir;
e);

ntry_lastAgalysogr je chcbetwe3)
s[idd 			follow = g*correc;pr m;prce

ncise() f horizofillr
vesoint	e ofspo

	}

 */
seo

sintgex_

n inructu		ubr Bondexesrrm pfm>stebasrgaly edumemse.ubroutine in the S rgaly eje ch(*/
	short *v
)e */
	short 	nys	 rev-extrem	
	shortt].			GEX_CONt *vx      x;
	douh th
vsd2, dots}3	}2rloX,Y*/];
	NTRYi;ter*vx3->X_CON)e-dE(ne-x3->X_CON)ne-diriylow	ook*/
			/* can			/je cednhoifstl/
		S
e */i

retu 1;f Bl,			/* should/je c imo
		l/
		SIirs nnyx->type)!&y3;XF_FLAT ||a/nyx->type)!&y3;XF_FLAT	
	s */
x->ain2 > SMOOTHSIN2)s, go oorry_f BlE
		;nit->sny = nge->iy3;
;
				j=0;hs		ny = nge->iy3;
;
				j=0;E->nnyx->len2 > SMALL
;
		2 ||a/nyx->len2 > SMALL
;
		2 , i);go oorry_f BlE
		;ns	}>ix1;  s, e->nnyx->len2*TIMES
;
		2 >a/nyx->len2 , i);go oorry_f BlE
		;ns	}gp[i-1]; ->s	ny = nge->iy3;
;
				j=0;->s	nyx->len2*TIMES
;
		2 >anyx->len2 , i)go oorry_f BlE
		;ns}S
e */i

	}
			>h	/* ( 
zone bord		SIirs e-x->isd}Xi*ne-x->isd}Xi<0 ||ae-x->isd}Yi*ne-x->isd}Yi<0)s, go oorry_		c] ==e;S
e */i

would/>j].t grszigzag
		SIirs n(ny =dir&CVDIR_FRONT)-CVDIR_FEQUALDS r(s	ny =dir&CVDIR_REAR)-CVDIR_REQUALDS	in 	s, go oorry_f Bl==e;S
e->n fcrossray1ge)	conne-r.NULLr.NULLr.NULLDSfforrex->type)!|iy3;XF_JGOODir
rry_f Bl==e:iylow	ook*/
			/* can			/je cednby;f Bl*
 * 
ves)neno

sintesrrm pf		S
e */a rt 			le chcwe kc('\	 			}
		*codeal 
zone bordo

sin
envsgcorrm pfbs OK
 * otj	irs e-x->type)!&y3;XF_FLAT 		j=0;t * lo*].				t *.yd1ev-t *.yd3				t *.yy1ev-t *.y

				 norm be ege)&te-dE /*->n fcrossray1ge)&te-onne-r.NULLr.NULLr.NULLDSfforrrex->type)!|iy3;XF_JFLAT|3;XF_JFLAT1ir;}GE->na/nyx->type)!&y3;XF_FLAT 		j=0;t * lo*n].				t *.yd2(] nhs]y/3				t *.yy2(] nhs]y

				 norm be ege)&te-dE /*->n fcrossray1ge)e-r.&te-onNULLr.NULLr.NULLDSfforrrex->type)!|iy3;XF_JFLAT|3;XF_JFLAT2;rt}p
rry_		c] ==e:iylow	ook*/
	)neno

sintesrrm pfcan			/br			ftT1 ran 		c] e od
envsertical pripr _LINE) {
positborda			retn/je ced
	sr[j]irs e-x->type)!&y3;XF_HOR s */
x->isd}Xi*ne-x->isd}Xi>=0 		j=0;t * lo*].				t *.yd1ev-t *.yd3				t *.yy1ev-e->te {
		V

	 rwd
decesertical pri /* nonorm be ege)&te-dE /*->n fcrossray1ge)&te-onne-r.NULLr.NULLr.NULLDSfforrrex->type)!|iy3;XF_JID|3;XF_JID1l>	->nhs].irs e-x->type)!&y3;XF_VERT s */
x->isd}Yi*ne-x->isd}Yi>=0 		j=0;t * lo*].				t *.yd1ev-e->te {
		Vx3l rwd
deces_LINE) {
 /* nt *.yy1ev-t *.y

				 norm be ege)&te-dE /*->n fcrossray1ge)&te-onne-r.NULLr.NULLr.NULLDSfforrrex->type)!|iy3;XF_JID|3;XF_JID1l>	-GE->na/nyx->type)!&y3;XF_HOR s */
x->isd}Xi*ne-x->isd}Xi>=0 		j=0;t * lo*n].				t *.yd2(] nhs]y/3				t *.yy2(] ne->tynx  rwd
decesertical pri /* nonorm be ege)&te-dE /*->n fcrossray1ge)e-r.&te-onNULLr.NULLr.NULLDSfforrrex->type)!|iy3;XF_JID|3;XF_JID2l>	->nhs].irs /nyx->type)!&y3;XF_VERT s */
x->isd}Yi*ne-x->isd}Yi>=0 		j=0;t * lo*n].				t *.yd2(] ne->ty/
	 rwd
deces_LINE) {
 /* nt *.yy2(] nhs]y

				 norm be ege)&te-dE /*->n fcrossray1ge)e-r.&te-onNULLr.NULLr.NULLDSfforrrex->type)!|iy3;XF_JID|3;XF_JID2l>	-r
rry_f BlE
		:iylow	ook*/
	wtucan >h	/* csitmtpoi)nen-2; /actI->nnyx->type)!&y3;XF_FLAT s */nyx->type)!&y3;XF_FLAT	else  fo,p[g->ns21 );
		j=0;
dots}0][nr  ge->te {
		yle cha			}2i;SI_}dots}1]}nrP=fne->tyle cha			}2i;SI_}dots}2]}nrP=fe->tyle cha			}2i;SI_} /*->n f* tsegdiet2(d tsr.dots}2]) <= CVEPS2)forrrex->type)!|iy3;XF_J;
		E /}Entry_lastFdeces

ncisenes1;o
	)nen>frwour	e/* if WARNI,
nvs	g->cfrwour	est;

	c
te= Eao)nencorrec;
			ie.ubroutine in the S 

ncisecfrwour
 */

stati,
	
	short et rt*v
)e * */initi b/}
xim
	iirst empty* tss1 r		/usednas	rend encecr[j#
efere MAXDOTS	((NREFDOTS+1)*12)f*/
	short *vr  p         *si].			GEX_CONt *vx   p*vx      x       x;
	
	shorttp    tn].			 chcqusd, qq,		, j, n* tsr.}
x* ts1		 chcfound}2ia_ed byje cmask, ptype, nfype;j]inructs* t_diet ** ts;
	douh th
vsd2, }
x*2, eps2ortdouh thapcv[4]}2ia_fogp,et rt*vr iy0		j=0; * sizeif (s[0]))p, &nex:d;ssLINEordenNG_2	ill %r, pleaserreport	ihi1 rsi[ittf2pt1uprojne t v=				__FILE__= __;
		__e				 * sizeif (s[0]))Stra/* c>frwour	e/*WARNING_t v= e	ifnes);>f	dumpint .
g2)NULLr.NULLD;>f			is 0;tI}_fogp,et rt*v!= 0; g!iy3;
				} s *et rt*v!= 0; g!iy3;
;
			
e			is 0; e plrobably;a de*codeat c>frwour	 otj	irssg=i;
FCONCISE) 			 * sizeif (s[0]))pro;

	 = g>frwour	0x%pg
		gARNING_t v= et rt*v= e	ifnes);>
	}
x* tsP=fMAXDOTSortdotsP=f(inructs* t_diet *)mallo)(se oof(** ts)*}
x* ts) GE->ndotsP==.NULLDSj=0; * size if (s[0]))) **mallo) faile*NG_2	ill %rt v= __FILE__= __;
		__e				nxit(255dE /}E
	grev-et rt*vE /je cmask iy3;XF_JGOODir	 now *1		j=0 est rt:forrex3->X_CON)e-dE /E->nnnyx->type)!&y3;XF_JMASKfj> ((je cmask<<1)-1) els, e->nsg=i;
FCONCISE) 					 * sizeif (s[0]))found hige X1type (%x>%x)/a r0x%pt v=a			vrrrex->type)!&y3;XF_JMASK, ((je cmask<<1)-1)ongx);>f	ije cmask <<->1st[diet rt*vr /e-e y_on 			poired rsi[ip;
	v2) /*ype, etype;is i/E->nn e-x->type)!&yje cmask )ite 
	*ygo oo g->;

ie */i

wc2*/pp3)
so			/in		 { mid/
		ofgr srrm= g
	
renvsje cah thesrrm p,	
				iharb		pge = 
	 * ot	]irs e-x->type)!&y(3;XF_JCVMASK^3;XF_JIDDSfforrqusd  ge-x->type)!&yX_CON_Fnnhs]yry )!&y3;XF_QMASK				n vpairs rex->type)!&y3;XF_JID2Sfforrqusd  ge-x->type)!&y3;XF_QFROM_IDEAL(X_CON_Fnnhs]yry ))!&y3;XF_QMASK				n vpa */}>stebas3;XF_JID1v2) /*yqusd  g3;XF_QFROM_IDEAL(e-x->type))!&yX_CON_Fnnhs]yry )!&y3;XF_QMASK		
;
p * loe-em		prex3->X_CON)p		>t.ge );>		;->nsg=i;
FCONCISE) 				e* sizeof (s[0] "Wl %p/prev ->	0x%pg"ongx %pe-diriy	 now *prex->type)!&y3;XF_JCVMASK els, e->n !*prex->type)!&y((3;XF_JCVMASK^3;XF_JIDD|3;XF_JID2)DSfforr	qq  g3;XF_QFROM_IDEAL(prex->type));>f	iix1; 			I_qq  gprex->type)!&y3;XF_QMASK		
;
e->nsg=i;
FCONCISE) 					 * sizeif (s[0]))(%x?%x)"onqusd, qq)		
;
e->n !*qusd & qq)j].low <=->n !*X_CON_Fnp			c&y(3;XF_JCVMASK^3;XF_JIDD 					s *pe-x->type)!&y(3;XF_JCVMASK^3;XF_JIDDSf low <= 			retupreviosncorreciss
efer
aely;a bett emm
tchractI_}	firspte-		n			cotI_}	fe->nsg=i;
FCONCISE) 								 * sizeif (s[0]))\nprev idd  bett emm
tchra r%pt v=ape-dir	- (giet rt*vr /e-er	- (gigo oo g->;
- (gi->ix1;
			gi
p * los].s]extrem		
	)
				[j].al>	ge->
	}
qusd &= qql>	gep * los].s].ge ;>	gep *x3->X_CON)p		>t.ge );>;
e->nsg=i;
FCONCISE) 					 * sizeif (s[0]))0x%pg"onpe-dir;
e)
.h			collne 3a		 retuesrrm pf;pr je c	}

]		le
	 h th*e ;
n * loe-s]extrem		ne-x3->X_CON)ne-di 			nne-x3->X_CON)ne-v-extr)  >		;->nsg=i;
FCONCISE) 				e* sizeof (s[0] ":	0x%x\n g-> ->	0x%pg"onlue, origin, (p		vane-diriy	 now */nyx->type)!&y3;XF_JCVMASK els, e->n !*nrex->type)!&y((3;XF_JCVMASK^3;XF_JIDD|3;XF_JID1)DSfforr	qq  g3;XF_QFROM_IDEAL(nnrex->type));>f	iix1; 			I_qq  gn/nyx->type)!&y3;XF_QMASK		
;
e->nsg=i;
FCONCISE) 					 * sizeif (s[0]))(%x?%x)"onqusd, qq)		;
e->n !*qusd & qq)j].low <=->n !*X_CON_Fnn		>t.ge )r&y(3;XF_JCVMASK^3;XF_JIDD 					s *ne-x->type)!&y(3;XF_JCVMASK^3;XF_JIDDSf low <= 			retung->  g-> correciss
efer
aely;a bett emm
tchractI_}	firsnte-		n		-tyre )rl
	y1	fe->nsg=i;
FCONCISE) 								 * sizeif (s[0]))\n g-> %x idd  bett emm
tchrrean;%x a r%p (jmask %x)t v=a			vvvvvv/nyx->type)!&y3;XF_JCVMASK, rex->type)!&y3;XF_JCVMASK,     *je cmask)er	- (gigo oo g->;
- (gi->ix1;
			gi
ngrev-n		>t.ge ;m		
	)
				[j].al>	ge->
	}
qusd &= qql>	gengrev-n		>textrem		
ne-x3->    x;a			vnne-x3->X_CON)ne-v-extr) >;
e->nsg=i;
FCONCISE) 					 * sizeif (s[0]))0x%pg"onne-dir;
e)
.h->nsg=i;
FCONCISE) 				e* sizeof (s[0] ":	0x%x\n"onlue, origin, (ne-diriy	endXXX add/
/**tt = g
		urn;
corrm pfbfo gc;

	arya		S
is vem* Fosu				 			o ha	g->rend encec* tssa*tuingid r[j]  fo,pgrev-s].	 ite-!iyn		>textre pgrev-i		-tyre )rl
	y1nne-x3->X_CON)ie-dir	- ->n !*n/nyx->type)!&y3;XF_VDOTSDSf low <= seeple* ts(i		van/nyx->* tsr.NREFDOTS)er	- (n/nyx->type)!|iy3;XF_VDOTSorts	} th
	
}
			d rsi[iactuslnje c	}

r[j]  now *1		j=0;
p *x3->X_CON)p		)em		
ne-x3->X_CON)ne-v-.ge );>;
e			c('\retu;egmechss1 r		/je cedn 			pge...	 * 		S
is	ndotsP=f= 0;

RP-1pgrev-s].	 ite-!iyn		>textre pgrev-i		-tyre )rl
	y1wsp,maxdotsP< n* ts+(NREFDOTS+1))rl
	y1	fmaxdotsP+=fMAXDOTSortttttdotsP=f(inructs* t_diet *)j].llo)((the  *)* tsr.se oof(** ts)*}
x* ts) GE	y1wsp,dotsP==.NULLDSj=0;				 * size if (s[0]))) **mallo) faile*NG_2	ill %rt v= __FILE__= __;
		__e								nxit(255dE /		
	)
				}r	- (n/nyx3->X_CON)ie-dir	- y fo,p[g->nsNREFDOTS1 );
		j=0;
	>e, " group 2:     							dots}n* ts].p}			=fn/nyx->* ts}nr			E /		
	n* ts++;m		
	)
				e, " group 2:     						dots}n* ts].p}			=fie->tyle cha	j	}2i;SI_}in* ts++;m		
}
is	ndots--;i			retuurn;
le chc			 /**inte est	}

r[j
is	tp * lo*pe-er	- ptype  gprex->type)ir	- ->nptype &y(3;XF_JGOOD|3;XF_JFLAT2|3;XF_JID2)DSj=0;
	wd; /*h	}

r[j] 	->nhs].irsptype &y3;XF_JFLATDSj=0;
	tp *.yd1ev-tp *.yd3				
	tp *.yy1ev-tp *.yy
				v->nhs].irsptype &y3;XF_JIDDSl
	y1wsp,ptype &y3;XF_HOR)s, e
	tp *.yy1ev-tp *..ge -	Vy
				vvix1;
			gitp *.yd1ev-tp *..ge -	Vd3				
->
	}
tn * lo*n].					ntype  gnrex->type)ir	- ->nntype &y(3;XF_JGOOD|3;XF_JFLAT1|3;XF_JID)s, es *!nntype &y3;XF_JID2)DSj=0;
	wd; /*h	}

r[j] 	->nhs].irsntype &y3;XF_JFLATDSj=0;
	tn *.yd2(] tn *..ge -	Vd3				
	tn *.yy2(] tn *..ge -	Vy
				v->nhs].irsntype &y3;XF_JIDDSl
	y1wsp,X_CON_Fnn		) &y3;XF_HOR)s, e
	tn *.yy2(] tn *.Vy
				vvix1;
			gitn *.yd2(] tn *.Vd3				
->
	}
 norm be ege)&tp		)em		
 norm be ege)&tne-dir	- ->n fcrossray1ge)&tpe-r.&tne-r.NULLr.NULLr.&apcv[1ifjDSl
	y1wapcv[0	}Xi avtp *..ge -	Vd3				
wapcv[0	}Yi avtp *..ge -	Vy
				vv */apcv[1igr			opcv}2] wtrl fillednby;fcrossray1ge))ractI_}	opcv}3	}Xi avtn *.Vd3				
	opcv}3	}Y](] tn *.Vy
					vv */>alc* Blueretuprecislyps
epe

	= g
)
s[e1smo h emdimecslyps
		retuc}
		ractI_}	}
x*2(] opcv}3	}Xi-apcv[0	}Xi;tI_}	}
x*2(*= }
x*2				vvips2(] opcv}3	}Yi-apcv[0	}Yia_				ips2(*= eps2orty1wsp,maxd2 <heps2)s, e
	ips2(] }
x*2				vvips2(*= (CVEPS2*4.),wi,400.*400.);>f	ii	hsips2(< CVEPS2)forr
	ips2(] CVEPS2				vvix1; 	hsips2(> CVEPS2*4.)forr
	ips2(] CVEPS2*4.					vvfapprox	}
		(apcv,;* tsr.n* ts],


	>favsd2  g * t	}
	diet2(apcv,;* tsr.n* tsr.&}
x*2	a >GR=e->nsg=i;
FCONCISE) 						e* sizeof (s[0] "	vsd er%g,r}
x* er%g,rv=asqrt(avsd2)=asqrt(}
x*2	);>f	ii	hsavsd2 <= ips2(s *maxd2 <= ips2*2.f low <= 			we'			gue
	igiai	}
				 						
loif({
			fp in
	rgiggoo=cv++; ggoo=cvdotsP+=fn* ts1
GE	y1wsp,sg=i;
FCONCISE)  j=0;				 * sizeof (s[0] "enNG_2je cedn%p-%* to v= e	ifnesonpe-onne-dir;
				e, "p[g->ns4! );
		j=0;;				 * sizeof (s[0] " (%g, %g)v= apcv[i]	Xi= apcv[i]	Y]) GEEEEEE}=0;				 * sizeof (s[0] "c;
		mory forrrrrdumpint .
g2)pe-onne-dir;
			}

				e, "p[g->ns3! );
		j=0;;			s].s]exn}nrP=fapcv[i+1	}Xi;tI_}			s].s]eyn}nrP=fapcv[i+1	}Yia_					}

				pny = nge->y3;
				}a_					grev-s].	

				e, "p * los].s]extre e pgrev-p		-tyre )rl
	y1	fe->nite-		np			cotI_}	fe; * sizeif (s[0]))p, &nex:d;ssLINEordenNG_2	ill %r, pleaserreport	ihi1 rsi[ittf2pt1uprojne t v=									__FILE__= __;
		__e								_ ren(* ts) GE	y1w	r)*is 0;tI_EEEE}=0;				gp,et rt*vr iyie-dGE	y1w	ret rt*vr /s].	

				_ ren(iny =g->)	

				_ renrn 1ge)ie-dir;
				->nite-		nne-dGE	y1w	r[j].al>	ge		}

				enorm be ege)e-dir;
			sp,sg=i;
FCONCISE)  j=0;				 * sizeof (s[0] "gorm be od "dir;
				e, "p[g->ns3! );
		j=0;;				 * sizeof (s[0] " (%g, %g)v= e->tyle cha	X][nr=ae->tyle cha	Y]}i]dErEEEEEE}=0;				 * sizeof (s[0] "mory forrrr}

				eogaly ege)e-dir;
			 rgaly eje ch(e-dir;
			 rgaly ege)e-v-.ge );>;
e		 rgaly eje ch(e->t.ge );>		;	= 			retu esul
seo

sii_2je c willrn 			poibtu ecsn			cied r[j].hiiet rt*vr /e- loe-s]extrem			gigo oo est rt;m		
	)>ix1; low <= gba=cv++; gba=cvdotsP+=fn* ts1
rrrr}

		->
	}
			i

wc'rus
own to 2 corrm pfty3)
s[e1je c */
	faile*N*/=	ii	hsp		-tyre -		nne-d low <=pe-x->type)!&= ~je cmask;>f	ii	hssg=i;
FCONCISE) 						e* sizeof (s[0] "nomm
tchmory forrrgo oo g->;
- (->
	}
			ieduce	returrst emptycorrm pfby;dropp	= g
)					sof }e

=				br ihould/netderdrop	retutri	pgal gth;
			retura/* 				br/	
;
e->nne-v-.ge -		n		 >GR=||/s].-!iygsPlb (prex->type)!&y3;XF_JCVMASK e<= */nyx->type)!&y3;XF_JCVMASK ed low <=pe- los].s]extrem		
)>ix1; low <=ngrev-n		>t.ge ;m		
} th=->nsg=i;
FCONCISE) 					 * sizeif (s[0])) g-> try: %* to %pt v=ape-onne-dir;
e)
 g->:forre loe-s]extrem		->nny-		net rt*vd low <je cmask iy(je cmask >> 1		&y3;XF_JCVMASKir	- ->nje cmask iiy0	
1w	r[j].al>	g}ns}S
e */je c f Blu;egmechssn, oo		ifsthe ;y_one			ge==et rt*vrhe ; now *1		j=0;rex3->X_CON)e-dE /E->n*!nnyx->type)!&y3;XF_J;
				 
	*ygo oo g->2a_
		ndotsP=f= 0;
dots}n* ts].p}X](] nhs]y/3 0;
dots}n* ts].p}Y](] ehs]yn3;
}in* ts++;m
;
p * loe->t.ge ;m		n * loe-s]extrem
.h->nsg=i;
FCONCISE) 				e* sizeof (s[0] "je c	}

;
		h;
			%p-%*t v= e	vane-diriy	 now *p *!=ne-d low <p *x3->X_CON)p		)em		
ne-x3->X_CON)ne-	a >GR=->nsg=i;
FCONCISE) 					 * sizeif (s[0]))(p=%p/%x n=0x%x/%x)/v=ape-onprex->type)!&y3;XF_J;
		=a			vvvlue, origin, (ne-,*/nyx->type)!&y3;XF_J;
			ir	- ->n !*(prex->type)!|a/nyx->type))!&y3;XF_J;
				 Sl
	y1wsp,sg=i;
FCONCISE) 						e* sizeof (s[0] "(eizop=%p n=%p)/v=ape-onne-dir;
		[j].al>	ge->
	}
sp,maxdotsP< n* ts+2].low <=maxdotsP+=fMAXDOTSorttttdotsP=f(inructs* t_diet *)j].llo)((the  *)* tsr.se oof(** ts)*}
x* ts) GE	y1sp,dotsP==.NULLDSj=0;			 * size if (s[0]))) **mallo) faile*NG_2	ill %rt v= __FILE__= __;
		__e							nxit(255dE /		
}m		
} th=->nnprex->type)!&y3;XF_J;
		Sf low <= fo,p[g->ns21 );
		j=0;

wapcv[0	}nrP=fp		>t.ge >tyle cha			}2i;SI_}
wapcv[1]}nrP=fne->tyle cha			}2i;SI_};
dots}n* ts].p}nrP=fp		>tyle cha			}2i;SI_};}r	- (n* ts++;m		
	 fo,p[g->nsn* ts1 );
		j=0;g;;avsd2  g * tsegdiet2(apcv,;* ts}i].pdEr;
			sp,avsd2 > CVEPS2)forr
	r[j].al>	ge	}GE	y1sp,nsn* ts el.lowfaile*N->sje cractI_}	firssg=i;
FCONCISE) 							 * sizeif (s[0]))faile*N->sje crprev %pg"onpe-dir;
	s	ndots--;

				pnyx->type)!&= ~3;XF_J;
		E /	
	)>ix1; low <= p * los].s].ge ;>	ge	firspte-		nn			cotI_}	fe->nsg=i;
FCONCISE) 								 * sizeif (s[0]))inte sne igiatrprev %pg"onpe-dir;
	s	r[j].al.lowoop s trm *N->sself-inte sne ractI_}	f)
				}r	- ->nhs].irssg=i;
FCONCISE) 					 * sizeif (s[0]))(p=%p)g"onpe-dir th=->nn/nyx->type)!&y3;XF_J;
		Sf low <= fo,p[g->ns21 );
		j=0;

wapcv[0	}nrP=fp		>tyle cha			}2i; e plgtule chs/be foe	}
		1sti;egmechiactI_}	fapcv[1]}nrP=fne->tyre >tyle cha			}2i;SI_}
wdots}n* ts].p}nrP=fne->tyle cha			}2i;SI_};}r	- (n* ts++;m		
	 fo,p[g->nsn* ts1 );
		j=0;g;;avsd2  g * tsegdiet2(apcv,;* ts}i].pdEr;
			sp,avsd2 > CVEPS2)forr
	r[j].al>	ge	}GE	y1sp,nsn* ts el.lowfaile*N->sje cractI_}	firssg=i;
FCONCISE) 							 * sizeif (s[0]))faile*N->sje cr g-> %pg"onne-v-extr) >;
es	ndots--;

				nnyx->type)!&= ~3;XF_J;
		E /	
	)>ix1; low <= ngrev-n		>textrem		
	}r	- ->nhs].irssg=i;
FCONCISE) 					 * sizeif (s[0]))(n=%p)/v=ane-dir;
e)
.hpe- los].s]extre  			c('\retuf miEsn 			pge...	 * ones.si		ractI_irspte-		nn			c/*gr deeply\pertdesi		r>frwour	 ot
	r[j].al>
.h->nsg=i;
FCONCISE) 	j=0;
e* sizeof (s[0] "moenNG_2je cedn;
		S%p-%* ;
		mor= e	ifnesonpe-onne-dir;
	dumpint .
g2)pe-onne-dir;
}
		pny = nge->y3;
;
		E /	 fo,p[g->ns21 );
		j=0;
p		>tyle cha			}2iP=fne->tyle cha			}2i;SI_intsonorm be ege)pe-dir;
X_CON_Fnp			c&= ~3;XF_J;
		E 
		grev-s].	

	e, "p * los].s]extre e pgrev-p		-tyre )rl
	y1->nite-		np			cotI_}	 * sizeif (s[0]))p, &nex:d;ssLINEordenNG_2	ill %r, pleaserreport	ihi1 rsi[ittf2pt1uprojne t v=						__FILE__= __;
		__e						 ren(* ts) GE	y1)*is 0;tI_E} th=->net rt*vr iyie-dGE	y1et rt*vr /s].	

		 ren(iny =g->)	

		 renrn 1ge)ie-dir;
	->nite-		nne-dGE	y1[j].al>	g}n g->2:forre loe-s]extrem		->nny-		net rt*vdt
	r[j].al>prevw ren(* ts) Gnue;
	
deces

ncisenes1: substitute 2 or mfoe		}
		ddgo	}

in		 {
** see aqusdr;chcwst p)nen>}
		t**/in f oat	}

le ch
dres>nsg-f;prce

ncise(
	     /

stat g
)e *
	
	shorttttttttt*         *seiz   *sxge;S
e;ssLINEsf oat
g2)"en;prc = g>frcisenes1ry f, fdnhsmall
g2)0.05dE /;ssLINint (e	iesrrm p,	__FILE__= __;
		__= e	ifnes);>
	irssg=i;
FCONCISE) 			dumpint .
g2)NULLr.NULLD;>
h			collne 3mfoe	in;prmsafe,eab
vesn the*correca			retir je chs r[jw fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)m		-> nny = nge->iy3;
				} ||ae- = nge->iy3;
;
			

		 norm be ege)e-dirjw fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)m		-> nny = nge->iy3;
				} ||ae- = nge->iy3;
;
			cotI_}allo)_gex_

n(		)em		
 ogaly ege)e-dir;
	fpr */
ee w				wtucae goeab
vesje c	}

r[j] fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)m		-> nny = nge->iy3;
				} ||ae- = nge->iy3;
;
			

		 rgaly eje ch(e-dir
e			c('\d rsi[ije c	}

r[j] fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)m		->nny = nge->iy3;
MOV		

		 

ncisecfrwour
g,oe-s] g->)irjw fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)m		-> nny = nge->iy3;
				} ||ae- = nge->iy3;
;
			

		 ren(ny =g->)	
}es>nsg-* siz_gARNI(
	    chcgARNIno
)e */


stattttttttt* ;
	
	shorttttttttt*  ;_ed byyyyyyyyyyyyy <] =,	yg->0;_ed byyyyyyyyyyyyyi;_ed byyyyyyyyyyyyygrp,uurn;grp->-1l>
	irssg=i;
FCONCISE) s */ARNInor iy0		j=0; * sizeif (s[0]))Gue
	igi	}
		d: ba*NGd/%d	goo=NGd/%dt v=				gba=cv, gba=cvdots, ggoo=cv, ggoo=cvdotsdE /}E
	gg->&/ARNI_liet[/ARNInoia_fo * sizeipfa_file]))/G_2{ t v= e	ifnes);>
h			con			ciawidt . >MAXLEGALWIDTH
]		bugssr[j]irs e->s>altdwidt e<= MAXLEGALWIDTH
		j=0; * sizeipfa_file]))03%dihsbwt v= e	is>altdwidt dE /}>ix1; low  * sizeipfa_file]))031000ihsbwt vdir;
p, &nex_2M * sizeof (s[0] "gARNING_:awidt 3%disnemss1 r		/st=gy,
	eS]i]]1000t v=				g	ifnesone	is>altdwidt dE /}fp#i

0f  * sizeipfa_file]))%%r>frwour_:a;
			 fo ,pg->g->n < g	if>frwour_1 );
	ow  * sizeipfa_file]))%s(%d,%d)/v=a(e	i>frwour_}i].
zone bord iyDIR_OUTER ? "
ve" :))in")=				g	i>frwour_}i].xofm c,	g	i>frwour_}i].ym c
			 * sizeipfa_file]))mory f, -> nn->rym cj< 5000	ow  * sizeipfa_file]))%d lowerG_t v= e	irym c=a(e	if Blym cj? "f Bl" :))	}
		")) GE-> nn->rymax > -5000	ow  * sizeipfa_file]))%d upperG_t v= e	irymax=a(e	if Blymax ? "f Bl" :))	}
		")) G#e

	f>
;-> nn->hstems)

	e,  ,pg->g->n < g	ifh_1 )P+=f2)rl
	y1-> nn->hstems}i].type)!&yST_3	cotI_}	 * sizeipfa_file]))%d %d %d %d %d %d hstem3t v=						n->hstems}i].ing a=					n->hstems}i + P].ing as-.e->hstems}i].ing a=						n->hstems}i + 2].ing a=						n->hstems}i + 3].ing as-.e->hstems}i + 2].ing a=						n->hstems}i + 4].ing a=						n->hstems}i + 5].ing as-.e->hstems}i + 4].ing a						) GE	y1sP+=f4em		
)>ix1; low <= * sizeipfa_file]))%d %d hstemt v= e	ihstems}i].ing a=					n->hstems}i + P].ing as-.e->hstems}i].ing a);tI_E} th}>
;-> nn->vstems)

	e,  ,pg->g->n < g	ifv_1 )P+=f2)rl
	y1-> nn->vstems}i].type)!&yST_3	cotI_}	 * sizeipfa_file]))%d %d %d %d %d %d vstem3t v=						n->vstems}i].ing a=					n->vstems}i + P].ing as-.e->vstems}i].ing a=						n->vstems}i + 2].ing a=						n->vstems}i + 3].ing as-.e->vstems}i + 2].ing a=						n->vstems}i + 4].ing a=						n->vstems}i + 5].ing as-.e->vstems}i + 4].ing a						) GE	y1sP+=f4em		
)>ix1; low <= * sizeipfa_file]))%d %d vstemt v= e	ivstems}i].ing a=					n->vstems}i + P].ing as-.e->vstems}i].ing a);tI_E} th}>
; fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)	j=0;->sg	ifsg>0		 s, errp-e-s]stemidir;
	->nrrp >iy0 s */rp !iyurn;grp)  low <= * sizeipfa_file]))%d 4/>allsubrt v= erp+e	ifemsesubr) GE	y1urn;grp-grp;tI_E} th}>
;	swstthenny = nge		 s, caser3;
MOV	:
	y1-> nabsolute)ow <= * sizeipfa_file]))%d %d amovetot v= e	->ix3= e	->iy3);>f	iix1;GE	y1)moveto(e	->ix3s-.x= e	->iy3s-.ydir;
	-> (0 					 * sizeif (s[0]))GARNING_:a* siz moveto(%r, %d)t v=						n->fnesone	->ix3= e	->iy3);>f	ix loe-s]id3				
yg->e->tiy
				v[j].al>	gcaser3;
;
		:
	y1-> nabsolute)ow <= * sizeipfa_file]))%d %d a	illtot v= e	->ix3= e	->iy3);>f	iix1;GE	y1)	illto(e	->ix3s-.x= e	->iy3s-.ydir;
	x loe-s]id3				
yg->e->tiy
				v[j].al>	gcaser3;
				}:
	y1-> nabsolute)ow <= * sizeipfa_file]))%d %d %d %d %d %d ar	}
		tot v=						n-s]id1= e	->iy1= e	->ix2= e	->iy2= e	->ix3= e	->iy3);>f	iix1;GE	y1)r	}
		to(e	->ix1s-.x= e	->iy1s-.y=						  e	->ix2s-.e->tid1= e	->iy2s-.e->tiy1=						  e	->ix3s-.e->tid2= e	->iy3s-.e	->iy2dir;
	x loe-s]id3				
yg->e->tiy
				v[j].al>	gcaser3;
PATH:
	y1
loifint ()				v[j].al>	gdefaul>:for
p, &nex_1M * sizeof (s[0] ") ** GARNING_:aunkc('n correc nge-'%c't v=					n->fnesone	-> nge					v[j].al>	g}ns}S
e * sizeipfa_file]))e

/f(si} NDmory fnue;
	* siz s[e1subr		t	ifst
			reis WARNI,r)*is 0s	returrst emptysitmtr[j ch
* siz_gARNI_subs(
	    chcgARNIno,
	    chcet rtidn/*gst rturrst eing
	ubr		t	ifst

			reest;*N*/=)e */


sta* ;
	 ch		, grp;t
	gg->&/ARNI_liet[/ARNInoia_fo->n!h chs ||a!	ubh chs ||ag	ifsg<1), iy is 0 =;t
	g	ifemsesubr=et rtid;fp#i

0f  * sizeipfa_file]))%%rG_2%rt v= g	ifnesone	ifsg) G#e

	f>	e, "grp-0;/erp<e	ifsg;/erp;
		j=0; * sizeipfa_file]))dup %d {t v= et rtid;
	E /	 fo,p[ "grp-=0)?y0 :ne	ifsbs[grp-1]! )<e	ifsbs[grp]1 );
	ow 	 * sizeipfa_file]))mt%d %d %cstemt v= e	isbstems}i].low=a			vve	isbstems}i].hige-e	isbstems}i].low=			vve	isbstems}i].is_LIN ? 'v' :n'h'e				 * sizeipfa_file]))mty is 0\n\t} NPt vdir;}S
en't fine	ifsg;
}es>nsg-* siz_gARNI_metrics(
yyyyyFILE *afm_file]
	    chccode]
	    chcgARNIno
)e */


sta* ;

	gg->&/ARNI_liet[/ARNInoia_fo->ntra/s;prm)
	   * sizeiafm_file] "C %d ; WX %d ; NrG_2; G %d ; B %d %d %d %d ;t v=			 ccode]ne	is>altdwidt = g	ifnesoneARNIno,
		 cis>altsg	ixM c
,cis>altsg	iyM c
,cis>altsg	ixMax
,cis>altsg	iyMax
dir;ix1;GE   * sizeiafm_file] "C %d ; WX %d ; NrG_2; G %d ; B %d %d %d %d ;t v=			 ccode]ne	is>altdwidt = g	ifnesoneARNIno,
		 cg	ixM c= g	iyM c= g	ixMax= g	iyMax);
p}es>nsg-* siz_gARNI_metrics_ufm(
yyyyyFILE *ufm_file]
	    chccode]
	    chcgARNIno
)e */


sta* ;

	gg->&/ARNI_liet[/ARNInoia_f  // Mo
	fm *N->s		tput >h	ract emspec	fmc bounding
box	siassn, AFM filesfo->ntra/s;prm)
yyyy * sizeiufm_file] "U %d ; WX %d ; NrG_2; G %d ; B %d %d %d %d ;t v=
	    code]ne	is>altdwidt = g	ifnesoneARNIno,
yyyy cis>altsg	ixM c
,cis>altsg	iyM c
,cis>altsg	ixMax
,cis>altsg	iyMax
di
yyix1;
yyyy * sizeiufm_file] "U %d ; WX %d ; NrG_2; G %d ; B %d %d %d %d ;t v=
	    code]ne	is>altdwidt = g	ifnesoneARNIno,
yyyy cg	ixM c= g	iyM c= g	ixMax= g	iyMax);p}ey_laSB:
 An import;chcnot grb
vesointBg aVng as._f T[[iAdobus
ocumechsafe,esays\	 			}
		}
xim
	iwidt 3ofgr Bg a zone
				
onnne igi1 rsi[iing a			/Bg aS>alt, whitheipfby;defaul>)0.039625.f T[[iBg aS>altiing a	
eferes,iatrwhithele chcse o	retuttdeshoot
gsuppr

	 on			/disah td._f T[[i;prmulat
			ihi1 						g	v3)
in		 { manuslnis:_f  Bg aS>alt=le ch_se o/240,t
			a 300dpi	
evice_f 1 			m* Fs/us won	ciaw 						reest240 et nding

		. Incidechslly
t240=72*1000/300, whe			72				reerrelsafe,ebetwe3)
inchedd 			me chaP
31000i			reerse o	o

sintgARNINmatrix=  			300dpi				reerresolutlyps
	
	retut	tput 
evice. Know = gt				wtucae re>alc* Blueretu;prmulat
		
eretu;pchcse o	 crpixix1 raretrrrean;me cha:_f  Bg aS>alt=lixix_se o/1000_f T[				ookdd  lohcseeplerrrean;retutri	pgal ;prmula,;* e		 /**iN ?
 And\retuf miEsafe,eab
ves}
		}
xim
	iwidt 3ofgz
)			lso		ookd
d  lohcseeplerraftciaretutra/s;prmsafe,:_f  }
x_widt e<31000/lixix_se o_f 1 			ensu		s\	 			ev3)
1es}
		}
xim
	ilixixcse o	wy3)
s[e1ttdeshoot
gsuppr

	 on	iss
isah td
s[e1z
)		widt ewillrb /	essrrean;
)		lixix.f T[ipfbs import;ch,wfailu				>scsmply\1 rsi			l miEewillr esul
	 c
 j].lly ugARu;pchs (be3)
s[ere,;* n			 		). Bvesknow = gt	tu;prmula
e
			retupixixcwidt = we/
ee 1 				nwfac		wtucae uses}
		}
xim
	iwidt 
e		/24,	 /**23iassspec	fmigin,		 { manusl._fdres#
efere MAXBLUEWIDTH
(24)try_lastF				retu			exess
		retu}ostt

equechiing aslastn,		 { hystogram= eort	sitmtn,	asce

	= g
r	ci=  			s 			whitheone
	* was.	g->b	ses)nen(i

rsked)er t R*is 0s	returrst emptying ashfound (mayrb /	essrrean;}
xim
	ibe>ause
	* wtu	gnfoe	}
		zeroying as)e rout#
efere MAXHYST	(2000	}
			se o	o

sinthystogramcr[j#
efere HYSTBASE 500utine in  ch
b	sehyst(
	  chc*hyst,= 			retuhystogramcr[j	  chcbase,= 			retubase/me ch		

sinthystogramcr[j	  chc*b	se,= 			retua*/
	t
			i		exess
		b	sesing ashr[j	  chcnb	se,= 			iEsn llo) ted	se o	r[j	  chcwidt =is veminim
	i
	fnd encecbetwe3)
in	exessr[j	  chc*b	sein	p}
			ieis 0igi1 p/me ch	*/=)e */ue, origi/f(si  hused[MAXHYST / 8 + P];_ed byyyyyyyyyyyyyi,r}
x, j, w,uurn;g->0;_ed byyyyyyyyyyyyynf(] =;t
	widt --;
 /memset)hused,y0 ,hse oofthused);>
	}
x ->1st[e,  ,pg->g->n < nb	se(s *max-!iy0;/);
		j=0;best}i] =f= 0;
}
x ->0;

	e,  ,j ->1s j < MAXHYST ->1s j;
		j=0;
w ->hyst			E 
	y1-> nw >*max-lb (hused[j>>3] &y(1 << ,j & 0x07)))r iy0		j=0;0;best}i] =fjst[dir}
x ->w;tI_E} th}>y1-> nmax-!iy0)rl
	y1-> nmax-<uurn;/2].low <=			d r /**pi}

retutoo		owsing ashr[j				[j].al>	ge->	
	e,  ,j ->best}i] -cwidt s j <->best}i] +cwidt s j;
		j=0;g;-> nj >iy0 s *j < MAXHYST 						hused[j >> 3] |=y(1 << ,j & 0x07))l>	ge->	
	urn;g->max				v[est}i] -=ubase				vnf(] i + Pl>	g}ns}S
e-> nb	sein	p 			*b	sein	p ->best}0];>
h			eort	sit
in	exessn,	asce

	= g
r	ci
r[j] fo (pg->g->n < nf;/);
		j=0;e,  ,j ->i + Pl*j < nf;/    				-> nb	se}			<>best}i]		j=0;g;w ->best}i];=0;0;best}i] =fb	se}		;=0;0;best}			=fw;tI_E} t}S
en't finnfa_ntry_lastF				retu g-> b	se(Bg a zonetn,		 { hystogramer t R*is 0		 { wei	ftT	

sintfound zone.ubroutine in  ch
b	sebg a(
	 short	*zhyst,= 			retuzonesthystogramcr[j	 short	*physt,= 			retule chs/hystogramcr[j	 short	*ozhyst,= 			retuoretrrzonesthystogramcr[j	  chc*bg atab= 			whe			1 rpves}
		found zone	*/=)e */d byyyyyyyyyyyyyi,rj, w,u}
x, 			,umemse,uurn;;>
h			
				retuhige n;
le chc	n	retuzonesthystogramcr[j	 */i

wc2*/				 p Bluau, t* FoiEsnce
tci
r[j] */i

wc2*/			multip
		l].as, t* Fo}
		femse one	*/=
	}
x ->-1l>	femse =uurn;g->-10st[e,  ,pg->g->n <= MAXHYST ->MAXBLUEWIDTH;/);
		j=0;w ->zhyst}i];=0;-> nw >*max 	j=0;
eemse =uurn;g->i;tI_E}
x ->w;tI_->nhs].ir nw ==*max 	j=0;
ir nurn;g-->i ->1)GE	y1urn;g->i;tI_}>	-GE-n* er(eemse +uurn;d
			 f, -> n}
x -iy0)
	wd; /uzonestlefhiactI_y is 0 =;t
				c('\werreuses`eemse'  			`urn;'iassn,es.si		rb
r	ciss
		retuzone	*/=
eemse =u-n*;tIurn;g->i			+ (MAXBLUEWIDTH
->1);t
				our	}
xim
	iwidt 3 1;f(sitoo	big= eo\werrrec ]]m* FoiEena*/owerrhe ; g->max			j ->nw &>1);vv */a pseudo-ra/dom	bitrhe ; now  *1		j=0; now  *physt[eemse] iiy0	
1w	eemse++;m		 now  *physt[urn;] iiy0	
1w	urn;--;

	ir nurn;g-	femse < (MAXBLUEWIDTH
* 2
		3) ||an}
x -cwDS r10 >*max 			v[j].al>

	ir nphyst[eemse] < physt[urn;]
		 c  ||aphyst[eemse] iiyphyst[urn;] s *j 	j=0;
ir nphyst[eemse] * 20 >*w)] */i

wci	ftT 1;>5%=								br in p/r[j				[j].al>	gew -=uphyst[eemse];
1w	eemse++;m			j ->0;tI_->nhs].j=0;
ir nphyst[urn;] * 20 >*w)] */i

wci	ftT 1;>5%=								br in p/r[j				[j].al>	gew -=uphyst[urn;];
1w	urn;--;

		j ->1st[g}ns}S
e */s 			our	zone	*/=
bg atab}0](] femse - HYSTBASE;=
bg atab}1](] urn;g-	HYSTBASE;=j] */iningid.t gr ha	g->zonestttdelapp	= gwst psi			one	*/=
/vs	g->cfrst;chc		/2giss
etcim cednby;retu*efaul>)ing a			/Bg aFuzz
r[j] fo (pg->femse - (MAXBLUEWIDTH
->1) - 2->n <= urn;g+ 21 );
	ow ir ni >iy0 s *i < MAXHYST .j=0;
zhyst}i] ->0;tI_	ozhyst}i] ->0;tI_}pwn't finwa_ntry_lastTrec ]]
				retuBg a Vng as, bounding
box  			iEslin ang tubrout>nsg-f			bg as(the )e */y_onystogramst
			upper  			lower>zonestr[j]ihort											nystl[MAXHYST];
1ihort											nystu[MAXHYST];
1ihort											zuhyst}MAXHYST];
1ihort											zlhyst}MAXHYST];
1d byyyyyyyyyyyyyn/f(ss;
1d byyyyyyyyyyyyyi,rj, k, w,u}
x;
	
	shorttttttttt*  ;_e


stattttttttt* ;
	douh thhhhhhhhhhang;>
h			
				retulowen;gand hige n;
le chsg
		gARNIsthe ;y_oand by;retuwayrbuil		retuing ast
			FontBBoxthe ;y_oand buil		retuhystogramc
			retuIEslinAng th		S
e */re-usesnystlc
			retuhystogramc
		iEslin ang th		S
ebbox}0](] bbox}1](] 5000;
ebbox}2](] bbox}3	  ge5000;
j] fo (pg->g->n < MAXHYST1 );
	ow nystl[i] ->0;t
	n/f(ss ->0;t
	 fo (pg->g, gg->/ARNI_liet->n < numgARNIs1 );
, g;
		j=0;-> nn->type)!&y3F_USEDDSl
	y1n/f(ss++;m
;
	n->rym cj] 5000;
e
	n->rym
x ->-5000;
e
	 fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)	j=0;		-> nny = nge->iy3;
;
			cot						jg->e->tiy
s-.e->te {
		iy
				v		k loe-s]id3s-.e->te {
		id3				
	;-> nj >y0	
1w	r		angP=fat;c2(-k, jDS r180.0
		M_PI				
	;ix1;
			gi
angP=fat;c2(k, -jDS r180.0
		M_PI					v		k /=3100;						jg/=3100;						-> nangP> -45.0 s *angP< 45.0	cotI_}	fey_l						br btucarefulc ]] /**ttdeflowl						br 	g->cfu
tcil						brctI_}	f nystl[HYSTBASE + (be>)	nangP r10.0	]P+=f(kP rk + jnvsjd
		4;						}						-> ne->tiy
s==.e->te {
		iy
	cotI_}	fe-> ne->tiy
s<= e	irym c		j=0;;				n->rym cj] e->tiy
				v				n->f Blym cj->1st[di			}						e-> ne->tiy
s>= e	irymax 	j=0;
				n->rymaxj] e->tiy
				v				n->f Blym
x ->1st[di			}						)>ix1; low <= e-> ne->tiy
s< e	irym c		j=0;;				n->rym cj] e->tiy
				v				n->f Blym cj->0st[di			}						e-> ne->tiy
s> e	irymax 	j=0;
				n->rymaxj] e->tiy
				v				n->f Blym
x ->0st[di			}						)
				}>nhs].ir nny = nge->iy3;
				} 	j=0;
		-> ne->tiy
s< e	irym c		j=0;;			n->rym cj] e->tiy
				v			n->f Blym cj->0st[di		}						-> ne->tiy
s> e	irymax 	j=0;
			n->rymaxj] e->tiy
				v			n->f Blym
x ->0st[di		)
				}r	- (-> nny = nge->iy3;
;
		 ||ae- = nge->iy3;
				} 	j=0;
		-> ne->tix
s< bbox}0])forr
	r[box}0](] e-s]id3				
		-> ne->tix
s> bbox}2])forr
	r[box}2](] e-s]id3				
		-> ne->tiy
s< bbox}1])forr
	r[box}1](] ehs]iy
				v		-> ne->tiy
s> bbox}3	)forr
	r[box}3](] ehs]iy
				v	}m		
} th}ns}S
e */get	retu}osttpopular ang th		S
}
x ->0;

w =h0;jw fo (pg->g->n < MAXHYST1 );
		j=0;-> nnystl[i] >*w)	j=0;
w ->hystl}i];=0;0}
x ->i;tI_}>	-GEangP=f(douh t)an}
x -cHYSTBASEd
		10.0;tIp, &nex_2M * sizeof (s[0] "Gue
	igiiEslin ang t: %ft v= ang) GE-> niEslin_ang thiiy0.0	
1wiEslin_ang thihang;>
h			buil		retuhystogramc
		retulower>pe chs r[jw fo (pg->g->n < MAXHYST1 );
	ow nystl[i] ->0;t
	 fo (pg->g, gg->/ARNI_liet->n < numgARNIs1 );
, g;
		j=0;-> nnn->type)!&y3F_USEDD
		 c  s */->rym cj+ HYSTBASE >iy0 s */->rym cj< MAXHYST ->HYSTBASEd
j=0;
nystl[/->rym cj+ HYSTBASE]++;m		}ns}S
e */buil		retuhystogramc
		retuupper pe chs r[jw fo (pg->g->n < MAXHYST1 );
	ow nystu[i] ->0;t
	 fo (pg->g, gg->/ARNI_liet->n < numgARNIs1 );
, g;
		j=0;-> nnn->type)!&y3F_USEDD
		 c  s */->rym
x + HYSTBASE >iy0 s */->rymax-<uMAXHYST ->HYSTBASEd
j=0;
nystu[/->rym
x + HYSTBASE]++;m		}ns}S
e */buil		retuhystogramc
		r ha	g->le
	 h thlower>zonestwst pm
x widt 3r[jw fo (pg->g->n < MAXHYST1 );
	ow zlhyst}i] ->0;t
	 fo (pg->g->n <= MAXHYST ->MAXBLUEWIDTH;/);
		j=0;e,  ,j ->0s j < MAXBLUEWIDTH;/    				zlhyst}i] +->hystl}i + j];ns}S
e */buil		retuhystogramc
		r ha	g->le
	 h thupper zonestwst pm
x widt 3r[jw fo (pg->g->n < MAXHYST1 );
	ow zuhyst}i] ->0;t
	 fo (pg->g->n <= MAXHYST ->MAXBLUEWIDTH;/);
		j=0;e,  ,j ->0s j < MAXBLUEWIDTH;/    				zuhyst}i] +->hystu}i + j];ns}S
e */
				retubase-2; /actIw ->bestbg a(zlhyst,>hystl,	zuhyst, &bg aing as}0]) GE-> n0	ow  * sizeif (s[0] "Base-2; Bg a zonet%d%%rGd...%rt v= wP r100
		n/f(ss=					bg aing as}0], bg aing as}1]y f, -> nw -iy0)
	wd; /ubase-2; ,	sof *h	}

weirdiactI_y is 0;>
h			
				retuupper zonestr[jw fo (nbg as ->21 nbg as < 141 nbg as +=f2)rl
	yw ->bestbg a(zuhyst,>hystu, zlhyst,>&bg aing as}nbg as])l>

	ir n0 				e* sizeof (s[0] "Bg a zonet%d%%rGd...%rt v= wP r100
		n/f(ss= 					bg aing as}nbg as], bg aing as}nbg as+1])l>

	ir nw * 20 <	n/f(ss 			v[j].al=			d n't/s 			si			zone	*/=
}S
e */
				retulower>zonestr[j] fo (noretrb ->0s noretrb <310s noretrb +=f2)rl
	yw ->bestbg a(zlhyst,>hystl,	zuhyst, &oretrbg as}noretrb])l>

	ir n0 				e* sizeof (s[0] "OretrBg a zonet%d%%rGd...%rt v= wP r100
		n/f(ss=					oretrbg as}noretrb], oretrbg as}noretrb+1])l>


	ir nw * 20 <	n/f(ss 			v[j].al=			d n't/s 			si			zone	*/=
}S
ntry_lastF				retuactuslnwidt 3ofgsintgARNINand mo
	fy;retlastdescripafe,e oo eflne 3it. N/**guar;cheigi1 rdof horiy	goo=,u}
y]m* Fo>h	ract emspac = gtoo	wide.ubrout>nsg-do	e ofctwidt (the )e */d byyyyyyyyyyyyyi;_e
	shorttttttttt*  ;_e


stattttttttt* ;
	d byyyyyyyyyyyyy m c=ax}
x;
	d byyyyyyyyyyyyy}
xwidt = m csp;>
h			en;prc		si			minim
	ispac = ,
envswtuf miE	retuamfu
tno

sintes;prc	dmspac = gto a>nsg-	br ipac = gtetubol		wochss1 o	widely
	sr[j]m csp =f(indhw>60 ||aindhw<10)?y60 :nindhw;t
	 fo (pg->g, gg->/ARNI_liet->n < numgARNIs1 );
, g;
		j=0;/->ol	widt =e	is>altdwidt ; e ps 			sie ol		widt = willrneigi fo AFM r/	
;
ir n	e ofctwidt  s */->type)!&y3F_USEDDSl
	y1xm cj] 5000;
e
	xm
x ->-5000;
e
	 fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)	j=0;		-> nny = nge-!iy3;
;
		 s */
!= 0; g!iy3;
				})a			vvvpe, etype;=0;		-> nny =ix
s<=y m c 	j=0;
		xm cj] e->tix
				v	}m		
	-> ne->tix
s>=ax}
x 	j=0;
		xmax loe-s]id3				
r}

		->
	}
}
xwidt =xmax+m csp;>		]irs e->s>altdwidt e<y}
xwidt Sf low <=e->s>altdwidt e=y}
xwidt 				
rp, &nex_3M * sizeof (s[0] "gARNING_:ag->endigi 
			%gi1 r%dt v=						g	ifnesone	iol	widt ]ne	is>altdwidt  );tI_E} th}>
}S
ntry_lastTrec ]]
				retu 0;E) {
stemawidt .ubrout>nsg-stemsne istics(the )e *#
efere MINDIST	10  veminim
	i
	st;ccecbetwe3)
retuwidt . r[j]i byyyyyyyyyyyyyhyst}MAXHYST+MINDIST*2];
1d byyyyyyyyyyyyybest}12];
1d byyyyyyyyyyyyyi,rj, k, w;
1d byyyyyyyyyyyyyn/f(ss;
1d byyyyyyyyyyyyyns;
1STEMyyyyyyyyyyy*s;_e


stattttttttt* ;

e */st rtuwst ps0;E) {
stemawidt  r/	
;n/f(ss=0;>
h			buil		retuhystogramc
		ertical pristemawidt .sr[j]memset)hyst, 0,hse oofthyst);t
	 fo (pg->g, gg->/ARNI_liet->n < numgARNIs1 );
, g;
		j=0;-> nn->type)!&y3F_USEDDSl
	y1n/f(ss++;m	y1s loe	ihstems;
e
	 fo (j ->0s j < g	ifh_1 jP+=f2)rl
	y1;-> nna	j	.type)!|aa	j + P].type))!&yST_END)			vvvpe, etype;	0;
w ->a	j + P].ing as-.a	j	.ing a+1st[di	irsw==20	c/*g
/**tistems ihould/notebascfu
tcd r[j].hiipe, etype;	0;
-> nw >*0 s *w < MAXHYST ->1f low <= 		ow <= nvseand thsof }fuzz
pr

echc	now <= nvspe,_LINigi fchsow <= nv[j].hiihyst}w+MINDIST] +->MINDIST-1st[di		 fo,k=1; k<MINDIST-1s k;
		j=0;g;iihyst}w+MINDIST + k] +->MINDIST-1-al>	ge		ihyst}w+MINDIST - k] +->MINDIST-1-al>	ge		)
				}r	- -m		}ns}S
e */
				12u}ostt

equechiing asnv[j]ns ->besthyst(hyst+MINDIST, 0,hb	se,	12, MINDIST, &indhw);

e */stfoe	datac	n	stemsnap 3r[jw fo (pg->g->n < n_1 );
	ow stemsnap }i] =fb	se}i];=0-> nns < 12	ow stemsnap }ns] ->0;t
				buil		retuhystogramc
		_LINE) {
stemawidt .sr[j]memset)hyst, 0,hse oofthyst);t
	 fo (pg->g, gg->/ARNI_liet->n < numgARNIs1 );
, g;
		j=0;-> nn->type)!&y3F_USEDDSl
	y1s loe	ivstems;
e
	 fo (j ->0s j < g	ifv_1 jP+=f2)rl
	y1;-> nna	j	.type)!|aa	j + P].type))!&yST_END)			vvvpe, etype;	0;
w ->a	j + P].ing as-.a	j	.ing a+1st[di	ir nw >*0 s *w < MAXHYST ->1f low <= 		ow <= nvseand thsof }fuzz
pr

echc	now <= nvspe,_LINigi fchsow <= nv[j].hiihyst}w+MINDIST] +->MINDIST-1st[di		 fo,k=1; k<MINDIST-1s k;
		j=0;g;iihyst}w+MINDIST + k] +->MINDIST-1-al>	ge		ihyst}w+MINDIST - k] +->MINDIST-1-al>	ge		)
				}r	- -m		}ns}S
e */
				12u}ostt

equechiing asnv[j]ns ->besthyst(hyst+MINDIST, 0,hb	se,	12, MINDIST, &indvw);

e */stfoe	datac	n	stemsnap 3r[jw fo (pg->g->n < n_1 );
	ow stemsnapv}i] =fb	se}i];=0-> nns < 12	ow stemsnapv}ns] ->0;t
#undif MINDIST
ntry_lastSBlastA}funny;re = : TTF int .n 			go	}

in	retdes	/dione bordcsmp 		d
nvs	o T0; 1. Soraftciar ha(be>ause	reerrestno

logic uses TTF
nvsint /dione bor))!wc2*/			 oo etdes	/si[ip;t ..ubr
nvsIt was.a	big headacetutoi
	scttde 1 		.ubrout			work		on E
		  chcand f oat int .nrout>nsg- etdes	int . 
		to(
		 c 
	short i 
		,
		 c 
	short ito
)e */
	shorttttttttt*         *sp].			GEshorttttttttt*cur    g->;
- ch		, c=aiurn;}2i;SIdouh thfurn;}2i, firjw fo (re lo 
		; ].-!iy0 s */
-!iyto;/e- loe-s] g->)	j=0;->sgy = nge->iy3;
;
		 ||ae- = nge->iy3;
				} 	j=0;
-> nsg=i;
REVERSAL) 					 * sizeif (s[0])) etdes	/int /0x%x <-/0x%x,	0x%x\n"onlue, origin, (   *lue, origin, (  >te {
 *lue, origin, (  >t.ge );>		;				cut 
ves}
		int /itselfnv[j].hp * loe->te {
; e p3;
MOV	N*/=	ii	h spte-		n0	cotI_}	 * sizeof (s[0] ") ! N/ MOV	Nbe foe	-2; /!!! Fatal. ) **mory forrrnxit(1)l>	ge->	
	n * loe-s].ge >t g->; e p3;
PATHnv[j].hp *>t g-> 	nne-;>	
	n *>te {
  /s].	

		e-s].ge >t g->g->g-> vem*rk}e

no

/f( cract		;				remembciaretuet rti}

le chN*/=	ii	hse-s]eype)!&y3;F_FLOATDSj=0;
	furn;}0rP=fp		>tyd3				
rfurn;}1rP=fp		>tyy
				v->nhs].l
	y1;-urn;}0rP=fp		>tid3				
riurn;}1rP=fp		>tiy
				v->
	}
			ty3)
re csert	sitmtn,	backwardsg
r	ci
r[j]		 fo,cur  /e-e cur !iy0;/cur  / g->gDSj=0;
	 g->g->cur>t g->; e p			addgeaftci() willrscrewoiEeup/r[j					hscur>teype)!&y3;F_FLOATDSj=0;
	= fo,p[g->ns21 );
		j=0;

w				retdes	/si[idione bordo

int /elemechiactI_}	f	fg->cur>tyle cha			}0i;tI_}			cur>tyle cha			}0ig->cur>tyle cha			}1i;tI_}			cur>tyle cha			}1rP=ff;tI_}	f	fg->furn;}ii;tI_}			furn;}iig->cur>tyle cha			}2i;tI_}			cur>tyle cha			}2rP=ff;tI_}	f)
				}>nhs].j=0;
	= fo,p[g->ns21 );
		j=0;

w				retdes	/si[idione bordo

int /elemechiactI_}	f	ng->cur>tile cha			}0i;tI_}			cur>tile cha			}0ig->cur>tile cha			}1i;tI_}			cur>tile cha			}1rP=f0;tI_EEEEng->iurn;}ii;tI_}			iurn;}iig->cur>tile cha			}2i;tI_}			cur>tile cha			}2iP=fnst[di		)
				}r	- (addgeaftci(pe-oncur)				v->
	}
			restfoe	}
		et rti}

le chN*/=	ii	hse-s]eype)!&y3;F_FLOATDSj=0;
	p		>tyd3g->furn;}0i;tI_}	p		>tyy
g->furn;}1i;tI_}}>nhs].j=0;
	p		>tid3g->iurn;}0i;tI_}	p		>tiy
s= iurn;}1i;tI_}}m
;
	ne 	nne-;>	
}m
;}p}es>nsg- etdes	int .(
	     /

stat g
)e *	 etdes	int . 
		to(g	iesrrm p,	NULLD;>nue;
	add/a kerc	}

pair	in;prmsafe,,hs>altsrsi[iing a	rout>nsg-addkercpair(*/ue, origiid1=		ue, origiid2,
- ch	ue,cing
)e *	ine in ue, origi/f(si*bitsP=f= 0;ine in  ch urn;idir;


sta*  ->&/ARNI_liet[id1];
1d by	, c 0;inructskerc*spa_fo->nue,cing-		n0 ||aid1s>=anumgARNIs ||aid2s>=anumgARNIs), iy is 0a_fo->n (rARNI_liet[id1].type)!&y3F_USEDD==0
=||/(rARNI_liet[id2].type)!&y3F_USEDD==0 ), iy is 0a_fo->nbitsP=	n0	cotI_bitsP=fc.llo)( BITMAP_BYTES(numgARNIs), 1dE /E-> nbitsP=	nNULLDSj=0;	 * size if (s[0]))) **mallo) faile*NG_2	ill %rt v= __FILE__= __;
		__e					nxit(255dE /	}r	-urn;ids= id1;ns}S
e->(urn;ids!= id1DSj=0;			refillgtetubitmapfc.cetu*/=	imemset)bits, 0,BITMAP_BYTES(numgARNIs)dE /	p loe	ikercE /	 fo,p[e	ikerccfu
t1 )>g->n--DSl
	y1n =f(p;
	>tidir;
	SET_BITMAP)bits, ndE /	}r	-urn;ids= id1;ns}S
e->(IS_BITMAP)bits, i*2	), iy is 0a e pdupli) teract		->sg	ikerccfu
ts<= e	ikercallo)		j=0;/->kercallo) +->8E /	p loj].llo)(/->kercr.se oof(inructskercDS re	ikercallo)	E /E->(p-		n0	cotI_} * size if (s[0]))) oj].llo) faile*, kerc	}

datacwillrb /incsmpletemory for}=0;/->kercP=fp;ns}S
eSET_BITMAP)bits, i*2	;nsp ->&/->kerc[g	ikerccfu
t];
1p>tids= id2;
1p>ting-	cis>altsue,cing) - (e	is>altdwidt  -ne	iol	widt 	;nsg	ikerccfu
t++;m	kerc	}
_pairs++;mnue;
	* siz 
ves}
		kerc	}

in;prmsafe,erout>nsg-* siz_kerc	}
(*/FILE *afm_file=)e */d b	i,rj, n;*/


sta* ;
	inructskerc*spa_fo->n kerc	}
_pairs-		n0 )a			y is 0a_fo * sizeiafm_file] "St rtKercDatamory fo * sizeiafm_file] "St rtKercPairs-%hrt v= kerc	}
_pairs);t
	 fo,p[g->nsnumgARNIs1 );
)  low   ->&/ARNI_liet[i];=0;->( nn->type)!&y3F_USEDDS-=0)tI_}pe, etype;	0p loe	ikercE /	 fo,j[e	ikerccfu
t1 j>g->j--, p;
		j=0;o * sizeiafm_file] "KPXrG_2%_2%rt v= g	ifnesontI_}	/ARNI_liet[ p>tids].fnesonp>ting-y for}=0}_fo * sizeiafm_file] "EndKercPairsmory fo * sizeiafm_file] "EndKercDatamory f}_fp#i

0fry_l) oT[ipffune bord			
ommeche*N
vesbe>ause	reerin;prmsafe,l) ocollne ednby;ihc			 /**u	igianywhe			nhs].yet. N/wt**/ie onlyocollne s/si[idione borsg
		>frwour_. And\rett**/dione bordo

>frwour_/getpffixigialj].dytn,	draw_gARf().t**
***********************************************t**
** He			w		nxpne 3	 			}
		int .n 			alj].dyt
loifd.t** W			lso	nxpne 3	 			}
		>frwour_/d r /**inte sne t** a			re				}
		dd* e	n't/crossoriy	b
r	cido

qusdr;ch.t**
**tF				whithe>frwour_/go*in			c	whithea			wh					
**tretir prop emdione bor. T[[nffix/si[idione bor
**tr]]m* FoiEeri	ft.t**
*out#
efere MAXCONT	1000ut>nsg-f	x>frwour_(
	    /

stat g
)e *	CONTOURttttttttt>frw[MAXCONT];
1ihort											ym
x[MAXCONT]; 			retuhige n;
le chcr[j]ihort											xofm
x[MAXCONT]; 			X-co
r	in ter
		riy	le ch
I_}			 hort	ym
xcr[j]ihort											ym c[MAXCONT]; 			retulowen;gle chcr[j]ihort											xofm c[MAXCONT]; 			X-co
r	in ter
		riy	le ch
I_}			 hort	ym cractIihort											cfu
t[MAXCONT]; 			cfu
tno

		ifsthe ;/f(si           dio[MAXCONT]; 			 c whithedione bordrety mun;ggo*he ;GEshorttttttttt*et rt[MAXCONT], *m cptr[MAXCONT], *maxptr[MAXCONT];
1d byyyyyyyyyyyyyn/frw;
1d byyyyyyyyyyyyyi;
1d byyyyyyyyyyyyydd1= dy1= dd2= dy2			GEshorttttttttt*        ;>
h			
				retu>frwour_/a			retir }osttupper/lower>pe chs r[jwn/frwP=f= 0;ym
x[0	  ge5000;
	ym c[0](] 5000;
e fo (re loe	iesrrm p; ].-!iy0;/e- loe-s] g->)	j=0;-> nny = nge->iy3;
;
		 ||ae- = nge->iy3;
				} 	j=0;
-> ne->tiy
s> ym
x[n/frw]		j=0;g;ym
x[n/frw](] ehs]iy
				v	xofm
x[n/frw](] ehs]id3				
rmaxptr[n/frw](] ehl>	ge->	
	-> ne->tiy
s< ym c[n/frw]		j=0;g;ym c[n/frw](] ehs]iy
				v	xofm c[n/frw](] ehs]id3				
rm cptr[n/frw](] ehl>	ge->	
}=0;-> nny =yre -!loe-s] g->)	j=0;	et rt[n/frw++](] ehs]yxtrem		
ym
x[n/frw](] -5000;
e
	ym c[n/frw](] 5000;
e
}ns}S
e */
etcim ce/si[idione borsg
		>frwour_3r[jw fo (pg->g->n < n/frw; );
		j=0;e- lom cptr[i];=0;n * loe-s]extrem
.h-> nny = nge->iy3;
				} 	j=0;
dd1ev-e	->ix3s-.e->tid2;
e
	dy1(] ehs]iy
s-.e	->iy2E 
	y1-> ndd1eviy0 s *dy1(]	n0	cov */a pnt ologicng-caseractI_}	dd1ev-e	->ix3s-.e->tid1st[di	dy1(] ehs]iy
s-.e	->iy1l>	ge->	
	-> ndd1eviy0 s *dy1(]	n0	cov */a mfoe	pnt ologicng
I_}			 nvspaseractI_}	dd1ev-e	->ix3s-.e->te {
		id3				
	dy1(] ehs]iy
s-.e	->e {
		iy
				v->	
}>nhs].j=0;
dd1ev-e	->ix3s-.e->te {
		id3				
dy1(] ehs]iy
s-.e	->e {
		iy
				}=0;-> nnny = nge->iy3;
				} 	j=0;
dd2ev-e	->ix3s-.ne->tid1st[didy2(] ehs]iy
s-.ne	->iy1l>	ge-> ndd1eviy0 s *dy1(]	n0	cov */a pnt ologicng-caseractI_}	dd2ev-e	->ix3s-.ne->tid2				
	dy2(] ehs]iy
s-.ne	->iy2l>	ge->	
	-> ndd1eviy0 s *dy1(]	n0	cov */a mfoe	pnt ologicng
I_}			 nvspaseractI_}	dd2ev-e	->ix3s-.ne->tid3				
	dy2(] ehs]iy
s-.ne	->iy
				v->	
}>nhs].j=0;
dd2ev-e	->ix3s-.ne->tid3				
dy2(] ehs]iy
s-.ne	->iy
				}m
;
			cfmp 		 ang tshr[j		>frw[i].
zone bord yDIR_INNERE /E-> ndy1(]	n0	co>	
	-> ndd1e<y0	
1w	r>frw[i].
zone bord yDIR_OUTER;>	
}>nhs].-> ndy2(]	n0	co>	
	-> ndd2 >y0	
1w	r>frw[i].
zone bord yDIR_OUTER;>	
}>nhs].-> ndd2 **dy1(<ydd1 **dy2)tI_}pe, [i].
zone bord yDIR_OUTER;>j		>frw[i].ym cj->ym c[i];=0;>frw[i].xofm cj->xofm c[i];ns}S
e */s 			sie in;prmsafe,e1 			m*yrb /neigigi urretrrr[j	g	if>frwour_ 	nn/frw;
1d> nn/frwP>n0	co>	
g	i>frwour_e=y}
llo)(se oof(CONTOURDS rn/frwdE /E-> ng	i>frwour_e=	n0	cotI_} * sizeif (s[0]))) *** Memfoyn llo) tfe,es[0fo *) **mory forrnxit(255dE /	}r	-memcpyng	i>frwour_,	>frwr.se oof(CONTOURDS rn/frwdE /}p}es#e

	f>
y_lasubrout                               